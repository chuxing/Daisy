sudo mount -v -t tmpfs -o size=1G none /tmp/ramdisk
