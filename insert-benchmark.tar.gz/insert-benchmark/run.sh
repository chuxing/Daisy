./insert-dram & ./insert-ramdisk & ./insert-scm
