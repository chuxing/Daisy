/*
**************************************************************
***                                                        
*** Project    : DGM                                       
*** Filename   : Basis_rectangle_new.h                                      
*** Author     : QWL , Department of Aerodynamics , NUAA   
*** Created    : 03-27-2012
*** Last update: 03-27-2012                                      
*** Propose    : Taylor Basis                                          
***                                                        
**************************************************************
***                                                        
***  headfile called: none                                 
***                                                        
***  Functions called: none                                
***                                                        
**************************************************************
*/


/*************************************************************
***  Let the game begin
**************************************************************/
#include<math.h>
class Basis_rectangle
{
	public:
	Basis_rectangle(int p_input);
	~Basis_rectangle();
	
	void L_xy(double xi, double yi, double& L1, double& L2, double& L3, double& L4);
	void xi_L(double L1, double L2, double L3, double L4,double& xi, double& yi );
	
	void Ni(double L1, double L2, double L3,double L4);
	
	void Ni_xy(double x,double y);
	
	//-------------------------------------------------------------------------------------------
	int p;	int n_Ni; double* p_N0;	double* p_N1_1;	double* p_N1_2;	int* p_M_Ni;
	//-------------------------------------------------------------------------------------------
};

Basis_rectangle::Basis_rectangle(int p_input)
{
	int i;
	p = p_input;
	//++++++++++++++++++++++++++++++++++++++
	p_M_Ni = new int[p+1];
	p_M_Ni[0] = 1;
	for(i=1; i<=p; i++)
	{
		p_M_Ni[i] = p_M_Ni[i-1]+(i+1);
	}
	//++++++++++++++++++++++++++++++++++++++
	n_Ni   = p_M_Ni[p];
	
	p_N0   = new double[n_Ni];
	p_N1_1 = new double[n_Ni];
	p_N1_2 = new double[n_Ni];
	
}

Basis_rectangle::~Basis_rectangle()
{
	delete[]p_N0;
	delete[]p_N1_1;
	delete[]p_N1_2;
	delete[]p_M_Ni;
}

void Basis_rectangle::Ni(double L1, double L2, double L3,double L4)
{
	int k, i, px, py;
	double xi, yi;
	
	double xi_c = 0.0;
	double yi_c = 0.0;
	
	xi_L(L1, L2, L3, L4, xi, yi);
	
	xi = xi-xi_c;
	yi = yi-yi_c;
	
	i = 0;
	for(k=0; k<=p; k++) // current order
	{
		for(py=0; py<=k; py++)
		{
			px = k-py;
			//--------------------------------------------------------
			p_N0[i]   = pow(xi,px) * pow(yi,py) ;
			if(px >= 1)
				p_N1_1[i] = px*(pow(xi,px-1) * pow(yi,py));
			else
				p_N1_1[i] = 0.0;
			if(py >= 1)
				p_N1_2[i] = py*(pow(xi,px)   * pow(yi,py-1));
			else
				p_N1_2[i] = 0.0;
			//--------------------------------------------------------
			i = i+1;
		}
	}
}


void Basis_rectangle::Ni_xy(double x,double y)
{
	int k, i, px, py;
	double xi, yi;
	
	double xi_c = 0.0;
	double yi_c = 0.0;
	
	xi = x-xi_c;
	yi = y-yi_c;
	
	i = 0;
	for(k=0; k<=p; k++) // current order
	{
		for(py=0; py<=k; py++)
		{
			px = k-py;
			//--------------------------------------------------------
			p_N0[i]   = pow(xi,px) * pow(yi,py) ;
			if(px >= 1)
				p_N1_1[i] = px*(pow(xi,px-1) * pow(yi,py)) ;
			else
				p_N1_1[i] = 0.0;
			if(py >= 1)
				p_N1_2[i] = py*(pow(xi,px)   * pow(yi,py-1));
			else
				p_N1_2[i] = 0.0;
			//--------------------------------------------------------
			i = i+1;
		}
	}

}

void Basis_rectangle::L_xy(double xi, double yi, double& L1, double& L2, double& L3,double& L4)
{
	L1 = 0.25*(1-xi)*(1-yi);
	L2 = 0.25*(1+xi)*(1-yi);
	L3 = 0.25*(1+xi)*(1+yi);
	L4 = 0.25*(1-xi)*(1+yi);
}

void Basis_rectangle::xi_L(double L1, double L2, double L3,double L4, double& xi, double& yi)
{
	xi = (L2 - L1)/(L2 + L1);
	yi = (L3 - L2)/(L3 + L2);
}
