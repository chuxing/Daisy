
//#include"dg.h"
int Init_quadrature_max_1d()
{
	if(ORDER_QUADRATURE_1D > 11)
	{
		M_xi_1d = 20;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];
		
		p_xi_1d[0] = -0.993128599185;	p_wi_1d[0] = 0.0176140070678;
		p_xi_1d[1] = -0.963971927278;     	p_wi_1d[1] = 0.0406014298819;
		p_xi_1d[2] = -0.912234428251;    	p_wi_1d[2] = 0.0626720482976;
		p_xi_1d[3] = -0.839116971822;     	p_wi_1d[3] = 0.0832767415506;
		p_xi_1d[4] = -0.74633190646;	p_wi_1d[4] = 0.101930119826;
		p_xi_1d[5] = -0.636053680727;    	p_wi_1d[5] = 0.118194531969;
		p_xi_1d[6] = -0.510867001951;  	p_wi_1d[6] = 0.131688638458;
		p_xi_1d[7] = -0.373706088715;    	p_wi_1d[7] = 0.142096109327;
		p_xi_1d[8] = -0.227785851142;    	p_wi_1d[8] = 0.149172986482;
		p_xi_1d[9] = -0.0765265211335;     p_wi_1d[9] = 0.15275338714;

		p_xi_1d[10] = 0.0765265211335;     p_wi_1d[10] = 0.15275338714;
		p_xi_1d[11] = 0.227785851142;    	p_wi_1d[11] = 0.149172986482;
		p_xi_1d[12] = 0.373706088715;   	p_wi_1d[12] = 0.142096109327;
		p_xi_1d[13] = 0.510867001951;    	p_wi_1d[13] = 0.131688638458;
		p_xi_1d[14] = 0.636053680727;   	p_wi_1d[14] = 0.118194531969;
		p_xi_1d[15] = 0.74633190646;     	p_wi_1d[15] = 0.101930119826;
		p_xi_1d[16] = 0.839116971822;    	p_wi_1d[16] = 0.0832767415506;
		p_xi_1d[17] = 0.912234428251;     	p_wi_1d[17] = 0.0626720482976;
		p_xi_1d[18] = 0.963971927278;     	p_wi_1d[18] = 0.0406014298819;
		p_xi_1d[19] = 0.993128599185;     	p_wi_1d[19] = 0.0176140070678;
	}

	if(ORDER_QUADRATURE_1D == 11)
	{
		M_xi_1d = 12;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.981560634247;	p_wi_1d[0] = 0.0471753363866;
		p_xi_1d[1] = -0.90411725637;     	p_wi_1d[1] = 0.106939325995;
		p_xi_1d[2] = -0.769902674194;    	p_wi_1d[2] = 0.160078328543;
		p_xi_1d[3] = -0.587317954287;     	p_wi_1d[3] = 0.203167426723;
		p_xi_1d[4] = -0.367831498998;	p_wi_1d[4] = 0.233492536538;
		p_xi_1d[5] = -0.125233408511;    	p_wi_1d[5] = 0.249147045813;

		p_xi_1d[6] = 0.125233408511;  	p_wi_1d[6] = 0.249147045813;
		p_xi_1d[7] = 0.367831498998;    	p_wi_1d[7] = 0.233492536538;
		p_xi_1d[8] = 0.587317954287;    	p_wi_1d[8] = 0.203167426723;
		p_xi_1d[9] = 0.769902674194;    	p_wi_1d[9] = 0.160078328543;
		p_xi_1d[10] = 0.90411725637;    	p_wi_1d[10] = 0.106939325995;
		p_xi_1d[11] = 0.981560634247;    	p_wi_1d[11] = 0.0471753363866;

		return 12;
	}

	if(ORDER_QUADRATURE_1D == 9)
	{
		M_xi_1d = 10;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

	  	p_xi_1d[0] = -0.973906528517;  	p_wi_1d[0] = 0.0666713443087;
	 	p_xi_1d[1] = -0.865063366689; 	p_wi_1d[1] = 0.149451349151;
 		p_xi_1d[2] = -0.679409568299; 	p_wi_1d[2] = 0.219086362516;
 		p_xi_1d[3] = -0.433395394129; 	p_wi_1d[3] = 0.26926671931;
 		p_xi_1d[4] = -0.148874338982; 	p_wi_1d[4] = 0.295524224715;
 		p_xi_1d[5] = 0.148874338982; 	p_wi_1d[5] = 0.295524224715;
 		p_xi_1d[6] = 0.433395394129; 	p_wi_1d[6] = 0.26926671931;
 		p_xi_1d[7] = 0.679409568299; 	p_wi_1d[7] = 0.219086362516;
 		p_xi_1d[8] = 0.865063366689; 	p_wi_1d[8] = 0.149451349151;
 		p_xi_1d[9] = 0.973906528517; 	p_wi_1d[9] = 0.0666713443087;

		return 10;
	}

	if(ORDER_QUADRATURE_1D == 4 || ORDER_QUADRATURE_1D == 5)
	{
		M_xi_1d = 8;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

	  	p_xi_1d[0] = -0.960289856498; 	p_wi_1d[0] = 0.10122853629;
	 	p_xi_1d[1] = -0.796666477414; 	p_wi_1d[1] = 0.222381034453;
 		p_xi_1d[2] = -0.525532409916; 	p_wi_1d[2] = 0.313706645878;
 		p_xi_1d[3] = -0.183434642496; 	p_wi_1d[3] = 0.362683783378;
 		p_xi_1d[4] = 0.1834346424960; 	p_wi_1d[4] = 0.362683783378;
 		p_xi_1d[5] = 0.5255324099160; 	p_wi_1d[5] = 0.313706645878;
 		p_xi_1d[6] = 0.7966664774140; 	p_wi_1d[6] = 0.222381034453;
 		p_xi_1d[7] = 0.9602898564980; 	p_wi_1d[7] = 0.10122853629;

		return 8;
	}
	/*
	if(ORDER_QUADRATURE_1D == 5)
	{
		M_xi_1d = 6;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.932469514203;	p_wi_1d[0] = 0.171324492379;
		p_xi_1d[1] = -0.661209386466;      p_wi_1d[1] = 0.360761573048;
		p_xi_1d[2] = -0.238619186083;    	p_wi_1d[2] = 0.467913934573;
		p_xi_1d[3] = 0.238619186083;       p_wi_1d[3] = 0.467913934573;
		p_xi_1d[4] = 0.661209386466;	p_wi_1d[4] = 0.360761573048;
		p_xi_1d[5] = 0.932469514203;    	p_wi_1d[5] = 0.171324492379;

		return 6;
	}*/
	if(ORDER_QUADRATURE_1D == 3)
	{
		M_xi_1d = 5;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.906179845938664;		p_wi_1d[0] = 0.236926885056189;
		p_xi_1d[1] = -0.538469310105683;      	p_wi_1d[1] = 0.478628670499366;
		p_xi_1d[2] = 0.0;    			p_wi_1d[2] = 0.568888888888888;
		p_xi_1d[3] = 0.538469310105683;      	p_wi_1d[3] = 0.478628670499366;
		p_xi_1d[4] = 0.906179845938664;      	p_wi_1d[4] = 0.236926885056189;

		return 5;
	}

	if(ORDER_QUADRATURE_1D== 2)
	{
		M_xi_1d = 4;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.861136311594053;		p_wi_1d[0] = 0.347854845137454;
		p_xi_1d[1] = -0.339981043584856;      	p_wi_1d[1] = 0.652145154862546;
		p_xi_1d[2] = 0.339981043584856;    	p_wi_1d[2] = 0.652145154862546;
		p_xi_1d[3] = 0.861136311594053;      	p_wi_1d[3] = 0.347854845137454;

		return 4;

	}
	/*if(ORDER_QUADRATURE_1D == 2)
	{
		M_xi_1d = 3;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.774596669241483;		p_wi_1d[0] = 0.55555555555555555;
		p_xi_1d[1] = 0.0;      			p_wi_1d[1] = 0.88888888888888888;
		p_xi_1d[2] = 0.774596669241483;    	p_wi_1d[2] = 0.55555555555555555;

		return 3;
	}*/
	if(ORDER_QUADRATURE_1D == 1)
	{
		M_xi_1d = 2;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];

		p_xi_1d[0] = -0.577350269189626;		p_wi_1d[0] = 1.0;
		p_xi_1d[1] =  0.577350269189626;		p_wi_1d[1] = 1.0;

		return 2;
	}
	if(ORDER_QUADRATURE_1D== 0)
	{
		M_xi_1d = 1;
		p_xi_1d = new double[M_xi_1d];
		p_wi_1d = new double[M_xi_1d];
		
		p_xi_1d[0] = 0.0;	p_wi_1d[0] = 2.0;
		
		return 1;
	}
	else
	{
		return 0;
	}
}


void Read_triangle(Triangle_quadrature* p_triangle)
{
	int i,order, i_fscanf;
	
	FILE* fp = fopen("Quadrature_rule_triangle.txt", "r");
	for(order=0; order<6; order++)
	{
		i_fscanf = fscanf(fp, "%d%d\n", &p_triangle[order].order, &p_triangle[order].M_xi_2d);
		
		p_triangle[order].p_xi = new double[p_triangle[order].M_xi_2d];
		p_triangle[order].p_yi = new double[p_triangle[order].M_xi_2d];
		p_triangle[order].p_wi = new double[p_triangle[order].M_xi_2d];
		
		for(i=0; i<p_triangle[order].M_xi_2d; i++)
			i_fscanf = fscanf(fp, "%le%le%le\n", &p_triangle[order].p_xi[i], 
						    &p_triangle[order].p_yi[i], 
						    &p_triangle[order].p_wi[i]);
		i_fscanf = fscanf(fp, "\n");
		i_fscanf = fscanf(fp, "\n");
	}
	fclose(fp);
}


void Init_quadrature_max_2d()
{
	int i,j,ii,order_quadrature;
	//rec:
	M_xi_2d_rec = M_xi_1d * M_xi_1d;
	
	p_xi_2d_rec = new double[M_xi_2d_rec];
	p_yi_2d_rec = new double[M_xi_2d_rec];
	p_wi_2d_rec = new double[M_xi_2d_rec];
	 
	for(i=0;i<M_xi_1d;i++)
		for(j=0; j<M_xi_1d; j++)
		{
			ii = i * M_xi_1d + j;
			p_xi_2d_rec[ii] = p_xi_1d[j];
			p_yi_2d_rec[ii] = p_xi_1d[i];
			p_wi_2d_rec[ii] = p_wi_1d[i]*p_wi_1d[j]/4.0;
		}
		
	/*
	FILE* fp = fopen("xi_yi_rectangle.dat", "w");
	double test_temp = 0.0;
	for(ii=0; ii<M_xi_2d; ii++)
	{
		fprintf(fp, "%12.8f  %12.8f  %12.8f\n",p_xi_2d[ii], p_yi_2d[ii], p_wi_2d[ii]);
		test_temp = test_temp + p_wi_2d[ii];
	}
	printf("   test   =   %12.8f\n", test_temp);
	fclose(fp);
	*/
	//tri:
	Triangle_quadrature* p_triangle = new Triangle_quadrature[6];
	Read_triangle(p_triangle);
	
	order_quadrature = ORDER_U;
	M_xi_2d_tri = p_triangle[order_quadrature].M_xi_2d;
	
	p_xi_2d_tri = new double[M_xi_2d_tri];
	p_yi_2d_tri = new double[M_xi_2d_tri];
	p_wi_2d_tri = new double[M_xi_2d_tri];
	 
	for(ii=0;ii<M_xi_2d_tri;ii++)
	{
		p_xi_2d_tri[ii] = p_triangle[order_quadrature].p_xi[ii];
		p_yi_2d_tri[ii] = p_triangle[order_quadrature].p_yi[ii];
		p_wi_2d_tri[ii] = p_triangle[order_quadrature].p_wi[ii];
	}
	//===========================================================
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	for(order_quadrature=0; order_quadrature<6; order_quadrature++)
	{
		delete[]p_triangle[order_quadrature].p_xi;
		delete[]p_triangle[order_quadrature].p_yi;
		delete[]p_triangle[order_quadrature].p_wi;
	}
	delete[]p_triangle;
}




