#include<math.h>
class Basis_triangle
{
	public:
	Basis_triangle(int p_input);
	~Basis_triangle();
	
	void L_xy(double xi, double yi, double& L1, double& L2, double& L3);
	void xi_L(double L1, double L2, double L3, double& xi, double& yi );
	
	void Ni(double L1, double L2, double L3);
	
	void Ni_xy(double xi, double yi);
	
	//-------------------------------------------------------------------------------------------
	int p;	int n_Ni; double* p_N0;	double* p_N1_1;	double* p_N1_2;	int* p_M_Ni;
	//-------------------------------------------------------------------------------------------
	
	
};

Basis_triangle::Basis_triangle(int p_input)
{
	int i;
	p = p_input;
	//++++++++++++++++++++++++++++++++++++++
	p_M_Ni = new int[p+1];
	p_M_Ni[0] = 1;
	for(i=1; i<=p; i++)
	{
		p_M_Ni[i] = p_M_Ni[i-1]+(i+1);
	}
	//++++++++++++++++++++++++++++++++++++++
	n_Ni   = p_M_Ni[p];
	
	p_N0   = new double[n_Ni];
	p_N1_1 = new double[n_Ni];
	p_N1_2 = new double[n_Ni];
	
}

Basis_triangle::~Basis_triangle()
{
	delete[]p_N0;
	delete[]p_N1_1;
	delete[]p_N1_2;
	delete[]p_M_Ni;
}

void Basis_triangle::Ni(double L1, double L2, double L3)
{
	int k, i, px, py;
	double xi, yi;
	
	double xi_c = 0.0;
	double yi_c = 1.0/sqrt(3.0);
	
	xi_L(L1, L2, L3, xi, yi);
	
	xi = xi-xi_c;
	yi = yi-yi_c;
	
	i = 0;
	for(k=0; k<=p; k++) // current order
	{
		for(py=0; py<=k; py++)
		{
			px = k-py;
			//--------------------------------------------------------
			p_N0[i]   = pow(xi,px) * pow(yi,py) ;
			if(px >= 1)
				p_N1_1[i] = px*(pow(xi,px-1) * pow(yi,py)) ;
			else
				p_N1_1[i] = 0.0;
			if(py >= 1)
				p_N1_2[i] = py*(pow(xi,px)   * pow(yi,py-1));
			else
				p_N1_2[i] = 0.0;
			//--------------------------------------------------------
			i = i+1;
		}
	}
}


void Basis_triangle::Ni_xy(double xi, double yi)
{
	int k, i, px, py;
	
	double xi_c = 0.0;
	double yi_c = 1.0/sqrt(3.0);
	
	xi = xi-xi_c;
	yi = yi-yi_c;
	
	i = 0;
	for(k=0; k<=p; k++) // current order
	{
		for(py=0; py<=k; py++)
		{
			px = k-py;
			//--------------------------------------------------------
			p_N0[i]   = pow(xi,px) * pow(yi,py) ;
			if(px >= 1)
				p_N1_1[i] = px*(pow(xi,px-1) * pow(yi,py)) ;
			else
				p_N1_1[i] = 0.0;
			if(py >= 1)
				p_N1_2[i] = py*(pow(xi,px)   * pow(yi,py-1));
			else
				p_N1_2[i] = 0.0;
			//--------------------------------------------------------
			i = i+1;
		}
	}
}


void Basis_triangle::L_xy(double xi, double yi, double& L1, double& L2, double& L3)
{
	L1 = 0.5*(1-xi-yi/sqrt(3.0));
	L2 = 0.5*(1+xi-yi/sqrt(3.0));
	L3 = yi/sqrt(3.0);
}

void Basis_triangle::xi_L(double L1, double L2, double L3, double& xi, double& yi)
{
	xi = L2 - L1;
	yi = sqrt(3.0)*L3;
}

