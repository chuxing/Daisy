/*
 * =====================================================================================
 *
 *       Filename:  Init_para.h
 *
 *    Description: set parameters of initial state
 *
 *        Version:  1.0
 *        Created:  08/11/13 19:42:38
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

//#include"dg.h"
void Init_para_flow_out(int my_id, PARA_FLOW_OUT& para_flow_out)
{
	para_flow_out.rho = RHO_inf;
	para_flow_out.p   = P_inf;

	para_flow_out.u   = MACH_inf*cos(ALPHA*PI/180.0);
	para_flow_out.v   = MACH_inf*sin(ALPHA*PI/180.0);
	para_flow_out.e0  = T_inf/(GAMMA*(GAMMA-1.0)) + 0.5*MACH_inf*MACH_inf;

	/*
	if(2 == Dimen)
		Num_U = 4;
	else if(3 == Dimen)
		Num_U = 5;
	*/
	Num_U = 4;

	if(1 == FLAG_Turb)
	{
		//for S-A turb
		if(1 == FLAG_TModel)
		{
			Num_U = 5;
			para_flow_out.nut = Nut_far;
		}
		//for K-W turb:
		else if(2 == FLAG_TModel)
		{
			Num_U = 6;
			para_flow_out.kine = 3.0/2*Tu_far*Tu_far*MACH_inf*MACH_inf;
			para_flow_out.lwor = log(para_flow_out.kine/(FACTOR*Ru_far));
		}
	}
}



void Init_para( int my_id,
		GRID_GENERAL& Grid,
		PARA_FLOW_OUT& para_flow_out,
		PARA_ELEMENT* p_para_element,
		PARA_FACE* p_para_face)
{
	int e,k,i,num_f;
	int m_xi_2d,eshape;
	int face;
	//====== p_para_element ======
	for(e=0; e<Grid.num_e; e++)
	{
		Array_2d_double.New(p_para_element[e].p_u, Num_U, M_Ni_U);
		// rho  rho*u  rho*v  rho*w  rho*e0
		//Array_2d_double.New(p_para_element[e].p_u_old,Num_U, M_Ni_U);

		Array_2d_double.New(p_para_element[e].p_u0,Num_U, M_Ni_U);
		Array_2d_double.New(p_para_element[e].p_u1,Num_U, M_Ni_U);

		//if(6 == FLAG_IMPLICIT)
			//Array_2d_double.New(p_para_element[e].p_u_sold,Num_U, M_Ni_U);

		Array_2d_double.New(p_para_element[e].p_R, Num_U, M_Ni_U);

		//allocate more:if boundary is not face_last,this is needed
		Array_3d_double.New(p_para_element[e].p_dLdU_block, Grid.p_element[e].num_f, Num_U*M_Ni_U, Num_U*M_Ni_U);

		//if(3 == Grid.p_element[e].type)
			//Array_3d_double.New(p_para_element[e].p_dLdU_block, Grid.p_element[e].num_f, Num_U*M_Ni_U, Num_U*M_Ni_U);
		//else if(4 == Grid.p_element[e].type)
			//Array_3d_double.New(p_para_element[e].p_dLdU_block, Grid.p_element[e].num_f, Num_U*M_Ni_U, Num_U*M_Ni_U);

		/*
		num_f = Grid.num_f_e[e];
		Array_3d_double.New(p_para_element[e].p_dLdU, num_f, 6*M_Ni_U, 6*M_Ni_U);
		*/
		Array_2d_double.New(p_para_element[e].p_dLdU_block_1, Num_U*M_Ni_U, Num_U*M_Ni_U);

		p_para_element[e].p_du    = new double[Num_U*M_Ni_U];
		p_para_element[e].p_du0   = new double[Num_U*M_Ni_U];
		//------------------------------------------------

		//p_para_element initialize
		for(k=0; k<Num_U; k++)
		{
			for(i=0; i<M_Ni_U; i++)
			{
				p_para_element[e].p_u[k][i] = 0.0;

				p_para_element[e].p_du[k*M_Ni_U+i] = 0.0;
			}
		}

		p_para_element[e].p_u[0][0] = para_flow_out.rho;
		p_para_element[e].p_u[1][0] = para_flow_out.rho * para_flow_out.u;
		p_para_element[e].p_u[2][0] = para_flow_out.rho * para_flow_out.v;
		p_para_element[e].p_u[3][0] = para_flow_out.rho * para_flow_out.e0;

		if(1 == FLAG_Turb)
		{
			//for S-A turb
			if(1 == FLAG_TModel)
			{
				p_para_element[e].p_u[4][0] = para_flow_out.nut;
			}
			//for K-W turb:
			else if(2 == FLAG_TModel)
			{
				p_para_element[e].p_u[4][0] = para_flow_out.rho * para_flow_out.kine;
				p_para_element[e].p_u[5][0] = para_flow_out.rho * para_flow_out.lwor;
			}
		}
		//=============================================================================
	}

	//printf(" MY_ID = %6d \n",my_id);

	if(FLAG_CONTINUE == 1)
	{
		Read_para(my_id, Grid, p_para_element);
	}

	//printf(" MY_ID = %6d \n",my_id);

	for(e=0;e<Grid.num_e;e++)
		for(k=0; k<Num_U; k++)
			for(i=0; i<M_Ni_U; i++)
			{
				//p_para_element[e].p_u_old[k][i] = p_para_element[e].p_u[k][i];
				p_para_element[e].p_u0[k][i] = p_para_element[e].p_u[k][i];
				p_para_element[e].p_u1[k][i] = p_para_element[e].p_u[k][i];
			}


	//artificial initialize
	if(1 == FLAG_Laprho)
	{
		//artificial_visc:
		for(e=0;e<Grid.num_e;e++)
		{
			p_para_element[e].Epsilon = 0.0;
			p_para_element[e].Epsilon_old = 0.0;
			Array_2d_double.New(p_para_element[e].p_sx, Num_U, M_Ni_U);
			Array_2d_double.New(p_para_element[e].p_sy, Num_U, M_Ni_U);

			for(k=0;k<Num_U;k++)
				for(i=0;i<M_Ni_U;i++)
				{
					p_para_element[e].p_sx[k][i] = 0.0;
					p_para_element[e].p_sy[k][i] = 0.0;
				}

		}
	}

	//liftor initialize
	if(1 == FLAG_Euler)
	{
		for(e=0;e<Grid.num_e;e++)
		{
			num_f = Grid.p_element[e].num_f;
			eshape = Grid.p_element[e].type;

			if(3 == eshape)
				m_xi_2d = M_xi_2d_tri;
			else if(4 == eshape)
				m_xi_2d = M_xi_2d_rec;

			Array_2d_double.New(p_para_element[e].grad_ux_e, Num_U, m_xi_2d);
			Array_2d_double.New(p_para_element[e].grad_uy_e, Num_U, m_xi_2d);

			Array_3d_double.New(p_para_element[e].grad_ux_face_in_e, eshape, Num_U, M_xi_1d);
			Array_3d_double.New(p_para_element[e].grad_uy_face_in_e, eshape, Num_U, M_xi_1d);

			Array_2d_double.New(p_para_element[e].S_ex, Num_U, m_xi_2d);
			Array_2d_double.New(p_para_element[e].S_ey, Num_U, m_xi_2d);

			Array_4d_double.New(p_para_element[e].dS_ex, num_f, Num_U, Num_U, m_xi_2d);
			Array_4d_double.New(p_para_element[e].dS_ey, num_f, Num_U, Num_U, m_xi_2d);


		}
	}

	//====================================================
	if(1 == FLAG_Euler)
	{
		for(face=0;face<Grid.num_face;face++)
		{
			Array_2d_double.New( p_para_face[face].S_facex_l, Num_U, M_xi_1d );
			Array_2d_double.New( p_para_face[face].S_facey_l, Num_U, M_xi_1d );

			Array_4d_double.New( p_para_face[face].dS_facex_l, 2, Num_U, Num_U, M_xi_1d );
			Array_4d_double.New( p_para_face[face].dS_facey_l, 2, Num_U, Num_U, M_xi_1d );

			if(0 == Grid.p_face[face].flag)
			{
				Array_2d_double.New( p_para_face[face].S_facex_r, Num_U, M_xi_1d );
				Array_2d_double.New( p_para_face[face].S_facey_r, Num_U, M_xi_1d );

				Array_4d_double.New( p_para_face[face].dS_facex_r, 2, Num_U, Num_U, M_xi_1d );
				Array_4d_double.New( p_para_face[face].dS_facey_r, 2, Num_U, Num_U, M_xi_1d );
			}
		}
	}
	//===================================== p_para_face ======================================
	for(face=0; face<Grid.num_face; face++)
	{
		//p_para_face[face].p_alpha = new double[M_xi_1d];

		if(Grid.p_face[face].flag == -11 ||Grid.p_face[face].flag == -12) //分区边界
		{
			Array_2d_double.New( p_para_face[face].p_u_f,  Num_U, M_Ni_U );
			p_para_face[face].p_du_f  = new double[Num_U*M_Ni_U];
			p_para_face[face].p_du0_f = new double[Num_U*M_Ni_U];

			//type and Epsilon

			if(1 == FLAG_Laprho)
			{
				//shock
				Array_2d_double.New( p_para_face[face].p_sx_f,  Num_U, M_Ni_U );
				Array_2d_double.New( p_para_face[face].p_sy_f,  Num_U, M_Ni_U );
			}
			if(1 == FLAG_Euler)
			{
				//N-S
				Array_2d_double.New( p_para_face[face].p_gradx_f,  Num_U, M_xi_1d );
				Array_2d_double.New( p_para_face[face].p_grady_f,  Num_U, M_xi_1d );

				Array_4d_double.New( p_para_face[face].p_dS_facex_rf,  2, Num_U, Num_U, M_xi_1d );
				Array_4d_double.New( p_para_face[face].p_dS_facey_rf,  2, Num_U, Num_U, M_xi_1d );
			}
			if(1 == FLAG_Laprho || 1 == FLAG_Euler)
			{
				//Mesh
				Array_3d_double.New( Grid.p_face[face].p_dxi_dX_rface,  M_xi_1d, 2, 2 );
			}
		}
	}
	//========================================================================================
}


void  Read_para(int my_id,
		GRID_GENERAL&   Grid,
		PARA_ELEMENT*   p_para_element)
{
	int e,i,k, i_fscanf;

	int order_temp, num_e_temp, M_Ni_U_temp;

	char fname[500];
	//===========================================
	sprintf(fname,"output_data/%s%d%s%d.dat","OUTPUT_u_save_p",
					ORDER_U-1,"_id",my_id);

	if(!fname)
	{
		printf("error in open OUTPUT_u_save_id_%d_p%d.dat",my_id, ORDER_U-1);
	}

	FILE* fp_u = fopen(fname, "r");
	//-----------------------------------------------------------
	fscanf(fp_u, "%d%d%d\n", &order_temp, &num_e_temp, &M_Ni_U_temp);
	//-----------------------------------------------------------
	if( (num_e_temp != Grid.num_e) || (order_temp != ORDER_U-1) )
	{
		printf("########################################################\n");
		printf("###########   Error In Read_para() !!!!!!!!!  ##########\n");
		printf("########################################################\n");
	}
	//-----------------------------------------------------------
	for(e=0; e<Grid.num_e; e++)
	{
		for(k=0; k<Num_U; k++)
		{
			for(i=0; i<M_Ni_U_temp; i++)
				i_fscanf = fscanf(fp_u, "%le\n", &p_para_element[e].p_u[k][i]);
		}
		i_fscanf = fscanf(fp_u, "\n");

	}

	fclose(fp_u);
}

