//#include"dg.h"

void Cal_M_Ni_from_p(int P_order,int*& p_M_Ni)
{
	int p;
	
	p_M_Ni[0] = 1;
	
	for(p=1; p<=P_order; p++)
	{
		p_M_Ni[p] = p_M_Ni[p-1]+(p+1);
	}
}

//rectangle:
void Cal_L_from_xi_yi_rectangle(double xi, double yi, double& L1, double& L2, double& L3, double& L4)
{
	L1 = 0.25*(1-xi)*(1-yi);
	L2 = 0.25*(1+xi)*(1-yi);
	L3 = 0.25*(1+xi)*(1+yi);
	L4 = 0.25*(1-xi)*(1+yi);
}
/*
void Cal_xi_yi_from_L_rectangle(double L1, double L2, double L3,double L4, double& xi, double& yi)
{
	xi = (L2 - L1)/(L2 + L1);
	yi = (L3 - L2)/(L3 + L2);

}
*/
void Cal_X_from_xi_rectangle(double  X1_e, double  Y1_e, 
							double  X2_e, double  Y2_e, 
							double  X3_e, double  Y3_e, 
							double  X4_e, double  Y4_e,
							double  xi,   double  yi,
							double& X,    double& Y)
{
	double L1, L2, L3, L4;
	
	Cal_L_from_xi_yi_rectangle(xi, yi, L1, L2, L3, L4);
	
	X = L1*X1_e + L2*X2_e + L3*X3_e + L4*X4_e;
	Y = L1*Y1_e + L2*Y2_e + L3*Y3_e + L4*Y4_e;
}
//
//
//triangle:
void Cal_L_from_xi_yi_triangle(double xi, double yi, double& L1, double& L2, double& L3)
{
	L1 = 0.5*(1-xi-yi/sqrt(3.0));
	L2 = 0.5*(1+xi-yi/sqrt(3.0));
	L3 = yi/sqrt(3.0);
}

void Cal_xi_yi_from_L_triangle(double L1, double L2, double L3, double& xi, double& yi)
{
	xi = L2 - L1;
	yi = sqrt(3.0)*L3;
}
 
void Cal_X_from_xi_triangle(double  X1_e, double  Y1_e, 
							double  X2_e, double  Y2_e, 
							double  X3_e, double  Y3_e, 
							double  xi,   double  yi,
							double&  X,   double& Y)
{
	double L_1, L_2, L_3;
	
	Cal_L_from_xi_yi_triangle(xi, yi, L_1, L_2, L_3);
	
	X = L_1*X1_e + L_2*X2_e + L_3*X3_e;
	Y = L_1*Y1_e + L_2*Y2_e + L_3*Y3_e;
}
