//*****************************   FUNCTIONS DECLARATION   ****************************
//
//*****************************   Linear_Algebriac.h      ****************************
void Gaussian_elim(int n, double**& p_A0, double* p_b0, double* p_xi);
void A_inverse(int n, double** p_A0, double**& p_A_1);
void Matrix_Vector(int m, int n, double** a, double* b, double*& c);
void Matrix_Matrix(int m, int mn, int n, double** a, double** b, double**& c);

//*****************************   Basis_function.cpp        *****************************
void Init_element_reference(Basis_rectangle& Basis_rectangle
                           ,Basis_triangle & Basis_triangle);

void Init_face_reference(Basis_rectangle& Basis_rectangle
                        ,Basis_triangle & Basis_triangle);



//*****************************      Relations.cpp          ******************************
void Cal_M_Ni_from_p(int P_order,int*& p_M_Ni);
void Cal_L_from_xi_yi_rectangle(double xi, double yi, double& L1, double& L2, double& L3, double& L4);
void Cal_X_from_xi_rectangle(double  X1_e, double  Y1_e, double  X2_e, double  Y2_e, double  X3_e, double  Y3_e, double X4_e, double Y4_e, double  xi,   double  yi,   double& X,    double& Y);

void Cal_L_from_xi_yi_triangle(double xi, double yi, double& L_1, double& L_2, double& L_3);
void Cal_xi_yi_from_L_triangle(double L_1, double L_2, double L_3, double& xi, double& yi);
void Cal_X_from_xi_triangle(double  X1_e, double  Y1_e, double  X2_e, double  Y2_e, double  X3_e, double  Y3_e, double  xi,   double  yi,	double& X,    double& Y);

//*****************************   Init_quadrature_max.h   ******************************
int Init_quadrature_max_1d();
void Read_triangle(Triangle_quadrature* p_triangle);
void Init_quadrature_max_2d();
//if find minimum-form of rectangle quadrature points,add
//void Read_rectangle(Rectangle_quadrature* p_rectangle);
//void Init_quadrature_max_2d();



//*****************************      Grid_general.h       *******************************
void Init_grid_general(int my_id,GRID_GENERAL& Grid);

void Cal_Mass_Matrix(int my_id,GRID_GENERAL& Grid);

void Cal_curve_information(int my_id,GRID_GENERAL& Grid);

void Cal_Jacobi(int my_id,GRID_GENERAL& Grid);

void Cal_P_polynomials(double xi, double yi, double*& p_A_row);

void Cal_dP_dxi_polynomials(double xi, double yi, double*& p_A_row);

void Cal_dP_dyi_polynomials(double xi, double yi, double*& p_A_row);

void Cal_trans_from_X_to_X_4(double* p_xi, double* p_X, double* p_Y, double*& p_a);

void Cal_trans_from_X_to_xi(double* p_xi, double* p_X, double* p_Y, double*& p_a);

void Cal_coeffi(double* X,double* Y,double alpha,double beta,
           double* p_X,double* p_Y,double* p_NX,double* p_NY);
//*****************************       Init_para.h         ********************************
void Init_para_flow_out(int my_id, PARA_FLOW_OUT& para_flow_out);
void Init_para(int my_id, GRID_GENERAL& Grid,PARA_FLOW_OUT& para_flow_out,PARA_ELEMENT*p_para_element);
void Read_para(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element);



//*****************************       Newton_Iter.h       ***********************************
void Newton_Iter(int my_id, int iter, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,PARA_FACE* p_para_face,PARA_FLOW_OUT& para_flow_out,
                 Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle);

void MAX_u_du(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element, double& MAXdu);

//======================

//*****************************         Output.h          ***********************************
void Output_Interface_mix(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,
                                Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle);
void Output_u_save(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element);
void read_Interface_mix(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,
                                Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle);
void read_u_save(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element);
void Output_statistic();


//****************************        Time.h/Resi.h       ***********************************
void Time_Resi(int my_id);

//==========================  MPI ======================================
void Init_para_trans(int my_id, GRID_GENERAL& Grid, PARA_SEND*& p_para_send, PARA_RECV*& p_para_recv);

void Exchange_infor_u( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_infor_avis_s( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_infor_vis_grad( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_infor_vis_dS( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_infor_dxidX( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_infor_etype( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );



void Exchange_num_element_total(int my_id, GRID_GENERAL& Grid);

void Exchange_num_face_total(int my_id, GRID_GENERAL& Grid);




void Exchange_infor_du(int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element);

void Exchange_infor_du0(int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element);

void Exchange_infor_newe( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element );

void Exchange_MAX_udu_Linf(int my_id, GRID_GENERAL& Grid,double MAXdu,double& MAX_MAXdu);
