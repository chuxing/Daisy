/*
 * =====================================================================================
 *
 *       Filename:  Structs.h
 *
 *    Description:  structs for main
 *
 *        Version:  1.0
 *        Created:  08/11/13 19:26:39
 *       Revision:  V1
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

ARRAY_2D <int>    Array_2d_int;
ARRAY_2D <double> Array_2d_double;

ARRAY_3D <int>    Array_3d_int;
ARRAY_3D <double> Array_3d_double;

ARRAY_4D <int>    Array_4d_int;
ARRAY_4D <double> Array_4d_double;

ARRAY_5D <int>    Array_5d_int;
ARRAY_5D <double> Array_5d_double;

ARRAY_6D <int>    Array_6d_int;
ARRAY_6D <double> Array_6d_double;

ARRAY_7D <int>    Array_7d_int;
ARRAY_7D <double> Array_7d_double;

ARRAY_8D <int>    Array_8d_int;
ARRAY_8D <double> Array_8d_double;



struct PARA_FLOW_OUT
{
	double rho;
	double u;
	double v;
	double w;
	double p;
	double e0;
	double nut;
	double kine;
	double lwor;
};


struct Rectangle_quadrature
{
	int order;
	int M_xi_2d;
	
	double* p_xi;
	double* p_yi;
	double* p_wi;
};

struct Triangle_quadrature
{
	int order;
	int M_xi_2d;
	
	double* p_xi;
	double* p_yi;
	double* p_wi;
};


struct PARA_ELEMENT
{
	double**  p_u;             // [4][M_Ni_U]
	//double**  p_u_old;         // [4][M_Ni_U]
	//double** p_u_sold;
	 
	double** p_u0;
	double** p_u1;
	double**  p_R;             // [4][M_Ni_U]
	
	double*** p_f;             // [4][4][M_Ni_U]
	//:artificial_visc:
	double** p_sx;
	double** p_sy;
	double Epsilon;
	double Epsilon_old;
	//====================
	//PARAMETERS for NS Equations
	//====================
	//RHS-->grad,S
	double** grad_ux_e;          //[e][4][M_xi_2d]
	double** grad_uy_e;          //[e][4][M_xi_2d]
	double*** grad_ux_face_in_e;      //[e][index_rotating][4][M_xi_1d]
	double*** grad_uy_face_in_e;      //[e][index_rotating][4][M_xi_1d]
	
	double** S_ex;               //[e][4][M_xi_2d] for 2D
	double** S_ey;
	//===================
	//LHS-->dS/dU
	double**** dS_ex;            //[e][5][4][4][ii]
	double**** dS_ey;
	//==================
	double* p_du;
	double* p_du0;
	 
	double*** p_dLdU_block;          // [5][4*M_Ni_U][4*M_Ni_U]
	double**  p_dLdU_block_1; // [4*M_Ni_U][4*M_Ni_U]
	
};


struct PARA_FACE
{
	double* p_alpha;           //[M_xi_1d] for internal faces only;
	double alpha_max;
	//=====================
	double** p_u_f;            //[4][M_Ni_U]  from another partition
	double* p_du_f;            //[4*M_Ni_U]
	double* p_du0_f;
	
	//=====================
	//  MPI
	//type and Epsilon
	int p_type_f;   //may be change into Grid.p_face
	double p_Epsilon_f;
	//shock
	double** p_sx_f; //[4*M_Ni_U]
	double** p_sy_f;
	 
	//N-S
	double** p_gradx_f; //[4*M_xi_1d]
	double** p_grady_f;
	 
	double**** p_dS_facex_rf;
	double**** p_dS_facey_rf;
	//
	//=====================
	//PARAMETERS for NS Equations
	//====================
	//RHS-->gradS
	double** S_facex_l;//[face][4][M_xi_1d] for 2D
	double** S_facey_l;
	double** S_facex_r;
	double** S_facey_r;
	//=====================
	//LHS-->dS/dU
	double**** dS_facex_l;       //[face][2][4][4][ii]
	double**** dS_facex_r;
	double**** dS_facey_l;
	double**** dS_facey_r;
	//lis
	int enew_f;
	//=====================
};

struct PARA_SEND
{
	int     num;
	int*    p_e;	// [num]
	int*    p_face;	// [num]
	
	double* p_u;	// [num*(4*M_Ni_U)]
	double* p_du;	// [num*(4*M_Ni_U)]
	double* p_du0;	// [num*(4*M_Ni_U)]
	
	//MPI
	//type and Epsilon
	int* p_type;
	double* p_Epsilon;
	//avis
	double* p_sx;
	double* p_sy;
	//vis
	double* p_gradx;
	double* p_grady;
	 
	double* p_dS_facex;
	double* p_dS_facey;
	//grid 
	double* p_dxi_dX_r;
	//lis
	int* enew;
	
	double* p_N0;	// [num*(M_xi_1d*M_Ni_MAX)]
};
 
struct PARA_RECV
{
	int     num;
	int*    p_e;	// [num]
	int*    p_face;	// [num]

	double* p_u;	// [num*(4*M_Ni_U)]
	double* p_du;	// [num*(4*M_Ni_U)]
	double* p_du0;	// [num*(4*M_Ni_U)]
	
	//type and Epsilon
	int* p_type;
	double* p_Epsilon;
	//avis
	double* p_sx;
	double* p_sy;
	//vis
	double* p_gradx;
	double* p_grady;
	 
	double* p_dS_facex;
	double* p_dS_facey;
	//grid 
	double* p_dxi_dX_r;
	//lis
	int* enew;
	 
	double* p_N0;	// [num*(M_xi_1d*M_Ni_MAX)]
};

struct PARA_TRANS
{
	int  num;
	int* p_face;	// [num]
};

struct ELEMENT_INFOR
{
	int flag;
	int type;
	int cflag;   //for curve_layer 
	int* p_node;
	int* p_face;
	 
	double h;
	double* l;
	double volume;
	 
	int  num_f;
	//int* p_index_f;
	int* p_f;
	int* p_partition_f;		// for parallel only
	
	//int  num_face;
	//int* p_face;
	//int* p_index_face;
	
	int* face_in_e_curve;
	int* face_index_in_e_curve;
	 
	double* p_det_J_e; 
	double*** p_dxi_dX_e;		// [2][2]
	double*** p_dX_dxi_e;		// [2][2]
	
	double**** p_dX_dxi_face_in_e;  //[e][index_in_e][M_xi_1d][2][2]
	double**** p_dxi_dX_face_in_e;
	 
	double* p_a_to_X_e;
	double* p_a_to_Y_e;
	double* p_a_to_xi_e;
	double* p_a_to_yi_e;
	 
	//distance from wall
	double* DisWall;
	 
	//lis
	int enew;
	//+++++++++ Cal X from xi using Taylor Basis ++++++++
	//int        ORDER_U_X;
	//int        M_Ni_U_X;
	//double**   p_u_X;		// [2][M_Ni_U_X]
	//+++++++++++++++++++++++++++++++++++++++++++++++++++
	
	//double**   p_c_xi;	   	// [2][10]
	//double**   p_c_X;		// [2][10]
	
	//double**   p_X_node_Lagrangian;	// [M_Ni_U_LAGRANGIAN]
};

struct NODE_INFOR
{
	int flag;
	double* p_X;
};

struct FACE_INFOR
{
	int flag;
	int cflag;
	int* p_face;  //node+e
	 
	int index_in_e;
	int index_in_f;		// should be the same as in the 'global' case
	double Area;
	double* p_n_of_face;	// 在分区边界上时，方向与SOLID_WALL边界类似，指向流场外部
	
	int partition_e;
	int partition_f;
	int face_in_partition_f;
	// Curve solid
	double* offset;      //[2]
	double* X_face;      //[4]
	double* Y_face;
	double* NX_face;     //[3]
	double* NY_face;
	double** p_node_on_edge;
	
	double*** p_dxi_dX_rface;
	double* p_det_J_face;
	double** p_n_of_face_curved;  //[M_xi_1d][2]
	// Curve solid
	//double*  p_J_curved;	// [M_xi_1d]
	//double*  p_c_curved;	// [4] yi = sum c_j * pow(xi,j)
	//double** p_n_curved;	// [M_xi_1d][2]
	
	double** p_N0_e;	// [M_xi_1d][M_Ni_MAX]
	double** p_N0_f;	// including internal and partitioning boundary !!!
};

struct GRID_GENERAL
{
	//------------------  General infor  -----------------
	int num_e;
	int num_node;
	int num_face;
	
	//int num_face_wall;
	//int num_e_wall;
	
	//int num_up_wall;
	//int num_down_wall;
	//int* eup;
	//int* edown;
	//double* xup;
	//double* xdown;
	
	ELEMENT_INFOR* p_element;	
	NODE_INFOR*    p_node;
	FACE_INFOR*    p_face;
	//++++++++++++++++++ for master only +++++++++++++++++
	int*  p_num_e_slave;			// [NUM_PARTITION]
	int*  p_num_node_slave;			// [NUM_PARTITION]
	int*  p_num_face_slave;			// [NUM_PARTITION]

	int*  p_partition_of_e;			// [Grid.num_e]
	int** p_partition_of_face;		// [Grid.num_face][2]

	int*  p_e_slave;			// [Grid.num_e]
	//++++++++++++++++++ for slave only +++++++++++++++++
	int*  p_e_master;			// [num_e]
	int*  p_node_master;			// [num_node]
	int*  p_face_master;			// [num_face]
	//++++++++++++++++++ for exchanging +++++++++++++++++
	int  num_partition_neighbouring;
	int* p_partition_neighbouring;

	PARA_TRANS* p_trans;			// [num_partition_neighbouring]
};
