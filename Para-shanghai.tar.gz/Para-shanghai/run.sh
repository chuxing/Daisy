mpirun -np 1 ./dg_2d_Euler_parallel

#
#  Clean up.
#
#rm poisson
#
#echo "Program output written to poisson_local_output.txt"
echo "Program output to dg_mpi terminal"
