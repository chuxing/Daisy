/*
 * =====================================================================================
 *
 *       Filename:  Discretization.h
 *
 *    Description:  discretization of dg method AND RHS of equation
 *
 *        Version:  1.0
 *        Created:  03/12/13 13:49:31
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

//#include"dg.h"



