void pressure_dist(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element, Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle)
{   // not suitable for farfield and wall adjecent  �����Զ������һ��Ҫ�������ʽ��������ѭ��
	//��ԪҪ����
	int i,j,k,e,t,face,index_in_e;
	int node1,node2;
	int temp_e;
	double temp_x;
	double x1,y1,x2,y2;
	
	int index_up =0, index_down =0, num_e_wall =0;
	for(e=0;e<Grid.num_e;e++)
	{
		if(-1==Grid.p_element[e].flag)
		{
			num_e_wall ++;
		}
	}
	
	int* eup = new int[num_e_wall];
	int* edown = new int[num_e_wall];
	double* xup = new double[num_e_wall];
	double* xdown = new double[num_e_wall];
	//������Ԫ���������µ�Ԫ����Ԫ������򣬱���ͳ��
	for(e=0;e<Grid.num_e;e++)
	{
		if(-1==Grid.p_element[e].flag)
		{
			 face = Grid.p_element[e].p_face[3];
			node1 = Grid.p_element[e].p_node[0];
			node2 = Grid.p_element[e].p_node[1];
			   x1 = Grid.p_node[node1].p_X[0];
			   y1 = Grid.p_node[node1].p_X[1];
			   y2 = Grid.p_node[node2].p_X[1];
			   
			if(y1>=0 && y2>=0)
			{
				eup[index_up] = e;
				xup[index_up] = x1;
				index_up ++;
			}
			
			else if(y1<=0 && y2<=0)
			{
				edown[index_down] = e;
				xdown[index_down] = x1;
				index_down ++;
			}
		}
	}
	// ���µ�Ԫ���԰��������������浥Ԫ�����ң�������ҵ���
	// up
	for(i=0;i<index_up-1;i++)
	{
		k = i;
		for(j=i+1;j<index_up;j++)
		{
			if(xup[j]<xup[k])  k=j;
		}
		
		if(k!=i)
		{
			temp_e = eup[i];
			temp_x = xup[i];
			
			eup[i] = eup[k];
			xup[i] = xup[k];
			 
			eup[k] = temp_e;
			xup[k] = temp_x;
		}
	}
	//down
	for(i=0;i<index_down-1;i++)
	{
		k = i;
		for(j=i+1;j<index_down;j++)
		{
			if(xdown[j]>xdown[k])  k=j;
		}
		
		if(k!=i)
		{
			temp_e = edown[i];
			temp_x = xdown[i];
			
			edown[i] = edown[k];
			xdown[i] = xdown[k];
			 
			edown[k] = temp_e;
			xdown[k] = temp_x;
		}
	}
	
	// Mapping get the numerical results:
	double* p_coef1 = new double[8];
	double* p_coef2 = new double[8];
	double* p_coef3 = new double[8];
	double** p_node_flat;        //[5][2]
	double*** p_node_up;       //[e][5][2]
	double*** p_node_down;
	double** p_N0;
	double*** p_U_up;
	double*** p_U_down;
	 
	int N0 = N_OUTPUT;
	
	double rho,u,v,p,ma,c,nut,mut;
	double Xt,Fy,fv1;
	double cv1 = 7.1;
	//double* temp0,*temp1;
	
	//*** for Cf
	double*** p_N1;
	Array_3d_double.New(p_N1,N0,M_Ni_MAX,2);
	double dN_dX,dN_dY;
	double map[4],invmap[4];
	for(i=0;i<4;i++)
	{
		map[i] = 0.0;
		invmap[i] = 0.0;
	}
	double Jac;
	double mu;
	double UX,UY,VX,VY;
	double nx,ny,tx,ty,tk;
	double h1,h2,h3,p1,p2,p3;
	double pnx,pny,pnL;
	double txx,txy,tyy;
	double twx,twy;
	double Ptol,ttol;
	double temp,temp1;
	//***
	Array_2d_double.New(p_node_flat,N0,2);
	
	Array_3d_double.New(p_node_up,index_up,N0,2);
	Array_3d_double.New(p_node_down,index_down,N0,2);
	for(i=0;i<index_up;i++)
		for(j=0;j<N0;j++)
			{
				p_node_up[i][j][0] = 0.0;
				p_node_up[i][j][1] = 0.0;
			}
	for(i=0;i<index_down;i++)
		for(j=0;j<N0;j++)
			{
				p_node_down[i][j][0] = 0.0;
				p_node_down[i][j][1] = 0.0;
			}
	
	Array_2d_double.New(p_N0,N0,M_Ni_MAX);
	
	Array_3d_double.New(p_U_up,index_up,N0,Num_U);   //RHO,U,V,E,nut/Cp,Cf
	Array_3d_double.New(p_U_down,index_down,N0,Num_U);   //RHO,U,V,E,nut/Cp,Cf
	for(i=0;i<index_up;i++)
		for(j=0;j<N0;j++)
			for(t=0;t<Num_U;t++)
				p_U_up[i][j][t] = 0.0;
	for(i=0;i<index_down;i++)
		for(j=0;j<N0;j++)
			for(t=0;t<Num_U;t++)
				p_U_down[i][j][t] = 0.0; 
	
	//********************  here  to input the sixteen points in the flat plane  *******************//
	for(i=0;i<N0;i++)
	{
		p_node_flat[i][0] = -1 + 2.0/(N0-1)*i;
		p_node_flat[i][1] = -1.0;
	}
	
	for(i=0;i<N0;i++)
	{
		Basis_rectangle.Ni_xy(p_node_flat[i][0],p_node_flat[i][1]);
		
		for(k=0;k<M_Ni_MAX;k++)
		{
			p_N0[i][k] = Basis_rectangle.p_N0[k];
			p_N1[i][k][0] = Basis_rectangle.p_N1_1[k];
			p_N1[i][k][1] = Basis_rectangle.p_N1_2[k];
		}
	}
	
	
	for(i=0;i<index_up;i++)
	{
		e = eup[i];
		face = Grid.p_element[e].p_face[3];
		
		for(j=0;j<N0;j++)
		{
			UX = 0.0;
			UY = 0.0;
			VX = 0.0;
			VY = 0.0;
			 
			//===nx,ny:
			tk = 1.0/(N0-1)*j;
			h1 = Grid.p_face[face].NX_face[0];
			h2 = Grid.p_face[face].NX_face[1];
			h3 = Grid.p_face[face].NX_face[2];
			 
			p1 = Grid.p_face[face].NY_face[0];
			p2 = Grid.p_face[face].NY_face[1];
			p3 = Grid.p_face[face].NY_face[2];
			
			pnx = tk*tk*h1+tk*h2+h3;
			pny = tk*tk*p1+tk*p2+p3;
			//===
			pnL = sqrt(pnx*pnx+pny*pny);
			nx = pnx/pnL;
			ny = pny/pnL;
			//over
			
			//dudx...:
			for(t=0;t<4;t++)
				map[t] = 0.0;
			 
			Cal_dP_dxi_polynomials(p_node_flat[j][0],p_node_flat[j][1], p_coef2);   
			Cal_dP_dyi_polynomials(p_node_flat[j][0],p_node_flat[j][1], p_coef3);
			 
			
			for(t=0;t<8;t++)
			{
				map[0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef2[t];
				map[1] += Grid.p_element[e].p_a_to_X_e[t] * p_coef3[t];
				map[2] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef2[t];
				map[3] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef3[t];
			}
			Jac = map[0]*map[3] - map[1]*map[2];
			invmap[0] =  map[3]/Jac; 
			invmap[1] = -map[1]/Jac;
			invmap[2] = -map[2]/Jac;
			invmap[3] =  map[0]/Jac;
			
			for(t=0;t<M_Ni_MAX;t++)
			{
				for(k=0;k<Num_U;k++)
					p_U_up[i][j][k] += p_para_element[e].p_u[k][t] * p_N0[j][t];
				
				//for Cf
				dN_dX = p_N1[j][t][0] * invmap[0] + 
				        p_N1[j][t][1] * invmap[2] ;
				dN_dY = p_N1[j][t][0] * invmap[1] + 
				        p_N1[j][t][1] * invmap[3] ;
				
				UX += p_para_element[e].p_u[1][t] * dN_dX ;
				UY += p_para_element[e].p_u[1][t] * dN_dY ;
				VX += p_para_element[e].p_u[2][t] * dN_dX ;
				VY += p_para_element[e].p_u[2][t] * dN_dY ;
			}
				
				//Uy += S1[face][j];
				//Vx += S2[face][j];
				/*
				Cal_mu_from_U(p_U_up[i][j],mu);
				nut =  p_U_up[i][j][4];
				Xt = nut/(mu/rho);
				Fy = Xt;
				if(Fy<=10.0)
				{
					Fy = 0.05*log(1.0+exp(20.0*Xt));
				}
				fv1 = Fy*Fy*Fy/(Fy*Fy*Fy+cv1*cv1*cv1);
				
				//if(nut>=0.0)
				mut = rho*((mu/rho)*Fy)*fv1;
				//else if(nut<0.0)
				//{
				//	mut = 0.0;
				//}
				*/
				Cal_mu_from_U_Tur(p_U_up[i][j],mu,mut);
				txx = (mu+mut)*(2.0*UX-2.0/3*(UX+VY));
				txy = (mu+mut)*(UY+VX);
				tyy = (mu+mut)*(2.0*VY-2.0/3*(UX+VY));
				
				rho =  p_U_up[i][j][0];
				u =  p_U_up[i][j][1]/p_U_up[i][j][0];
				v =  p_U_up[i][j][2]/p_U_up[i][j][0];
				p =  (GAMMA-1.0)*( p_U_up[i][j][3] - 0.5*rho*(u*u+v*v) );
				//nut =  p_U_up[i][j][4];
				c =  sqrt(GAMMA*p/rho);
				ma =  sqrt(u*u+v*v)/c;
				//mut = rho*nut*fv1;
				//force_total:      
				twx = -(txx*nx+txy*ny)*FACTOR;
				twy = -(txy*nx+tyy*ny)*FACTOR;
				temp = twx*(-ny)+twy*(nx);//(txx*nx+txy*ny)*(txx*nx+txy*ny)+(txy*nx+tyy*ny)*(txy*nx+tyy*ny);
				temp1= twx*(nx)+twy*(ny);
				Ptol = p+temp1;
				ttol = temp;
				        
				p_U_up[i][j][0] = 2.0*(Ptol-P_inf)/(RHO_inf*MACH_inf*MACH_inf);
				p_U_up[i][j][1] = 2.0*(ttol)/(RHO_inf*MACH_inf*MACH_inf);
		}
	}
	
	for(i=0;i<index_down;i++)
	{
		e = edown[i];
		face = Grid.p_element[e].p_face[3];
		 
		for(j=0;j<N0;j++)
		{
			UX = 0.0;
			UY = 0.0;
			VX = 0.0;
			VY = 0.0;
			 
			//===nx,ny:
			tk = 1.0/(N0-1)*j;
			h1 = Grid.p_face[face].NX_face[0];
			h2 = Grid.p_face[face].NX_face[1];
			h3 = Grid.p_face[face].NX_face[2];
			 
			p1 = Grid.p_face[face].NY_face[0];
			p2 = Grid.p_face[face].NY_face[1];
			p3 = Grid.p_face[face].NY_face[2];
			
			pnx = tk*tk*h1+tk*h2+h3;
			pny = tk*tk*p1+tk*p2+p3;
			//===
			pnL = sqrt(pnx*pnx+pny*pny);
			nx = pnx/pnL;
			ny = pny/pnL;
			//over
			 
			for(t=0;t<4;t++)
				map[t] = 0.0;
			
			Cal_dP_dxi_polynomials(p_node_flat[j][0],p_node_flat[j][1], p_coef2);   
			Cal_dP_dyi_polynomials(p_node_flat[j][0],p_node_flat[j][1], p_coef3);
			for(t=0;t<8;t++)
			{
				map[0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef2[t];
				map[1] += Grid.p_element[e].p_a_to_X_e[t] * p_coef3[t];
				map[2] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef2[t];
				map[3] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef3[t];
			}
			Jac = map[0]*map[3] - map[1]*map[2];
			invmap[0] =  map[3]/Jac; 
			invmap[1] = -map[1]/Jac;
			invmap[2] = -map[2]/Jac;
			invmap[3] =  map[0]/Jac;
				
			for(t=0;t<M_Ni_MAX;t++)
			{
				for(k=0;k<Num_U;k++)
					p_U_down[i][j][k] += p_para_element[e].p_u[k][t] * p_N0[j][t];
				
				dN_dX = p_N1[j][t][0] * invmap[0] + 
				        p_N1[j][t][1] * invmap[2] ;
				dN_dY = p_N1[j][t][0] * invmap[1] + 
				        p_N1[j][t][1] * invmap[3] ;
				
				UX += p_para_element[e].p_u[1][t] * dN_dX ;
				UY += p_para_element[e].p_u[1][t] * dN_dY ;
				VX += p_para_element[e].p_u[2][t] * dN_dX ;
				VY += p_para_element[e].p_u[2][t] * dN_dY ;
			}
			//Uy += S1[face][j];
			//Vx += S2[face][j];
			Cal_mu_from_U_Tur(p_U_down[i][j],mu,mut);
			 
			txx = (mu+mut)*(2.0*UX-2.0/3*(UX+VY));
			txy = (mu+mut)*(UY+VX);
			tyy = (mu+mut)*(2.0*VY-2.0/3*(UX+VY));
			//Cal_mu_from_U(p_U_down[i][j],mu);
			//txx = 2.0*mu*UX-2.0/3*mu*(UX+VY);
			//txy = mu*(UY+VX);
			//tyy = 2.0*mu*VY-2.0/3*mu*(UX+VY);
			 
			rho =  p_U_down[i][j][0];
			u =  p_U_down[i][j][1]/p_U_down[i][j][0];
			v =  p_U_down[i][j][2]/p_U_down[i][j][0];
			p =  (GAMMA-1.0)*( p_U_down[i][j][3] - 0.5*rho*(u*u+v*v) );
			//nut =  p_U_down[i][j][4];
			c =  sqrt(GAMMA*p/rho);
			ma =  sqrt(u*u+v*v)/c;
			//mut = rho*nut*fv1; 
			//force_total:
			twx = -(txx*nx+txy*ny)*FACTOR;
			twy = -(txy*nx+tyy*ny)*FACTOR;
			temp = twx*(-ny)+twy*(nx);//(txx*nx+txy*ny)*(txx*nx+txy*ny)+(txy*nx+tyy*ny)*(txy*nx+tyy*ny);
			temp1= twx*(nx)+twy*(ny);
			Ptol = p+temp1;
			ttol = temp;
			
			p_U_down[i][j][0] = 2.0*(Ptol-P_inf)/(RHO_inf*MACH_inf*MACH_inf);
			p_U_down[i][j][1] = 2.0*(ttol)/(RHO_inf*MACH_inf*MACH_inf);
		}
	}
	
	//printf("ID = %5d\n", my_id);
	
	for(i=0;i<index_up;i++)
	{
		e = eup[i];
		
		if( -1 != Grid.p_element[e].flag)
		{
			printf("error in coff.h in press_output!\n");
			system("pause");
		}
		 
		else
		{
			for(j=0;j<N0;j++)
			{
				Cal_P_polynomials(p_node_flat[j][0],p_node_flat[j][1],p_coef1);
				
				for(t=0;t<8;t++)
				{
					p_node_up[i][j][0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef1[t];
					p_node_up[i][j][1] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef1[t];
				}
				
			}
		}
		
	}
	
	for(i=0;i<index_down;i++)
	{
		e = edown[i];
		
		if( -1 != Grid.p_element[e].flag)
		{
			printf("error in coff.h in press_output!\n");
			system("pause");
		}
		 
		else
		{
			for(j=0;j<N0;j++)
			{
				Cal_P_polynomials(p_node_flat[j][0],p_node_flat[j][1],p_coef1);
				for(t=0;t<8;t++)
				{
					p_node_down[i][j][0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef1[t];
					p_node_down[i][j][1] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef1[t];
				}
				
			}
		}
		
	}
	
	//printf("ID = %5d\n", my_id);
	
	//*** OK to output to tecplot Cp
	char fname[50];
	sprintf(fname,"output_data/%s%d%s%d.plt","OUTPUT_Cp_p",ORDER_U,"_id",my_id);
	FILE*fp4;
	fp4=fopen(fname,"w");
	
	//output to tecplot
	fprintf(fp4,"%s\n","Title = \"Cp distribution\"");
	fprintf(fp4,"%s\n","Variables= \"X\",\"CP\" ");
	
	if(index_up!=0)
	{
		fprintf(fp4,"%s%2d%s\n","Zone T=\"upsurf\", I=",index_up*N0,",F=Point, C=Red");
		for(i=0;i<index_up;i++)
			for(j=0;j<N0;j++)
				fprintf(fp4,"%16.6f%16.6f\n",p_node_up[i][j][0],p_U_up[i][j][0]);
	}
	if(index_down!=0)
	{
		fprintf(fp4,"%s%2d%s\n","Zone T=\"downsurf\", I=",index_down*N0,",F=Point, C=Blue");
		for(i=0;i<index_down;i++)
			for(j=0;j<N0;j++)
				fprintf(fp4,"%16.6f%16.6f\n",p_node_down[i][j][0],p_U_down[i][j][0]);
	}
	
	fclose(fp4);
	//***Cf:
	char fname2[50];
	sprintf(fname2,"output_data/%s%d%s%d.plt","OUTPUT_Cf_p",ORDER_U,"_id",my_id);
	fp4=fopen(fname2,"w");
	fprintf(fp4,"%s\n","Title = \"Cf distribution\"");
	fprintf(fp4,"%s\n","Variables= \"X\",\"Cf\" ");
	
	if(index_up!=0)
	{
		fprintf(fp4,"%s%2d%s\n","Zone T=\"upsurf\", I=",index_up*N0,",F=Point, C=Red");
		for(i=0;i<index_up;i++)
			for(j=0;j<N0;j++)
				fprintf(fp4,"%16.10f%16.10f\n",p_node_up[i][j][0],p_U_up[i][j][1]);
	}
	if(index_down!=0)
	{
		fprintf(fp4,"%s%2d%s\n","Zone T=\"downsurf\", I=",index_down*N0,",F=Point, C=Blue");
		for(i=0;i<index_down;i++)
			for(j=0;j<N0;j++)
				fprintf(fp4,"%16.10f%16.10f\n",p_node_down[i][j][0],p_U_down[i][j][1]);
	}
	fclose(fp4);
	
	//*** free space
	delete []p_coef1;
	delete []p_coef2;
	delete []p_coef3;
	
	delete []eup;
	delete []edown;
	delete []xup;
	delete []xdown;
	
	Array_2d_double.Delete(p_node_flat,N0,2);
	Array_3d_double.Delete(p_node_up,index_up,N0,2);
	Array_3d_double.Delete(p_node_down,index_down,N0,2);
	
	Array_2d_double.Delete(p_N0,N0,M_Ni_MAX);
	Array_3d_double.Delete(p_U_up,index_up,N0,Num_U);
	Array_3d_double.Delete(p_U_down,index_down,N0,Num_U);
	
	Array_3d_double.Delete(p_N1,N0,M_Ni_MAX,2);
}



void Cl_Cd(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,PARA_FACE* p_para_face,PARA_FLOW_OUT& para_flow_out,Basis_rectangle& Basis_rectangle)
{
	int e,i,j,k,face,ii,index_in_e;
	double* p_U = new double[Num_U];
	double rho,u,v,p,e0,tao,mu,mut,Xt;
	double UX,UY,VX,VY;
	double txx,txy,tyy,ttol,Ptol;
	double dN_dX,dN_dY;
	double nx,ny;
	double twx,twy;
	double temp;
	double YL = 0.0;
	double XD = 0.0;
	for(face=0;face<Grid.num_face;face++)
	{
		if(-1==Grid.p_face[face].flag)
		{
			e = Grid.p_face[face].p_face[2];
			index_in_e = Grid.p_face[face].index_in_e;
			for(ii=0;ii<M_xi_1d;ii++)
			{
				UX = 0.0;
				UY = 0.0;
				VX = 0.0;
				VY = 0.0;
				 
				for(i=0;i<M_Ni_U;i++)
				{
					dN_dX= p_N1_face_rec[index_in_e][ii][i][0] * Grid.p_element[e].p_dxi_dX_face_in_e[index_in_e][ii][0][0] + 
					       p_N1_face_rec[index_in_e][ii][i][1] * Grid.p_element[e].p_dxi_dX_face_in_e[index_in_e][ii][1][0] ;
					dN_dY= p_N1_face_rec[index_in_e][ii][i][0] * Grid.p_element[e].p_dxi_dX_face_in_e[index_in_e][ii][0][1] + 
					       p_N1_face_rec[index_in_e][ii][i][1] * Grid.p_element[e].p_dxi_dX_face_in_e[index_in_e][ii][1][1] ;
					
					UX += p_para_element[e].p_u[1][i] * dN_dX ;
					UY += p_para_element[e].p_u[1][i] * dN_dY ;
					VX += p_para_element[e].p_u[2][i] * dN_dX ;
					VY += p_para_element[e].p_u[2][i] * dN_dY ;
				}
				
				//Uy += S_facey_l[face][1][ii];
				//Vx += S_facex_l[face][2][ii];
				 
				nx = Grid.p_face[face].p_n_of_face_curved[ii][0];
				ny = Grid.p_face[face].p_n_of_face_curved[ii][1];
				
				Cal_U_from_u_on_face_in_rec(e, index_in_e, ii, p_para_element, p_U);
				
				Cal_mu_from_U_Tur(p_U,mu,mut);
				//Cal_mu_from_U(p_U,mu);
				
				//force_tensor:
				txx = (mu+mut)*(2.0*UX-2.0/3*(UX+VY));
				txy = (mu+mut)*(UY+VX);
				tyy = (mu+mut)*(2.0*VY-2.0/3*(UX+VY));
				
				rho = p_U[0];
				  u = p_U[1]/p_U[0];
				  v = p_U[2]/p_U[0];
				  e0= p_U[3]/p_U[0];
				  p = (e0-0.5*(u*u+v*v))*(GAMMA-1.0)*rho;
				   
				  Ptol = p;
				//if(ny<0.0)
				//{
					twx = -(txx*nx+txy*ny)*FACTOR;
					twy = -(txy*nx+tyy*ny)*FACTOR;
				//}
				/*
				else if(ny>=0.0)
				{
					twx = -(txx*nx+txy*ny)*FACTOR;
					twy = -(txy*nx+tyy*ny)*FACTOR;
				}
				*/
				  //tao = FACTOR*mu*(Uy+Vx); 
				  YL += (Ptol * ny + twy)* Grid.p_face[face].p_det_J_face[ii] * p_wi_1d[ii];
				  XD += (Ptol * nx + twx)* Grid.p_face[face].p_det_J_face[ii] * p_wi_1d[ii];
			}
		}
	}
		 
	Cl = 2.0*(YL*cos(ALPHA/180*PI)-XD*sin(ALPHA/180*PI))/(RHO_inf*MACH_inf*MACH_inf);
	Cd = 2.0*(YL*sin(ALPHA/180*PI)+XD*cos(ALPHA/180*PI))/(RHO_inf*MACH_inf*MACH_inf);
	//OUTPUT:
	delete []p_U;
	
	Exchange_ClCd(my_id, Grid);
	
	if(0 == my_id)
	{
		if(1 == FLAG_IMPLICIT || 2 == FLAG_IMPLICIT )//|| 3 == FLAG_IMPLICIT)
		{
			char fname3[50];
			sprintf(fname3,"output_data/%s%d.txt","OUTPUT_ClCd_p",ORDER_U);
			
			FILE* fp5 = fopen(fname3,"w");
			fprintf(fp5,"%s\n","Title = Coefficient Of LIFT AND DRAG");
			fprintf(fp5,"%s%8.4f\n","CL=",Cl);
			fprintf(fp5,"%s%8.4f\n","CD=",Cd);
			fclose(fp5);
		}
		 
		else if(3 == FLAG_IMPLICIT || 4 == FLAG_IMPLICIT|| 5 == FLAG_IMPLICIT || 6 == FLAG_IMPLICIT)
		{
			FILE* fp5;
			FILE* fp6;
			 
			char fname3[50];
			char fname4[50];
			sprintf(fname3,"output_data/%s%d.plt","OUTPUT_Cl_temp_p",ORDER_U);
			sprintf(fname4,"output_data/%s%d.plt","OUTPUT_Cd_temp_p",ORDER_U);
			if(0 == Iter)
			{
				fp5 = fopen(fname3,"w");
				fp6 = fopen(fname4,"w"); 
			}
			else
			{
				fp5 = fopen(fname3,"a");
				fp6 = fopen(fname4,"a");
			}
			
			temp = Iter * DT_STABIZATION;
			//fprintf(fp5,"%s\n","Title = Coefficient Of LIFT AND DRAG");
			fprintf(fp5,"%20.8f%20.8f\n",temp,Cl);
			fprintf(fp6,"%20.8f%20.8f\n",temp,Cd);
			fclose(fp5);
			fclose(fp6);
		}
		
	}
}
