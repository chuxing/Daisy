template <class Type_data> class ARRAY_2D
{
	public:
		void New(Type_data**& p_A, int N_1, int N_2);
		void Delete(Type_data**& p_A, int N_1, int N_2);
};

template <class Type_data> void ARRAY_2D<Type_data>::New(Type_data**& p_A, int N_1, int N_2)
{
	int i;

	p_A = new Type_data*[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data[N_2];
}

template <class Type_data> void ARRAY_2D<Type_data>::Delete(Type_data**& p_A, int N_1, int N_2)
{
	int i;
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}


//==========================================================================

template <class Type_data> class ARRAY_3D
{
	public:
		void New(Type_data***& p_A, int N_1, int N_2, int N_3);
		void Delete(Type_data***& p_A, int N_1, int N_2, int N_3);
};

template <class Type_data> void ARRAY_3D<Type_data>::New(Type_data***& p_A, int N_1, int N_2, int N_3)
{
	int i,j;

	p_A = new Type_data**[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data*[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data[N_3];
	}
}

template <class Type_data> void ARRAY_3D<Type_data>::Delete(Type_data***& p_A, int N_1, int N_2, int N_3)
{
	int i,j;
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}

//=======================================================================

template <class Type_data> class ARRAY_4D
{
	public:
		void New(Type_data****& p_A, int N_1, int N_2, int N_3, int N_4);
		void Delete(Type_data****& p_A, int N_1, int N_2, int N_3, int N_4);
};

template <class Type_data> void ARRAY_4D<Type_data>::New(Type_data****& p_A, int N_1, int N_2, int N_3, int N_4)
{
	int i,j,k;

	p_A = new Type_data***[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data**[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data*[N_3];
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				p_A[i][j][k] = new Type_data[N_4];
		}
	}
}

template <class Type_data> void ARRAY_4D<Type_data>::Delete(Type_data****& p_A, int N_1, int N_2, int N_3, int N_4)
{
	int i,j,k;
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				delete[]p_A[i][j][k];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}

//=============================================================================

template <class Type_data> class ARRAY_5D
{
	public:
		void New(Type_data*****& p_A,    int N_1, int N_2, int N_3, int N_4, int N_5);
		void Delete(Type_data*****& p_A, int N_1, int N_2, int N_3, int N_4, int N_5);
};

template <class Type_data> void ARRAY_5D<Type_data>::New(Type_data*****& p_A, int N_1, int N_2, int N_3, int N_4, int N_5)
{
	int i,j,k,m;

	p_A = new Type_data****[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data***[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data**[N_3];
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				p_A[i][j][k] = new Type_data*[N_4];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					p_A[i][j][k][m] = new Type_data[N_5];
			}
		}
	}
}

template <class Type_data> void ARRAY_5D<Type_data>::Delete(Type_data*****& p_A, int N_1, int N_2, int N_3, int N_4, int N_5)
{
	int i,j,k,m;

	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					delete[]p_A[i][j][k][m];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				delete[]p_A[i][j][k];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}

//=======================================================================

template <class Type_data> class ARRAY_6D
{
	public:
		void New(Type_data******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6);
		void Delete(Type_data******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6);
};

template <class Type_data> void ARRAY_6D<Type_data>::New(Type_data******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6)
{
	int i,j,k,m,n;

	p_A = new Type_data*****[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data****[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data***[N_3];
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				p_A[i][j][k] = new Type_data**[N_4];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					p_A[i][j][k][m] = new Type_data*[N_5];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						p_A[i][j][k][m][n] = new Type_data[N_6];
				}
			}
		}
	}

}

template <class Type_data> void ARRAY_6D<Type_data>::Delete(Type_data******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6)
{
	int i,j,k,m,n;

	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						delete[]p_A[i][j][k][m][n];
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					delete[]p_A[i][j][k][m];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				delete[]p_A[i][j][k];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}

//=======================================================================

template <class Type_data> class ARRAY_7D
{
	public:
		void New(   Type_data*******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7);
		void Delete(Type_data*******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7);
};

template <class Type_data> void ARRAY_7D<Type_data>::New(Type_data*******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7)
{
	int i,j,k,m,n,o;

	p_A = new Type_data******[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data*****[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data****[N_3];
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				p_A[i][j][k] = new Type_data***[N_4];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					p_A[i][j][k][m] = new Type_data**[N_5];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						p_A[i][j][k][m][n] = new Type_data*[N_6];
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
							p_A[i][j][k][m][n][o] = new Type_data[N_7];
					}
				}
			}
		}
	}

}

template <class Type_data> void ARRAY_7D<Type_data>::Delete(Type_data*******& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7)
{
	int i,j,k,m,n,o;

	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
							delete[]p_A[i][j][k][m][n][o];
					}
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						delete[]p_A[i][j][k][m][n];
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					delete[]p_A[i][j][k][m];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				delete[]p_A[i][j][k];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}
//=======================================================================

template <class Type_data> class ARRAY_8D
{
	public:
		void New(   Type_data********& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7, int N_8);
		void Delete(Type_data********& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7, int N_8);
};

template <class Type_data> void ARRAY_8D<Type_data>::New(Type_data********& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7, int N_8)
{
	int i,j,k,m,n,o,p;

	p_A = new Type_data*******[N_1];
	for(i=0; i<N_1; i++)
		p_A[i] = new Type_data******[N_2];
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			p_A[i][j] = new Type_data*****[N_3];
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				p_A[i][j][k] = new Type_data****[N_4];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					p_A[i][j][k][m] = new Type_data***[N_5];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						p_A[i][j][k][m][n] = new Type_data**[N_6];
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
							p_A[i][j][k][m][n][o] = new Type_data*[N_7];
					}
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
						{
							for(p=0; p<N_7; p++)
								p_A[i][j][k][m][n][o][p] = new Type_data[N_8];
						}
					}
				}
			}
		}
	}
}

template <class Type_data> void ARRAY_8D<Type_data>::Delete(Type_data********& p_A, int N_1, int N_2, int N_3, int N_4, int N_5, int N_6, int N_7, int N_8)
{
	int i,j,k,m,n,o,p;

	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
						{
							for(p=0; p<N_7; p++)
								delete[]p_A[i][j][k][m][n][o][p];
						}
					}
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
					{
						for(o=0; o<N_6; o++)
							delete[]p_A[i][j][k][m][n][o];
					}
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
				{
					for(n=0; n<N_5; n++)
						delete[]p_A[i][j][k][m][n];
				}
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
			{
				for(m=0; m<N_4; m++)
					delete[]p_A[i][j][k][m];
			}
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
		{
			for(k=0; k<N_3; k++)
				delete[]p_A[i][j][k];
		}
	}
	for(i=0; i<N_1; i++)
	{
		for(j=0; j<N_2; j++)
			delete[]p_A[i][j];
	}
	for(i=0; i<N_1; i++)
		delete[]p_A[i];
	delete[]p_A;
}


