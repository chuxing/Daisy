#!/bin/bash
#
sudo rm dg_2d_Euler_parallel
mpicxx -o dg_2d_Euler_parallel Main.cpp -lscmcxx
#
#
#  Rename the executable.
#
#mv a.out dg_mpi
#
#  Ask MPI to use 8 processes to run the program.
#
mpirun -np 1 ./dg_2d_Euler_parallel

#
#  Clean up.
#
#rm poisson
#
#echo "Program output written to poisson_local_output.txt"
echo "Program output to dg_mpi terminal"
