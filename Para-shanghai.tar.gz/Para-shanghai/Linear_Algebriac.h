//================================================================================================
//=======================================  Linear Algebriac  =====================================
//================================================================================================
void Gaussian_elim(int n, double**& p_A0, double* p_b0, double* p_xi)
{
	int i;  int j;  int ii; int jj;
	int i_largest;	double a_largest;
	int jcurrent = 0;
	double* p_tempa = new double[n];        double tempb;
	double aa;

	//++++++++++++++++++++++++++++
	double* p_aij = new double[n*n];
	double* p_bi = new double[n];
	for(i=0; i<n; i++)
	{
		for(j=0; j<n; j++)
			p_aij[i*n+j] = p_A0[i][j];
		p_bi[i] = p_b0[i];
	}
	//----------------------------
	for(jcurrent=0; jcurrent<(n-1); jcurrent++)
	{
		i_largest = jcurrent;
//		a_largest = p_aij[jcurrent*n+jcurrent];
		a_largest = fabs(p_aij[jcurrent*n+jcurrent]);

		for(i=jcurrent+1; i<n; i++)
		{
			if(fabs(p_aij[i*n+jcurrent]) > a_largest)
			{
				i_largest = i;
//				a_largest = p_aij[i*n+jcurrent];
				a_largest = fabs(p_aij[i*n+jcurrent]);
			}
		}

		if(i_largest != jcurrent)
		{
			for(j=0; j<n; j++)
			{
				p_tempa[j] = p_aij[n*jcurrent+j];
				p_aij[n*jcurrent+j] = p_aij[n*i_largest+j];
				p_aij[n*i_largest+j] = p_tempa[j];
			}
			tempb = p_bi[jcurrent];
			p_bi[jcurrent] = p_bi[i_largest];
			p_bi[i_largest] = tempb;
		}
		//---------------------------------
		for(ii=(jcurrent+1); ii<n; ii++)
		{
			aa = p_aij[n*ii+jcurrent]/p_aij[n*jcurrent+jcurrent];
			for(jj=jcurrent; jj<n; jj++ )
			{
				p_aij[n*ii+jj] = p_aij[n*ii+jj]-p_aij[n*jcurrent+jj]*aa;
			}
			p_bi[ii] = p_bi[ii]-p_bi[jcurrent]*aa;
		}
	}
	//-----------------------------------------
	p_xi[n-1] = p_bi[n-1]/p_aij[n*(n-1)+n-1];
	for(i=n-2; i>=0; i--)
	{
		p_xi[i] = p_bi[i];
		for(j=(i+1); j<n; j++)
		{
			p_xi[i] = p_xi[i]-p_aij[n*i+j]*p_xi[j];
		}
		p_xi[i] = p_xi[i]/p_aij[i*n+i];
	}

	//--------------------
	delete[]p_aij;
	delete[]p_bi;
	delete[]p_tempa;
}

void A_inverse(int n, double** p_A0, double**& p_A_1)
{
	int i,j,ii,jj;
	int i_largest;	double a_largest;
	int jcurrent = 0;
	double* p_tempa = new double[n];
 	double aa;

	//++++++++++++++++++++++++++++
	double** p_aij;
	Array_2d_double.New(p_aij, n, n);
	for(i=0; i<n; i++)
	{
		for(j=0; j<n; j++)
		{
			p_aij[i][j] = p_A0[i][j];
			if(j == i)
				p_A_1[i][j] = 1.0;
			else
				p_A_1[i][j] = 0.0;
		}
	}
	//----------------------------
	for(jcurrent=0; jcurrent<(n-1); jcurrent++)
	{
		i_largest = jcurrent;
		a_largest = fabs(p_aij[jcurrent][jcurrent]);

		for(i=jcurrent+1; i<n; i++)
		{
			if(fabs(p_aij[i][jcurrent]) > a_largest)
			{
				i_largest = i;
				a_largest = fabs(p_aij[i][jcurrent]);
			}
		}

		if(i_largest != jcurrent)
		{
			for(j=0; j<n; j++)
			{
				p_tempa[j] = p_aij[jcurrent][j];
				p_aij[jcurrent][j] = p_aij[i_largest][j];
				p_aij[i_largest][j] = p_tempa[j];
			}

			for(j=0; j<n; j++)
			{
				p_tempa[j] = p_A_1[jcurrent][j];
				p_A_1[jcurrent][j] = p_A_1[i_largest][j];
				p_A_1[i_largest][j] = p_tempa[j];
			}
		}
		//---------------------------------
		for(ii=(jcurrent+1); ii<n; ii++)
		{
			aa = p_aij[ii][jcurrent]/p_aij[jcurrent][jcurrent];
			for(jj=jcurrent; jj<n; jj++ )
				p_aij[ii][jj] = p_aij[ii][jj]-p_aij[jcurrent][jj]*aa;

			for(jj=0; jj<n; jj++ )
				p_A_1[ii][jj] = p_A_1[ii][jj]-p_A_1[jcurrent][jj]*aa;
		}
	}
	//=============================================================
	for(ii=0; ii<n; ii++)
	{
		aa = p_aij[ii][ii];
		for(jj=0; jj<n; jj++)
			p_aij[ii][jj] = p_aij[ii][jj]/aa;
		for(jj=0; jj<n; jj++)
			p_A_1[ii][jj] = p_A_1[ii][jj]/aa;
	}
	//-----------------------------------------
	for(jcurrent=n-1; jcurrent>0; jcurrent--)
	{
		for(ii=jcurrent-1; ii>=0; ii--)
		{
			aa = p_aij[ii][jcurrent];
			for(jj=0; jj<n; jj++)
			{
				p_aij[ii][jj] = p_aij[ii][jj]-aa*p_aij[jcurrent][jj];
				p_A_1[ii][jj] = p_A_1[ii][jj]-aa*p_A_1[jcurrent][jj];
			}
		}
	}
	delete[]p_tempa;
	Array_2d_double.Delete(p_aij, n, n);
}


void Matrix_Vector(int m, int n, double** a, double* b, double*& c)
{
	int i,j;
	for(i=0; i<m; i++)
	{
		c[i] = 0.0;
		for(j=0; j<n; j++)
		{
			c[i] = c[i]+a[i][j]*b[j];
		}
	}
}

void Matrix_Matrix(int m, int mn, int n, double** a, double** b, double**& c)
{
	int i,j,k;
	for(i=0; i<m; i++)
	{
		for(j=0; j<n; j++)
		{
			c[i][j] = 0.0;
			for(k=0; k<mn; k++)
			{
				c[i][j] = c[i][j]+a[i][k]*b[k][j];
			}
		}
	}
}



