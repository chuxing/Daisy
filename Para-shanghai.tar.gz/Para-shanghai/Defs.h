#define GAMMA		1.40
#define PrL			0.72
#define PrT			0.90

//Dimension //2d!
#define D1d			1
#define D2d			2
#define D3d			3
//Euler_NS
#define Euler		0
#define NS			1
//Wall_Type
#define isothermal	0
#define adiabatic	1
//FLUXe_MODEL
#define LLF			0
#define Roe			1
//FLUXv_MODEL
#define BR2			0
#define CDG			1
//Turbulence Mode
#define SA			0
#define KW			1
//SPARSE_MATRIX SOLVER
#define RK			0
#define BGS			1
#define GMRES		2
//boundary
#define Wall		-1 
#define Far			-2
#define Interior	0
#define Euler_wall	-3
//****** add your boundary

//******
#define Rec			4
#define Tri			3

