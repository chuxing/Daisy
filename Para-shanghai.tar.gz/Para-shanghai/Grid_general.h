/*
 * =====================================================================================
 *
 *       Filename:  Grid_general.h
 *
 *    Description:  grid generation and curve_impletation for DG method
 *
 *        Version:  1.0
 *        Created:  02/12/13 09:47:14
 *       Revision:  V1
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */
//#include"dg.h"
 
void Init_grid_general(int my_id, GRID_GENERAL& Grid)
{
	int e,i,j,k,ii, partition,face;
	int M_xi_2d_temp;
	 
	char fname[300];
	FILE* fp;
	 
	//################################################################
	partition = my_id;
	sprintf(fname,"data_partition/%s%d.txt","Grid_slave_", partition);
	fp = fopen(fname, "r");
	 
	//printf("ID = %5d\n", my_id);
	//-------------------- Grid_general ---------------------
	fscanf(fp, "%d\n",       &NUM_PARTITION);
	fscanf(fp, "%d %d %d\n", &Grid.num_e, &Grid.num_node, &Grid.num_face);
	
	Grid.p_element = new ELEMENT_INFOR[Grid.num_e];
	Grid.p_node    = new NODE_INFOR[Grid.num_node];
	Grid.p_face    = new FACE_INFOR[Grid.num_face];
	
	for(e=0; e<Grid.num_e; e++)
	{
		Grid.p_element[e].l = new double[2];
		Grid.p_element[e].face_in_e_curve = new int[2];
		Grid.p_element[e].face_index_in_e_curve = new int[2];
		  
		fscanf(fp, "%d %d %lf %lf %d %lf %lf %d %d %d %d %d", 
			&Grid.p_element[e].flag, 
			&Grid.p_element[e].type, 
			&Grid.p_element[e].h, 
			&Grid.p_element[e].volume, 
			&Grid.p_element[e].num_f, 
			&Grid.p_element[e].l[0], 
			&Grid.p_element[e].l[1],
			&Grid.p_element[e].cflag, 
			&Grid.p_element[e].face_in_e_curve[0], 
			&Grid.p_element[e].face_in_e_curve[1], 
			&Grid.p_element[e].face_index_in_e_curve[0],
			&Grid.p_element[e].face_index_in_e_curve[1]);
		
		Grid.p_element[e].p_node        = new int[Grid.p_element[e].type];
		Grid.p_element[e].p_face        = new int[Grid.p_element[e].type];
		Grid.p_element[e].p_f           = new int[Grid.p_element[e].num_f];
		Grid.p_element[e].p_partition_f = new int[Grid.p_element[e].num_f];
		//Grid.p_element[e].p_index_face  = new int[3];
		//Grid.p_element[e].p_index_f     = new int[3];
		
		for(i=0;i<Grid.p_element[e].type;i++)
		{
			fscanf(fp, "%d",&Grid.p_element[e].p_node[i]); 
		}
		 
		for(i=0;i<Grid.p_element[e].type;i++)
		{
			fscanf(fp, "%d",&Grid.p_element[e].p_face[i]); 
		}
		 
		for(i=0;i<Grid.p_element[e].num_f;i++)
		{
			fscanf(fp, "%d",&Grid.p_element[e].p_f[i]); 
		}
		for(i=0;i<Grid.p_element[e].num_f;i++)
		{
			fscanf(fp, "%d",&Grid.p_element[e].p_partition_f[i]); 
		}
		
		fscanf(fp,"\n");
	}
	//======================================
	for(i=0; i<Grid.num_node; i++)
	{
		Grid.p_node[i].p_X = new double[2];
		fscanf(fp, "%d %lf %lf\n", 
				&Grid.p_node[i].flag, 
				&Grid.p_node[i].p_X[0], 
				&Grid.p_node[i].p_X[1]);
	}
	
	for(face=0; face<Grid.num_face; face++)
	{
		Grid.p_face[face].p_n_of_face = new double[2];
		Grid.p_face[face].p_face = new int[4];
		Grid.p_face[face].offset = new double[2];
		 
		fscanf(fp, "%d %d %d %d %d %d %d %d %d %d %lf %lf %lf", 
				&Grid.p_face[face].flag, 
				&Grid.p_face[face].p_face[0], 
				&Grid.p_face[face].p_face[1], 
				&Grid.p_face[face].p_face[2], 
				&Grid.p_face[face].p_face[3], 
				&Grid.p_face[face].index_in_e,
				&Grid.p_face[face].index_in_f, 
				&Grid.p_face[face].partition_e,
				&Grid.p_face[face].partition_f,
				&Grid.p_face[face].face_in_partition_f,
				&Grid.p_face[face].p_n_of_face[0], 
				&Grid.p_face[face].p_n_of_face[1], 
				&Grid.p_face[face].Area);
		 
		fscanf(fp, "%d", &Grid.p_face[face].cflag);
		 
		for(i=0;i<2;i++)
		{
			fscanf(fp, "%lf",&Grid.p_face[face].offset[i]);
		}
		 
		fscanf(fp,"\n");
	}
	 
	//------------------- Partition Infor -------------------
	Grid.p_e_master    = new int[Grid.num_e];
	Grid.p_node_master = new int[Grid.num_node];
	Grid.p_face_master = new int[Grid.num_face];
	for(e=0; e<Grid.num_e; e++)
		fscanf(fp, "%d\n", &Grid.p_e_master[e]);
	for(i=0; i<Grid.num_node; i++)
		fscanf(fp, "%d\n", &Grid.p_node_master[i]);
	for(k=0; k<Grid.num_face; k++)
		fscanf(fp, "%d\n", &Grid.p_face_master[k]);
	//--------------------  Trans Infor  --------------------
	fscanf(fp, "%d\n", &Grid.num_partition_neighbouring);
	
	Grid.p_partition_neighbouring = new int[Grid.num_partition_neighbouring];
	for(i=0; i<Grid.num_partition_neighbouring; i++)
		fscanf(fp, "%d\n", &Grid.p_partition_neighbouring[i]);
	
	Grid.p_trans = new PARA_TRANS[Grid.num_partition_neighbouring];
	for(i=0; i<Grid.num_partition_neighbouring; i++)
	{
		fscanf(fp, "%d\n", &Grid.p_trans[i].num);
		
		Grid.p_trans[i].p_face = new int[Grid.p_trans[i].num];
		for(j=0; j<Grid.p_trans[i].num; j++)
			fscanf(fp, "%d\n", &Grid.p_trans[i].p_face[j]);
	}
	//-------------------------------------------------------
	fclose(fp);
	
	//printf("ID = %5d\n", my_id);
	//==================== 
	//Distance of Wall in S-A
	if(1 == FLAG_Turb && 1 == FLAG_TModel)
	{
		char fname1[300];
		FILE* fp1;
		sprintf(fname1,"data_partition/%s%d.txt","GridDis_slave_", partition);
		fp1 = fopen(fname1, "r");
		 
		for(e=0; e<Grid.num_e; e++)
		{
			if(3 == Grid.p_element[e].type)
				M_xi_2d_temp = M_xi_2d_tri;
			if(4 == Grid.p_element[e].type)
				M_xi_2d_temp = M_xi_2d_rec;
			
			Grid.p_element[e].DisWall = new double[M_xi_2d_temp];
			 
			for(i=0;i<M_xi_2d_temp;i++)
				fscanf(fp1, "%lf",&Grid.p_element[e].DisWall[i]);
				 
			fscanf(fp1,"\n");
		}
		 
		fclose(fp1);
	}
	//################################################################
	
	MPI_Barrier(MPI_COMM_WORLD);
	printf("MY_ID = %2d  Reading Mesh Done !!!\n", my_id );
	MPI_Barrier(MPI_COMM_WORLD);
	
	//==============================================================
	Cal_curve_information(partition,Grid);
	Cal_Jacobi(partition,Grid);
	Cal_Mass_Matrix(partition,Grid);
	//==============================================================
}

void Cal_Mass_Matrix(int my_id,GRID_GENERAL& Grid)
{
	//get p_M
	int e,ii,i,j;
	Array_3d_double.New(p_M,  Grid.num_e, M_Ni_U, M_Ni_U);
	Array_3d_double.New(p_M_1,Grid.num_e, M_Ni_U, M_Ni_U);
	
	for(e=0;e<Grid.num_e;e++)
	{
		for(i=0; i<M_Ni_U; i++)
		{
			for(j=0; j<M_Ni_U; j++)   
			{
				p_M[e][i][j] = 0.0;
				
				if(4 == Grid.p_element[e].type)
				{
					for(ii=0; ii<M_xi_2d_rec; ii++)
					{
						p_M[e][i][j] = p_M[e][i][j] + 4.0*Grid.p_element[e].p_det_J_e[ii]*p_wi_2d_rec[ii]*p_N0_element_rec[ii][i]*p_N0_element_rec[ii][j];
					}
				}
				//------------------------------
				else if(3 == Grid.p_element[e].type)
				{
					for(ii=0; ii<M_xi_2d_tri; ii++)
					{
						p_M[e][i][j] = p_M[e][i][j] + Grid.p_element[e].volume*p_wi_2d_tri[ii]*p_N0_element_tri[ii][i]*p_N0_element_tri[ii][j];
					}
				}
			}
		}
		 
		A_inverse(M_Ni_U, p_M[e], p_M_1[e]);
	} 
}
 
void Cal_curve_information(int my_id,GRID_GENERAL& Grid)
{
	int e,face,i,j,k,ii;
	int a,b,p;
	double offset1,offset2;
	
	//allocate 
	double* X = new double[2];
	double* Y = new double[2];
	
	for(face=0;face<Grid.num_face;face++)
	{
		Grid.p_face[face].X_face = new double[4];
		Grid.p_face[face].Y_face = new double[4];
		Grid.p_face[face].NX_face = new double[3];
		Grid.p_face[face].NY_face = new double[3];
		 
		Array_2d_double.New( Grid.p_face[face].p_node_on_edge, 4 ,2 );
		
		Array_2d_double.New(Grid.p_face[face].p_n_of_face_curved,M_xi_1d,2);
	}
	//zero_set 
	for(face=0;face<Grid.num_face;face++)
	{
		for(j=0;j<4;j++)
		{
			Grid.p_face[face].X_face[j] = 0.0;
			Grid.p_face[face].Y_face[j] = 0.0;
		}
		 
		for(j=0;j<3;j++)
		{
			Grid.p_face[face].NX_face[j] = 0.0;
			Grid.p_face[face].NY_face[j] = 0.0;
		}
	}
	
	for(face=0;face<Grid.num_face;face++)
	{
		for(j=0;j<4;j++)
			for(k=0;k<2;k++)
			{
				Grid.p_face[face].p_node_on_edge[j][k] = 0.0;
			}
	}
	
	for(face=0;face<Grid.num_face;face++)
		for(j=0;j<M_xi_1d;j++)
			for(k =0;k<2;k++)
				Grid.p_face[face].p_n_of_face_curved[j][k] = 0.0;
	
	//TEST
	/*
	FILE* fp2; 
	char fname1[100];
	sprintf(fname1,"checkoff_%d.txt",my_id);
	fp2 =  fopen(fname1,"w");
	*/
	//
	//============================================================
	for(face=0;face<Grid.num_face;face++)
	{
		a = Grid.p_face[face].p_face[0];
		b = Grid.p_face[face].p_face[1];
		 
		if(-1 == Grid.p_face[face].cflag || -2 == Grid.p_face[face].cflag)
		{
			if(-12 != Grid.p_face[face].flag)
			{
				X[0] = Grid.p_node[a].p_X[0];
				Y[0] = Grid.p_node[a].p_X[1];
				X[1] = Grid.p_node[b].p_X[0];
				Y[1] = Grid.p_node[b].p_X[1];
				 
				offset1 = Grid.p_face[face].offset[0];
				offset2 = Grid.p_face[face].offset[1];
				
				Cal_coeffi(X,Y,offset1,offset2, Grid.p_face[face].X_face,Grid.p_face[face].Y_face,
				       Grid.p_face[face].NX_face,Grid.p_face[face].NY_face); 
			}
			else if(-12 == Grid.p_face[face].flag)
			{
				X[0] = Grid.p_node[a].p_X[0];
				Y[0] = Grid.p_node[a].p_X[1];
				X[1] = Grid.p_node[b].p_X[0];
				Y[1] = Grid.p_node[b].p_X[1];
				 
				offset1 = Grid.p_face[face].offset[1];
				offset2 = Grid.p_face[face].offset[0];
				
			Cal_coeffi(X,Y,offset1,offset2, Grid.p_face[face].X_face,Grid.p_face[face].Y_face,
				       Grid.p_face[face].NX_face,Grid.p_face[face].NY_face); 
			}
			 
			//if(373 == Grid.p_face_master[face])
			//{
			//	fprintf(fp2,"%15.10f%15.10f\n",offset1,offset2);
			//}
		}
	}
	
	//fclose(fp2);
	delete[]X;
	delete[]Y;
	 
	//=================================================
	double f1,f2,f3,f4;
	double g1,g2,g3,g4;
	double h1,h2,h3;
	double p1,p2,p3;
	double tk,pnx,pny,pnL;
	
	//==================================================
	//for curved normal vector
	for(face=0;face<Grid.num_face;face++)
	{
		if(-1 == Grid.p_face[face].cflag || -2 == Grid.p_face[face].cflag)
		{
			a = Grid.p_face[face].p_face[0];
			b = Grid.p_face[face].p_face[1];
			 
			Grid.p_face[face].p_node_on_edge[0][0] = Grid.p_node[a].p_X[0];
			Grid.p_face[face].p_node_on_edge[0][1] = Grid.p_node[a].p_X[1];
			Grid.p_face[face].p_node_on_edge[3][0] = Grid.p_node[b].p_X[0];
			Grid.p_face[face].p_node_on_edge[3][1] = Grid.p_node[b].p_X[1];
			// other two_points:
			f1 = Grid.p_face[face].X_face[0];
			f2 = Grid.p_face[face].X_face[1];
			f3 = Grid.p_face[face].X_face[2];
			f4 = Grid.p_face[face].X_face[3];
			 
			g1 = Grid.p_face[face].Y_face[0];
			g2 = Grid.p_face[face].Y_face[1];
			g3 = Grid.p_face[face].Y_face[2];
			g4 = Grid.p_face[face].Y_face[3];
			
			//4_nodes on edges: 
			Grid.p_face[face].p_node_on_edge[1][0] = (1.0/27)*f1+(1.0/9)*f2+(1.0/3)*f3+f4;
			Grid.p_face[face].p_node_on_edge[1][1] = (1.0/27)*g1+(1.0/9)*g2+(1.0/3)*g3+g4;
			Grid.p_face[face].p_node_on_edge[2][0] = (8.0/27)*f1+(4.0/9)*f2+(2.0/3)*f3+f4;
			Grid.p_face[face].p_node_on_edge[2][1] = (8.0/27)*g1+(4.0/9)*g2+(2.0/3)*g3+g4;
			
			//p_n_nodes on quadrature points:
			for(j=0;j<M_xi_1d;j++)
			{
				  tk = (p_xi_1d[j]+1.0)/2.0;
				
				 h1 = Grid.p_face[face].NX_face[0];
				 h2 = Grid.p_face[face].NX_face[1];
				 h3 = Grid.p_face[face].NX_face[2];
				  
				 p1 = Grid.p_face[face].NY_face[0];
				 p2 = Grid.p_face[face].NY_face[1];
				 p3 = Grid.p_face[face].NY_face[2];
				 
				 pnx = tk*tk*h1+tk*h2+h3;
				 pny = tk*tk*p1+tk*p2+p3;
				 //===
				 pnL = sqrt(pnx*pnx+pny*pny);
				 pnx = pnx/pnL;
				 pny = pny/pnL;
				  
				Grid.p_face[face].p_n_of_face_curved[j][0] = pnx;
				Grid.p_face[face].p_n_of_face_curved[j][1] = pny;
			}
		}
	}
	
	//========================================
	//test in file
	char fname[100];
	sprintf(fname,"test_curve/%s%d.txt","Grid_curve_", my_id);
	double tx,ty;
	double gt;
	FILE* fp_t = fopen(fname, "w");
	
	for(face=0;face<Grid.num_face;face++)
	{
		if(-1==Grid.p_face[face].cflag || -2==Grid.p_face[face].cflag)     //---wall
		{
			f1 = Grid.p_face[face].X_face[0];
			f2 = Grid.p_face[face].X_face[1];
			f3 = Grid.p_face[face].X_face[2];
			f4 = Grid.p_face[face].X_face[3];
			 
			g1 = Grid.p_face[face].Y_face[0];
			g2 = Grid.p_face[face].Y_face[1];
			g3 = Grid.p_face[face].Y_face[2];
			g4 = Grid.p_face[face].Y_face[3];
			
			fprintf(fp_t,"%d\n",10);
			 
			for(j=0;j<10;j++)
			{
				gt = j/9.0;
				tx = gt*gt*gt*f1+gt*gt*f2+gt*f3+f4;
				ty = gt*gt*gt*g1+gt*gt*g2+gt*g3+g4;
				fprintf(fp_t,"%9.5f%9.5f%9.5f\n",tx,ty,0.00000);
			}
		}
	}
	
	fclose(fp_t);
}

void Cal_Jacobi(int my_id,GRID_GENERAL& Grid)
{
	int i,j,k,t,ii;
	int e,face,index;
	int node1,node2,node3,node4;
	double p_X_trans;
	double p_Y_trans;
	
	int facet[2];
	int indext[2];
	double nx[2],ny[2];
	double signal,J_face;
	
	//allocate
	double* p_bx = new double [4];
	double* p_by = new double [4];
	double* p_coef1 = new double [8];
	double* p_coef2 = new double [8];
	double* p_coef3 = new double [8];
	 
	double** p_X_8;
	double** p_xi_8;
	Array_2d_double.New(p_X_8,2,8);
	Array_2d_double.New(p_xi_8,2,8);
	double** p_X_4;
	double** p_xi_4;
	Array_2d_double.New(p_X_4,2,4);
	Array_2d_double.New(p_xi_4,2,4);
	//p_a_to_X(Y)
	for(e=0;e<Grid.num_e;e++)
	{
		Grid.p_element[e].p_a_to_X_e = new double[8];
		Grid.p_element[e].p_a_to_Y_e = new double[8];
		Grid.p_element[e].p_a_to_xi_e = new double[8];
		Grid.p_element[e].p_a_to_yi_e = new double[8];
	}
	
	for(e=0;e<Grid.num_e;e++)
		for(j=0;j<8;j++)
		{
			Grid.p_element[e].p_a_to_X_e[j] = 0.0;
			Grid.p_element[e].p_a_to_Y_e[j] = 0.0;
			Grid.p_element[e].p_a_to_xi_e[j] = 0.0;
			Grid.p_element[e].p_a_to_yi_e[j] = 0.0;
		}
		
	//p_X_xi_e(p_xi_X_e) 
	for(e=0;e<Grid.num_e;e++)
	{
		if(3 == Grid.p_element[e].type)
		{
			Array_3d_double.New(Grid.p_element[e].p_dX_dxi_e,M_xi_2d_tri,2,2);
			Array_3d_double.New(Grid.p_element[e].p_dxi_dX_e,M_xi_2d_tri,2,2);
		} 
		else if(4 == Grid.p_element[e].type)
		{
			Array_3d_double.New(Grid.p_element[e].p_dX_dxi_e,M_xi_2d_rec,2,2);
			Array_3d_double.New(Grid.p_element[e].p_dxi_dX_e,M_xi_2d_rec,2,2);
			
		}
	}
	
	for(e=0;e<Grid.num_e;e++)
	{
		if(3 == Grid.p_element[e].type)
		{
			for(j=0;j<M_xi_2d_tri;j++)
			{
				Grid.p_element[e].p_dX_dxi_e[j][0][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][0][1] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][1][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][1][1] = 0.0;
				
				Grid.p_element[e].p_dxi_dX_e[j][0][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][0][1] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][1][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][1][1] = 0.0;
			}
		}
		
		if(4 == Grid.p_element[e].type)
		{
			for(j=0;j<M_xi_2d_rec;j++)
			{
				Grid.p_element[e].p_dX_dxi_e[j][0][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][0][1] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][1][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_e[j][1][1] = 0.0;
				                  
				Grid.p_element[e].p_dxi_dX_e[j][0][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][0][1] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][1][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_e[j][1][1] = 0.0;
			}
		}
	}
	
	//p_dX_dxi_face(p_dxi_dX_face)
	for(e=0;e<Grid.num_e;e++)
	{
		k = Grid.p_element[e].type;
		 
		if(3 == k)
		{
			Array_4d_double.New(Grid.p_element[e].p_dX_dxi_face_in_e,
					k,M_xi_1d,2,2);
			Array_4d_double.New(Grid.p_element[e].p_dxi_dX_face_in_e,
					k,M_xi_1d,2,2);
		} 
		else if(4 == k)
		{
			Array_4d_double.New(Grid.p_element[e].p_dX_dxi_face_in_e,
					k,M_xi_1d,2,2);
			Array_4d_double.New(Grid.p_element[e].p_dxi_dX_face_in_e,
					k,M_xi_1d,2,2);
			
		}
	}
	
	for(e=0;e<Grid.num_e;e++)
	{
		t = Grid.p_element[e].type;
		 
		for(j=0;j<t;j++)
			for(k=0;k<M_xi_1d;k++)
			{
				Grid.p_element[e].p_dX_dxi_face_in_e[j][k][0][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_face_in_e[j][k][0][1] = 0.0;
				Grid.p_element[e].p_dX_dxi_face_in_e[j][k][1][0] = 0.0;
				Grid.p_element[e].p_dX_dxi_face_in_e[j][k][1][1] = 0.0;
				                  
				Grid.p_element[e].p_dxi_dX_face_in_e[j][k][0][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_face_in_e[j][k][0][1] = 0.0;
				Grid.p_element[e].p_dxi_dX_face_in_e[j][k][1][0] = 0.0;
				Grid.p_element[e].p_dxi_dX_face_in_e[j][k][1][1] = 0.0;
			}
		 
	}
	
	//det_J_e
	for(e=0;e<Grid.num_e;e++)
	{
		t = Grid.p_element[e].type;
		
		if(3 == t)
		{
			Grid.p_element[e].p_det_J_e = new double[M_xi_2d_tri];
		}
		 
		else if(4 == t)
		{
			Grid.p_element[e].p_det_J_e = new double[M_xi_2d_rec];
		}
	}
	
	for(e=0;e<Grid.num_e;e++)
	{
		t = Grid.p_element[e].type;
		
		if(3 == t)
		{
			for(j=0;j<M_xi_2d_tri;j++)
				Grid.p_element[e].p_det_J_e[j] = 0.0;
		}
		 
		else if(4 == t)
		{
			for(j=0;j<M_xi_2d_rec;j++)
				Grid.p_element[e].p_det_J_e[j] = 0.0;
		}
	}
	 
	//det_J_face
	for(face=0;face<Grid.num_face;face++)
	{
		Grid.p_face[face].p_det_J_face = new double[M_xi_1d];
	}
	
	for(face=0;face<Grid.num_face;face++)
	{
		for(j=0;j<M_xi_1d;j++)
			Grid.p_face[face].p_det_J_face[j] = Grid.p_face[face].Area*0.5;
	}
	
	
	//printf("MY_ID = %2d\n", my_id );
	
	//temp dX_dxi_face
	double** p_dX_dxi_face;
	double** p_dY_dxi_face;
	Array_2d_double.New(p_dX_dxi_face,Grid.num_face,M_xi_1d);
	Array_2d_double.New(p_dY_dxi_face,Grid.num_face,M_xi_1d);
	for(i=0;i<Grid.num_face;i++)
		for(j=0;j<M_xi_1d;j++)
		{
			p_dX_dxi_face[i][j] = 0.0;
			p_dY_dxi_face[i][j] = 0.0;
		}
	
	//=== points for test
	char fname[100];
	sprintf(fname,"test_curve/%s%d.grd","LINE_curve_", my_id);

	FILE* fp1 = fopen(fname,"w");
	
	double** p_t ;
	Array_2d_double.New(p_t,2,13);
	 
	double ** p_J_xi_X;
	Array_2d_double.New(p_J_xi_X,Grid.num_e,M_xi_2d_rec);
	
	//FILE*fp2 = fopen("LINE_plane.grd","w");
	//double x_plane=0.0,y_plane=0.0;
	
	//=============================
	//8 points in xi_plane for curve_grid
	p_xi_8[0][0] = -1.0;
	p_xi_8[1][0] = -1.0;
	p_xi_8[0][1] = -1.0/3;
	p_xi_8[1][1] = -1.0;
	p_xi_8[0][2] =  1.0/3;
	p_xi_8[1][2] = -1.0;
	p_xi_8[0][3] =  1.0;
	p_xi_8[1][3] = -1.0;
	 
	p_xi_8[0][4] =  1.0;
	p_xi_8[1][4] =  1.0;
	p_xi_8[0][5] =  1.0/3;
	p_xi_8[1][5] =  1.0;
	p_xi_8[0][6] = -1.0/3;
	p_xi_8[1][6] =  1.0;
	p_xi_8[0][7] = -1.0;
	p_xi_8[1][7] =  1.0;
	
	//4 points in xi_plane for straight_grid
	p_xi_4[0][0] = -1.0;
	p_xi_4[1][0] = -1.0;
	p_xi_4[0][1] =  1.0;
	p_xi_4[1][1] = -1.0; 
	p_xi_4[0][2] =  1.0;
	p_xi_4[1][2] =  1.0;
	p_xi_4[0][3] = -1.0;
	p_xi_4[1][3] =  1.0;
	 
	//===test points:
	p_t[0][0] = -1.0;
	p_t[1][0] = -1.0;
	p_t[0][1] = -1.0/3;
	p_t[1][1] = -1.0;
	p_t[0][2] =  1.0/3;
	p_t[1][2] = -1.0;
	p_t[0][3] =  1.0;
	p_t[1][3] = -1.0;
	p_t[0][4] =  1.0;
	p_t[1][4] = -1.0/3;
	p_t[0][5] =  1.0;
	p_t[1][5] =  1.0/3;
	p_t[0][6] =  1.0;
	p_t[1][6] =  1.0;
	
	p_t[0][7] =  1.0/3;
	p_t[1][7] =  1.0;
	p_t[0][8] = -1.0/3;
	p_t[1][8] =  1.0;
	p_t[0][9] = -1.0;
	p_t[1][9] =  1.0;
	p_t[0][10] =-1.0;
	p_t[1][10] = 1.0/3;
	p_t[0][11] =-1.0;
	p_t[1][11] =-1.0/3;
	
	p_t[0][12] =-1.0;
	p_t[1][12] =-1.0;
	
	//for triangles:
	//for triangle,det_J_e equals for different M_xi_2d quadrature_points 
	double x1,y1,x2,y2,x3,y3;
	double xi,yi;
	//TEST
	//FILE* fp2; 
	//char fname1[100];
	//sprintf(fname1,"checkgrid_%d.txt",my_id);
	//fp2 =  fopen(fname1,"w");
	//
	for(e=0;e<Grid.num_e;e++)
	{
		if(3 == Grid.p_element[e].type)
		{
			node1 = Grid.p_element[e].p_node[0];
			node2 = Grid.p_element[e].p_node[1];
			node3 = Grid.p_element[e].p_node[2];
			
			//node4 = Grid.p_element[e].p_node[3];
			 
			//if(node3!=node4)
			//{
			//	printf("==========================================\n");
			//	printf("========== Error in Cal_Jacobi.h ========\n");
			//	printf("========== Error in triangle =============\n");
			//	printf("==========================================\n");
			//	system("pause");
			//}
			//for dxi_dX
			x1 = Grid.p_node[node1].p_X[0];
			y1 = Grid.p_node[node1].p_X[1]; 
			x2 = Grid.p_node[node2].p_X[0];
			y2 = Grid.p_node[node2].p_X[1]; 
			x3 = Grid.p_node[node3].p_X[0];
			y3 = Grid.p_node[node3].p_X[1];
			 
			//write to file for test:
			fprintf(fp1,"4\n");
			fprintf(fp1,"%20.12f%20.12f%20.12f\n",x1,y1,0.0000);
			fprintf(fp1,"%20.12f%20.12f%20.12f\n",x2,y2,0.0000);
			fprintf(fp1,"%20.12f%20.12f%20.12f\n",x3,y3,0.0000);
			fprintf(fp1,"%20.12f%20.12f%20.12f\n",x1,y1,0.0000);
			
			//quadrature points:
			for(j=0;j<M_xi_2d_tri;j++)
			{
				Grid.p_element[e].p_dxi_dX_e[j][0][0] =  (2.0*y3-y1-y2)/(2.0*Grid.p_element[e].volume);          
				Grid.p_element[e].p_dxi_dX_e[j][0][1] = -(2.0*x3-x1-x2)/(2.0*Grid.p_element[e].volume);
				Grid.p_element[e].p_dxi_dX_e[j][1][0] = -sqrt(3.0)*(y2-y1)/(2.0*Grid.p_element[e].volume);
				Grid.p_element[e].p_dxi_dX_e[j][1][1] =  sqrt(3.0)*(x2-x1)/(2.0*Grid.p_element[e].volume);
				
				Grid.p_element[e].p_dX_dxi_e[j][0][0] = 0.5*(x2-x1);                    
				Grid.p_element[e].p_dX_dxi_e[j][1][0] = 0.5*(y2-y1);
				Grid.p_element[e].p_dX_dxi_e[j][0][1] = (0.5/sqrt(3.0))*(2.0*x3-x1-x2); 
				Grid.p_element[e].p_dX_dxi_e[j][1][1] = (0.5/sqrt(3.0))*(2.0*y3-y1-y2);  
				
				Grid.p_element[e].p_det_J_e[j] = Grid.p_element[e].p_dX_dxi_e[j][0][0]
						*Grid.p_element[e].p_dX_dxi_e[j][1][1] 
						-Grid.p_element[e].p_dX_dxi_e[j][0][1]
						*Grid.p_element[e].p_dX_dxi_e[j][1][0];
				//Grid.p_Det_J_e[i][j] = Grid.volume_e[i];
			}
			
			//quadrature points on face:
			for(j=0;j<3;j++)
				for(k=0;k<M_xi_1d;k++)
				{
					Grid.p_element[e].p_dX_dxi_face_in_e[j][k][0][0] = 0.5*(x2-x1);
					Grid.p_element[e].p_dX_dxi_face_in_e[j][k][1][0] = 0.5*(y2-y1);
					Grid.p_element[e].p_dX_dxi_face_in_e[j][k][0][1] = (0.5/sqrt(3.0))*(2.0*x3-x1-x2); 
					Grid.p_element[e].p_dX_dxi_face_in_e[j][k][1][1] = (0.5/sqrt(3.0))*(2.0*y3-y1-y2);
					
					Grid.p_element[e].p_dxi_dX_face_in_e[j][k][0][0] =  (2.0*y3-y1-y2)/(2.0*Grid.p_element[e].volume);   
					Grid.p_element[e].p_dxi_dX_face_in_e[j][k][0][1] = -(2.0*x3-x1-x2)/(2.0*Grid.p_element[e].volume);
					Grid.p_element[e].p_dxi_dX_face_in_e[j][k][1][0] = -sqrt(3.0)*(y2-y1)/(2.0*Grid.p_element[e].volume);
					Grid.p_element[e].p_dxi_dX_face_in_e[j][k][1][1] =  sqrt(3.0)*(x2-x1)/(2.0*Grid.p_element[e].volume);
				}
			
		}
		
		else if(4 == Grid.p_element[e].type)
		{
			node1 = Grid.p_element[e].p_node[0];
			node2 = Grid.p_element[e].p_node[1];
			node3 = Grid.p_element[e].p_node[2];
			node4 = Grid.p_element[e].p_node[3];
			if(node1==node2||node1==node3||node1==node4||
			   node2==node3||node2==node4||node3==node4)
			{
				printf("==========================================\n");
				printf("========== Error in Cal_Jacobi.h ========\n");
				printf("========== node equals!-->L707    ========\n");
				printf("==========================================\n");
				//system("pause");
			}
			
			if(-1 == Grid.p_element[e].cflag)
			{
				facet[0] = Grid.p_element[e].face_in_e_curve[0];
				facet[1] = Grid.p_element[e].face_in_e_curve[1];
				
				indext[0] = Grid.p_element[e].face_index_in_e_curve[0];
				indext[1] = Grid.p_element[e].face_index_in_e_curve[1];
				
				//printf("index_face0: %5d ,index_face1: %5d , face flag: %5d \n",indext[0], indext[1], 
				//		Grid.p_face[facet[0]].flag);
				//printf("node1: %5d ,node2: %5d , node3: %5d , node4: %5d \n", node1, node2, node3, node4); 
				//
				//printf("face0: node1: %5d ,node2: %5d \n", Grid.p_face[facet[0]].p_face[0],
				//		Grid.p_face[facet[0]].p_face[1]);  
				
				nx[0] = Grid.p_face[facet[0]].p_n_of_face[0];
				ny[0] = Grid.p_face[facet[0]].p_n_of_face[1];
				nx[1] = Grid.p_face[facet[1]].p_n_of_face[0];
				ny[1] = Grid.p_face[facet[1]].p_n_of_face[1];
				 
				signal = nx[0]*nx[1]+ny[0]*ny[1];
				
				if(-1 == Grid.p_face[facet[0]].cflag)
				{
					p_X_8[0][0] = Grid.p_face[facet[0]].p_node_on_edge[0][0];
					p_X_8[1][0] = Grid.p_face[facet[0]].p_node_on_edge[0][1];
					p_X_8[0][1] = Grid.p_face[facet[0]].p_node_on_edge[1][0];
					p_X_8[1][1] = Grid.p_face[facet[0]].p_node_on_edge[1][1];
					p_X_8[0][2] = Grid.p_face[facet[0]].p_node_on_edge[2][0];
					p_X_8[1][2] = Grid.p_face[facet[0]].p_node_on_edge[2][1];
					p_X_8[0][3] = Grid.p_face[facet[0]].p_node_on_edge[3][0];
					p_X_8[1][3] = Grid.p_face[facet[0]].p_node_on_edge[3][1];
					
					if(node1!=Grid.p_face[facet[0]].p_face[0] && 
					   node2!=Grid.p_face[facet[0]].p_face[0])
					{
						printf("====== ERROR in Curve_Solid.h ======\n");
						printf("=========  In line 816   ===========\n");
						printf("====================================\n");
						//system("pause");
					}
					 
					if(signal<0.0)
					{
						p_X_8[0][4] = Grid.p_face[facet[1]].p_node_on_edge[0][0];
						p_X_8[1][4] = Grid.p_face[facet[1]].p_node_on_edge[0][1];
						p_X_8[0][5] = Grid.p_face[facet[1]].p_node_on_edge[1][0];
						p_X_8[1][5] = Grid.p_face[facet[1]].p_node_on_edge[1][1];
						p_X_8[0][6] = Grid.p_face[facet[1]].p_node_on_edge[2][0];
						p_X_8[1][6] = Grid.p_face[facet[1]].p_node_on_edge[2][1];
						p_X_8[0][7] = Grid.p_face[facet[1]].p_node_on_edge[3][0];
						p_X_8[1][7] = Grid.p_face[facet[1]].p_node_on_edge[3][1];
						 
						if(node3!=Grid.p_face[facet[1]].p_face[0] && node4!=Grid.p_face[facet[1]].p_face[0])
						{
							printf("====== ERROR in Curve_Solid.h ======\n");
							printf("===========  In line 835  ==========\n");
							printf("====================================\n");
							//system("pause");
						}
					}
					
					else if(signal>=0.0)
					{
						p_X_8[0][4] = Grid.p_face[facet[1]].p_node_on_edge[3][0];
						p_X_8[1][4] = Grid.p_face[facet[1]].p_node_on_edge[3][1];
						p_X_8[0][5] = Grid.p_face[facet[1]].p_node_on_edge[2][0];
						p_X_8[1][5] = Grid.p_face[facet[1]].p_node_on_edge[2][1];
						p_X_8[0][6] = Grid.p_face[facet[1]].p_node_on_edge[1][0];
						p_X_8[1][6] = Grid.p_face[facet[1]].p_node_on_edge[1][1];
						p_X_8[0][7] = Grid.p_face[facet[1]].p_node_on_edge[0][0];
						p_X_8[1][7] = Grid.p_face[facet[1]].p_node_on_edge[0][1];
						 
						if(node3!=Grid.p_face[facet[1]].p_face[1] && node4!=Grid.p_face[facet[1]].p_face[1])
						{
							printf("====== ERROR in Curve_Solid.h ======\n");
							printf("==========  In line 855   ==========\n");
							printf("====================================\n");
							//system("pause");
						}
					}
					 
				}
				 
				else if(-2 == Grid.p_face[facet[0]].cflag)
				{
					p_X_8[0][0] = Grid.p_face[facet[0]].p_node_on_edge[3][0];
					p_X_8[1][0] = Grid.p_face[facet[0]].p_node_on_edge[3][1];
					p_X_8[0][1] = Grid.p_face[facet[0]].p_node_on_edge[2][0];
					p_X_8[1][1] = Grid.p_face[facet[0]].p_node_on_edge[2][1];
					p_X_8[0][2] = Grid.p_face[facet[0]].p_node_on_edge[1][0];
					p_X_8[1][2] = Grid.p_face[facet[0]].p_node_on_edge[1][1];
					p_X_8[0][3] = Grid.p_face[facet[0]].p_node_on_edge[0][0];
					p_X_8[1][3] = Grid.p_face[facet[0]].p_node_on_edge[0][1];
					 
					if(signal<0.0)
					{
						p_X_8[0][4] = Grid.p_face[facet[1]].p_node_on_edge[3][0];
						p_X_8[1][4] = Grid.p_face[facet[1]].p_node_on_edge[3][1];
						p_X_8[0][5] = Grid.p_face[facet[1]].p_node_on_edge[2][0];
						p_X_8[1][5] = Grid.p_face[facet[1]].p_node_on_edge[2][1];
						p_X_8[0][6] = Grid.p_face[facet[1]].p_node_on_edge[1][0];
						p_X_8[1][6] = Grid.p_face[facet[1]].p_node_on_edge[1][1];
						p_X_8[0][7] = Grid.p_face[facet[1]].p_node_on_edge[0][0];
						p_X_8[1][7] = Grid.p_face[facet[1]].p_node_on_edge[0][1];
					}
					
					else if(signal>=0.0)
					{
						p_X_8[0][4] = Grid.p_face[facet[1]].p_node_on_edge[0][0];
						p_X_8[1][4] = Grid.p_face[facet[1]].p_node_on_edge[0][1];
						p_X_8[0][5] = Grid.p_face[facet[1]].p_node_on_edge[1][0];
						p_X_8[1][5] = Grid.p_face[facet[1]].p_node_on_edge[1][1];
						p_X_8[0][6] = Grid.p_face[facet[1]].p_node_on_edge[2][0];
						p_X_8[1][6] = Grid.p_face[facet[1]].p_node_on_edge[2][1];
						p_X_8[0][7] = Grid.p_face[facet[1]].p_node_on_edge[3][0];
						p_X_8[1][7] = Grid.p_face[facet[1]].p_node_on_edge[3][1];
					}
				}
				
				Cal_trans_from_X_to_xi( p_xi_8[0], p_X_8[0], p_X_8[1],  Grid.p_element[e].p_a_to_xi_e);  //good         //kexi=a1+a2*Y+a3*Y*Y+......+a9*X*X*X   
				Cal_trans_from_X_to_xi( p_xi_8[1], p_X_8[0], p_X_8[1],  Grid.p_element[e].p_a_to_yi_e);          //yita=a1+a2*Y+a3*Y*Y+......+a9*X*X*X
				
				Cal_trans_from_X_to_xi( p_X_8[0], p_xi_8[0], p_xi_8[1],  Grid.p_element[e].p_a_to_X_e);          
				Cal_trans_from_X_to_xi( p_X_8[1], p_xi_8[0], p_xi_8[1],  Grid.p_element[e].p_a_to_Y_e);
				
				//=== write to file for test
				
				fprintf(fp1,"13\n");
				 
				for(j=0;j<13;j++)
				{    
					p_X_trans = 0.0;
					p_Y_trans = 0.0;
					
					//x_plane =0.0;
					//y_plane =0.0;
					
					Cal_P_polynomials(p_t[0][j],p_t[1][j],p_coef1);
					
					for(k=0;k<8;k++)
					{
						p_X_trans += Grid.p_element[e].p_a_to_X_e[k] * p_coef1[k];
						p_Y_trans += Grid.p_element[e].p_a_to_Y_e[k] * p_coef1[k];                     //to trans to computational domain
					}
					
					//Cal_P_polynomials(p_X_trans,p_Y_trans,p_coef1);
					
					//for(k=0;k<8;k++)
					//{
					//	x_plane += Grid.p_element[e].p_a_to_xi_e[k] * p_coef1[k];
					//	y_plane += Grid.p_element[e].p_a_to_yi_e[k] * p_coef1[k];
					//}
					
					//fprintf(fp2,"13\n");
					fprintf(fp1,"%20.12f%20.12f%20.12f\n",p_X_trans,p_Y_trans,0.0000);
					//fprintf(fp2,"%20.12f%20.12f%20.12f\n",x_plane,y_plane,0.0000);
				}
				//test over
				
				//det_J_e and dxi_dX_e
				for(j=0;j<M_xi_2d_rec;j++)
				{
					Cal_dP_dxi_polynomials(p_xi_2d_rec[j], p_yi_2d_rec[j], p_coef2);   
					Cal_dP_dyi_polynomials(p_xi_2d_rec[j], p_yi_2d_rec[j], p_coef3);
					
					for(t=0;t<8;t++)
					{
						Grid.p_element[e].p_dX_dxi_e[j][0][0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef2[t];
						Grid.p_element[e].p_dX_dxi_e[j][0][1] += Grid.p_element[e].p_a_to_X_e[t] * p_coef3[t];//
						Grid.p_element[e].p_dX_dxi_e[j][1][0] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef2[t];
						Grid.p_element[e].p_dX_dxi_e[j][1][1] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef3[t];// 
					}
					
					Grid.p_element[e].p_det_J_e[j] = Grid.p_element[e].p_dX_dxi_e[j][0][0]
													*Grid.p_element[e].p_dX_dxi_e[j][1][1] 
													-Grid.p_element[e].p_dX_dxi_e[j][0][1]
													*Grid.p_element[e].p_dX_dxi_e[j][1][0]; 
					
					//TEST
					//if(17 == Grid.p_e_master[e])
					//{
						//fprintf(fp2,"%10d\n",Grid.p_face_master[facet[1]]);
						//fprintf(fp2,"%10.5f\n",nx[1]);
						//fprintf(fp2,"%10.5f\n",ny[0]);
						//fprintf(fp2,"%10.5f\n",ny[1]);
						//fprintf(fp2,"\n");
						 
						//for(t=0;t<8;t++)
							//fprintf(fp2,"%15.10f%15.10f\n",p_X_8[0][t],p_X_8[1][t]);
						//fprintf(fp2,"\n");
						// 
						//for(t=0;t<8;t++)
							//fprintf(fp2,"%15.10f%15.10f\n",Grid.p_element[e].p_a_to_Y_e[t],p_coef2[t]);
						//fprintf(fp2,"\n");
						//p_X_8[0][4]
						//fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_det_J_e[j]);
					//}
					//
					if(Grid.p_element[e].p_det_J_e[j]<=0.0)
					{
						printf("==========================================\n");
						printf("========== Error in Cal_Jacobi.h ========\n");
						printf("========== e=%4d,M_xi=%4d ================\n",i,j);
						printf("============ det_J_e is %20.8f ===========\n",Grid.p_element[e].p_det_J_e[j]);
						printf("==========================================\n");
						//system("pause");
					}
					
					Grid.p_element[e].p_dxi_dX_e[j][0][0] =  Grid.p_element[e].p_dX_dxi_e[j][1][1]/Grid.p_element[e].p_det_J_e[j];  //    dxi/dX
					Grid.p_element[e].p_dxi_dX_e[j][0][1] = -Grid.p_element[e].p_dX_dxi_e[j][0][1]/Grid.p_element[e].p_det_J_e[j];  //    dxi/aY
					Grid.p_element[e].p_dxi_dX_e[j][1][0] = -Grid.p_element[e].p_dX_dxi_e[j][1][0]/Grid.p_element[e].p_det_J_e[j];  //    dyi/dX
					Grid.p_element[e].p_dxi_dX_e[j][1][1] =  Grid.p_element[e].p_dX_dxi_e[j][0][0]/Grid.p_element[e].p_det_J_e[j];  //    dyi/dY
					
					//TEST
					/*
					if(17 == Grid.p_e_master[e])
					{
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dX_dxi_e[j][0][0]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dX_dxi_e[j][0][1]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dX_dxi_e[j][1][0]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dX_dxi_e[j][1][1]);
						fprintf(fp2,"\n");
					}
					//
					//TEST
					if(17 == Grid.p_e_master[e])
					{
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dxi_dX_e[j][0][0]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dxi_dX_e[j][0][1]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dxi_dX_e[j][1][0]);
						fprintf(fp2,"%10.6f\n",Grid.p_element[e].p_dxi_dX_e[j][1][1]);
						fprintf(fp2,"\n");
					}
					//
					*/
					p_J_xi_X[e][j] = Grid.p_element[e].p_dxi_dX_e[j][0][0] * Grid.p_element[e].p_dxi_dX_e[j][1][1] 
									-Grid.p_element[e].p_dxi_dX_e[j][0][1] * Grid.p_element[e].p_dxi_dX_e[j][1][0];
					
					if(p_J_xi_X[e][j]<=0.0)
					{
						printf("==========================================\n");
						printf("========== Error in Cal_Jacobi.h ========\n");
						printf("========== det_(-1)J_e is %10.3f =========\n",p_J_xi_X[e][j]);
						printf("==========================================\n");
					}
				}
				
				//====================
				//Grid.p_dxi_dX_face
				for(j=0;j<4;j++)
				{
					//face = Grid.p_face_e[i][j];
					
					for(ii=0;ii<M_xi_1d;ii++)
					{
						if(0 == j)
						{
							xi = 1.0;
							yi = p_xi_1d[ii];
						}
						
						if(1 == j)
						{
							xi = -p_xi_1d[ii];
							yi = 1.0;
						}
							
						if(2 == j)
						{
							xi = -1.0;
							yi = -p_xi_1d[ii];
						}
						
						if(3 == j)
						{
							xi = p_xi_1d[ii];
							yi = -1.0;
						}
						
						Cal_dP_dxi_polynomials(xi, yi, p_coef2); //here   
						Cal_dP_dyi_polynomials(xi, yi, p_coef3);
						
						/*  
						Grid.p_dX_dxi_face[i][j][ii][0][0] = 0.0;
						Grid.p_dX_dxi_face[i][j][ii][0][1] = 0.0;
						Grid.p_dX_dxi_face[i][j][ii][1][0] = 0.0;
						Grid.p_dX_dxi_face[i][j][ii][1][1] = 0.0;
						Grid.p_dxi_dX_face[i][j][ii][0][0] = 0.0;
						Grid.p_dxi_dX_face[i][j][ii][0][1] = 0.0;
						Grid.p_dxi_dX_face[i][j][ii][1][0] = 0.0;
						Grid.p_dxi_dX_face[i][j][ii][1][1] = 0.0;
						*/
						 
						for(t=0;t<8;t++)
						{
							Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0] += Grid.p_element[e].p_a_to_X_e[t] * p_coef2[t];
							Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1] += Grid.p_element[e].p_a_to_X_e[t] * p_coef3[t];//
							Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef2[t];
							Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef3[t];// 
						}
						
						J_face = Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0]*Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1]-
						         Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1]*Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0]; 
						
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][0] =  Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1]/J_face;  //    dxi/dX
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][1] = -Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1]/J_face;  //    dxi/aY
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][0] = -Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0]/J_face;  //    dyi/dX
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][1] =  Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0]/J_face;  //    dyi/dY
					}
				}
				 
				//Grid.p_det_J_face
				for(j=0;j<M_xi_1d;j++)
				{
					//set all zero:   
					//because middle-edge used twice
					p_dX_dxi_face[facet[0]][j] = 0.0;
					p_dY_dxi_face[facet[0]][j] = 0.0;
					p_dX_dxi_face[facet[1]][j] = 0.0;
					p_dY_dxi_face[facet[1]][j] = 0.0;
					
					//here direction!!!
					//first_face+second_face
					if(-1 == Grid.p_face[facet[0]].cflag)
					{
						Cal_dP_dxi_polynomials(p_xi_1d[j], -1.0, p_coef1);
						 
						if(signal<0.0)
						{
							Cal_dP_dxi_polynomials(-p_xi_1d[j], 1.0, p_coef2);
						}
						else if(signal>0.0)
						{
							Cal_dP_dxi_polynomials( p_xi_1d[j], 1.0, p_coef2);
						}
					}
					 
					else if(-2 == Grid.p_face[facet[0]].cflag)
					{
						Cal_dP_dxi_polynomials(-p_xi_1d[j], -1.0, p_coef1);
						 
						if(signal<0.0)
						{
							Cal_dP_dxi_polynomials( p_xi_1d[j], 1.0, p_coef2);
						}
						else if(signal>0.0)
						{
							Cal_dP_dxi_polynomials( -p_xi_1d[j], 1.0, p_coef2);
						}
					}
					 
					for(t=0;t<8;t++)
					{
						p_dX_dxi_face[facet[0]][j] += Grid.p_element[e].p_a_to_X_e[t] * p_coef1[t];
						p_dY_dxi_face[facet[0]][j] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef1[t];
						p_dX_dxi_face[facet[1]][j] += Grid.p_element[e].p_a_to_X_e[t] * p_coef2[t];
						p_dY_dxi_face[facet[1]][j] += Grid.p_element[e].p_a_to_Y_e[t] * p_coef2[t];
					}
					 
					Grid.p_face[facet[0]].p_det_J_face[j] = sqrt(p_dX_dxi_face[facet[0]][j]*p_dX_dxi_face[facet[0]][j]
					                              +p_dY_dxi_face[facet[0]][j]*p_dY_dxi_face[facet[0]][j]);
					 
					Grid.p_face[facet[1]].p_det_J_face[j] = sqrt(p_dX_dxi_face[facet[1]][j]*p_dX_dxi_face[facet[1]][j]
					                              +p_dY_dxi_face[facet[1]][j]*p_dY_dxi_face[facet[1]][j]);
					
				}
				 
			}
			
			else if(0 == Grid.p_element[e].cflag)
			{
				p_X_4[0][0] = Grid.p_node[node1].p_X[0];
				p_X_4[1][0] = Grid.p_node[node1].p_X[1];
				p_X_4[0][1] = Grid.p_node[node2].p_X[0];
				p_X_4[1][1] = Grid.p_node[node2].p_X[1];
				p_X_4[0][2] = Grid.p_node[node3].p_X[0];
				p_X_4[1][2] = Grid.p_node[node3].p_X[1];
				p_X_4[0][3] = Grid.p_node[node4].p_X[0];
				p_X_4[1][3] = Grid.p_node[node4].p_X[1];
				
				Cal_trans_from_X_to_X_4(p_X_4[0],p_xi_4[0],p_xi_4[1],p_bx);
				Cal_trans_from_X_to_X_4(p_X_4[1],p_xi_4[0],p_xi_4[1],p_by);
				
				//write to file for test
				
				fprintf(fp1,"13\n");
				
				for(j=0;j<13;j++)
				{    
					p_X_trans = p_bx[0] + p_bx[1]*p_t[0][j] + p_bx[2]*p_t[1][j] + p_bx[3]*p_t[0][j]*p_t[1][j];
					p_Y_trans = p_by[0] + p_by[1]*p_t[0][j] + p_by[2]*p_t[1][j] + p_by[3]*p_t[0][j]*p_t[1][j]; 
					
					//to trans to computational domain
					fprintf(fp1,"%20.12f%20.12f%20.12f\n",p_X_trans,p_Y_trans,0.000000000000);
					
					//x_plane  = p_ax[0] + p_ax[1]*p_X_trans + p_ax[2]*p_X_trans*p_X_trans + p_ax[3]*p_Y_trans + p_ax[4]*p_X_trans*p_Y_trans + p_ax[5]*p_Y_trans*p_Y_trans;
					//y_plane  = p_ay[0] + p_ay[1]*p_X_trans + p_ay[2]*p_X_trans*p_X_trans + p_ay[3]*p_Y_trans + p_ay[4]*p_X_trans*p_Y_trans + p_ay[5]*p_Y_trans*p_Y_trans;
					//fprintf(fp02,"%20.5f%20.5f%20.5f\n",x_plane,y_plane,0.0000);
				}
				//over
				
				//det_J_e
				for(j=0;j<M_xi_2d_rec;j++)
				{
					Grid.p_element[e].p_dX_dxi_e[j][0][0] = p_bx[1] + p_bx[3]*p_yi_2d_rec[j];
					Grid.p_element[e].p_dX_dxi_e[j][0][1] = p_bx[2] + p_bx[3]*p_xi_2d_rec[j];
					Grid.p_element[e].p_dX_dxi_e[j][1][0] = p_by[1] + p_by[3]*p_yi_2d_rec[j];
					Grid.p_element[e].p_dX_dxi_e[j][1][1] = p_by[2] + p_by[3]*p_xi_2d_rec[j];
					
					Grid.p_element[e].p_det_J_e[j] = Grid.p_element[e].p_dX_dxi_e[j][0][0] 
													*Grid.p_element[e].p_dX_dxi_e[j][1][1] 
													-Grid.p_element[e].p_dX_dxi_e[j][0][1]
													*Grid.p_element[e].p_dX_dxi_e[j][1][0];
					
					if(Grid.p_element[e].p_det_J_e[j]<=0.0)
					{
						printf("==========================================\n");
						printf("========== Error in Curve_solid.h ========\n");
						printf("============ det_J_e is %10.3f ===========\n",Grid.p_element[e].p_det_J_e[j]);
						printf("==========================================\n");
						system("pause");
					}
					
					Grid.p_element[e].p_dxi_dX_e[j][0][0] =  Grid.p_element[e].p_dX_dxi_e[j][1][1] /Grid.p_element[e].p_det_J_e[j];
					Grid.p_element[e].p_dxi_dX_e[j][0][1] = -Grid.p_element[e].p_dX_dxi_e[j][0][1] /Grid.p_element[e].p_det_J_e[j];
					Grid.p_element[e].p_dxi_dX_e[j][1][0] = -Grid.p_element[e].p_dX_dxi_e[j][1][0] /Grid.p_element[e].p_det_J_e[j];
					Grid.p_element[e].p_dxi_dX_e[j][1][1] =  Grid.p_element[e].p_dX_dxi_e[j][0][0] /Grid.p_element[e].p_det_J_e[j];
					
					p_J_xi_X[e][j] = Grid.p_element[e].p_dxi_dX_e[j][0][0] 
									*Grid.p_element[e].p_dxi_dX_e[j][1][1] 
									-Grid.p_element[e].p_dxi_dX_e[j][0][1] 
									*Grid.p_element[e].p_dxi_dX_e[j][1][0];
					
					if(p_J_xi_X[e][j]<=0.0)
					{
						printf("==========================================\n");
						printf("========== Error in Curve_solid.h ========\n");
						printf("========== Det_(-1)J_e is %10.3f =========\n",p_J_xi_X[e][j]);
						printf("==========================================\n");
					}
				}
				
				for(j=0;j<4;j++)
				{
					//face = Grid.p_face_e[i][j];
					
					for(ii=0;ii<M_xi_1d;ii++)
					{
						if(0 == j) 
						{
							xi = 1.0;
							yi = p_xi_1d[ii];
						}
							
						if(1 == j)
						{
							xi = -p_xi_1d[ii];
							yi = 1.0;
						}
							
						if(2 == j)
						{
							xi = -1.0;
							yi = -p_xi_1d[ii];
						}
						
						if(3 == j)
						{
							xi = p_xi_1d[ii];
							yi = -1.0;
						}
						
						/*   
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0] = 0.0;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1] = 0.0;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0] = 0.0;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1] = 0.0;
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][0] = 0.0;
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][1] = 0.0;
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][0] = 0.0;
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][1] = 0.0;
						*/
						 
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0] += p_bx[1] + p_bx[3]*yi;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1] += p_bx[2] + p_bx[3]*xi;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0] += p_by[1] + p_by[3]*yi;
						Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1] += p_by[2] + p_by[3]*xi;
						
						J_face = Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0]
								*Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1]
								-Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1]
								*Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0]; 
						
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][0] =  Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][1]/J_face;  //    dxi/dX
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][0][1] = -Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][1]/J_face;  //    dxi/aY
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][0] = -Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][1][0]/J_face;  //    dyi/dX
						Grid.p_element[e].p_dxi_dX_face_in_e[j][ii][1][1] =  Grid.p_element[e].p_dX_dxi_face_in_e[j][ii][0][0]/J_face;  //    dyi/dY
					}
				}
				
			}
		}
		
	}
	
	//free space
	Array_2d_double.Delete(p_X_8,2,8);
	Array_2d_double.Delete(p_xi_8,2,8);
	
	Array_2d_double.Delete(p_xi_4,2,4);
	Array_2d_double.Delete(p_X_4,2,4);
	
	Array_2d_double.Delete(p_t,2,12);
	 
	delete []p_coef1 ;
	delete []p_coef2 ;
	delete []p_coef3 ;
	
	delete []p_bx;
	delete []p_by;
	
	fclose(fp1);
	//fclose(fp2);
	
	Array_2d_double.Delete(p_dX_dxi_face,Grid.num_face,M_xi_1d);
	Array_2d_double.Delete(p_dY_dxi_face,Grid.num_face,M_xi_1d);
	Array_2d_double.Delete(p_J_xi_X,Grid.num_e,M_xi_2d_rec);
	
}
 

void Cal_P_polynomials(double xi, double yi, double*& p_A_row)
{
	p_A_row[0] = 1.0;
	p_A_row[1] = xi;
	p_A_row[2] = xi * xi;
	p_A_row[3] = xi * xi * xi;
	p_A_row[4] = yi ;
	p_A_row[5] = xi * yi;
	p_A_row[6] = xi * xi * yi;
	p_A_row[7] = xi * xi * xi * yi;
}

void Cal_dP_dxi_polynomials(double xi, double yi, double*& p_A_row)
{
	p_A_row[0] = 0.0;
	p_A_row[1] = 1.0;
	p_A_row[2] = 2.0 * xi;
	p_A_row[3] = 3.0 * xi * xi;
	p_A_row[4] = 0.0;
	p_A_row[5] =  yi;
	p_A_row[6] = 2.0 * xi * yi;
	p_A_row[7] = 3.0 * xi * xi * yi;
}

void Cal_dP_dyi_polynomials(double xi, double yi, double*& p_A_row)
{
	p_A_row[0] = 0.0;
	p_A_row[1] = 0.0;
	p_A_row[2] = 0.0;
	p_A_row[3] = 0.0;
	p_A_row[4] = 1.0;
	p_A_row[5] =  xi;
	p_A_row[6] =  xi * xi;
	p_A_row[7] =  xi * xi * xi;
}

void Cal_trans_from_X_to_X_4(double* p_xi, double* p_X, double* p_Y, double*& p_a)
{
	int i;
	int M = 4;
	double** p_A;
	Array_2d_double.New(p_A, M, M);
	
	for(i=0;i<M;i++)
	{
		p_A[i][0] = 1;
		p_A[i][1] = p_X[i];
		p_A[i][2] = p_Y[i];
		p_A[i][3] = p_X[i] * p_Y[i];
	}
	Gaussian_elim(M, p_A, p_xi, p_a);
	
	Array_2d_double.Delete(p_A, M, M);
}

void Cal_trans_from_X_to_xi(double* p_xi, double* p_X, double* p_Y, double*& p_a)
{
	// to Cal p_a which satisfies: xi = sum_{i=0}^{N} sum_{j=0}^{N-i} sum_{k=0}^{N-i-j} p_a_{i,j,k} * X^{i} * Y^{j} * Z^{k}
	// as above
	
	int i,j,I,J;
	int M = 8;
	int N = 2;
	
	double** p_A;
	Array_2d_double.New(p_A, M, M);
	
	for(I=0; I<M; I++)
	{
		J = 0;
		for(j=0; j<N; j++)
		{
			for(i=0; i<=3; i++)
			{
				
				p_A[I][J] = pow(p_X[I], i) * 
						    pow(p_Y[I], j) ;
					J = J + 1;
			}
		}
	}
	 
	Gaussian_elim(M, p_A, p_xi, p_a);
	
	Array_2d_double.Delete(p_A, M, M);
}

void Cal_coeffi(double* X,double* Y,double alpha,double beta,
           double* p_X,double* p_Y,double* p_NX,double* p_NY)
{
	 //printf("=========alpha=%7.3f ======== beta=%7.3f =======",alpha,beta);
	
	double delx = X[1]-X[0];
	double dely = Y[1]-Y[0];
	double    L = sqrt(delx*delx+dely*dely);
		   //delx = delx/L;
		   //dely = dely/L;
	//=== coeffi of curve_line
	p_X[0] = 27.0/2*(alpha-beta)*dely/L;
	p_X[1] = (18.0*beta-45.0/2*alpha)*dely/L;
	p_X[2] = delx+9.0*(alpha-0.5*beta)*dely/L;
	p_X[3] = X[0];
	 
	p_Y[0] = -27.0/2*(alpha-beta)*delx/L;
	p_Y[1] = -(18.0*beta-45.0/2*alpha)*delx/L;
	p_Y[2] = dely-9.0*(alpha-0.5*beta)*delx/L;
	p_Y[3] = Y[0];
	//=== coeffi of normal_vector:
	p_NX[0] = 3.0*p_Y[0];//3*Grid.Y_face[face][0];
	p_NX[1] = 2.0*p_Y[1];//2*Grid.Y_face[face][1];
	p_NX[2] = p_Y[2];   //Grid.Y_face[face][2];
	//==============================
	p_NY[0] = -3.0*p_X[0];//-3*Grid.X_face[face][0];
	p_NY[1] = -2.0*p_X[1];//-2*Grid.X_face[face][1];
	p_NY[2] = -p_X[2];    //-Grid.X_face[face][2];
}
