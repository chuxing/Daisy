/*
 * =====================================================================================
 *
 *       Filename:  Basis_function.h
 *
 *    Description:  Basis function for tri and quad
 *
 *        Version:  1.0
 *        Created:  04/11/13 15:48:06
 *       Revision:  V1
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

//#include"dg.h"
void Init_element_reference(Basis_rectangle& Basis_rectangle
                           ,Basis_triangle & Basis_triangle)
{
	int ii,i;
	
	Array_2d_double.New(p_N0_element_rec, M_xi_2d_rec, M_Ni_MAX);
	Array_3d_double.New(p_N1_element_rec, M_xi_2d_rec, M_Ni_MAX, 2);
	
	Array_2d_double.New(p_N0_element_tri, M_xi_2d_tri, M_Ni_MAX);
	Array_3d_double.New(p_N1_element_tri, M_xi_2d_tri, M_Ni_MAX, 2);
	
	//rec:
	for(ii=0; ii<M_xi_2d_rec; ii++)               
	{
		Basis_rectangle.Ni_xy(p_xi_2d_rec[ii],p_yi_2d_rec[ii]);
		for(i=0; i<M_Ni_MAX; i++)
		{
			p_N0_element_rec[ii][i]    = Basis_rectangle.p_N0[i];
			p_N1_element_rec[ii][i][0] = Basis_rectangle.p_N1_1[i];
			p_N1_element_rec[ii][i][1] = Basis_rectangle.p_N1_2[i];
		}
	}
	
	//tri:
	for(ii=0; ii<M_xi_2d_tri; ii++)               
	{
		Basis_triangle.Ni_xy(p_xi_2d_tri[ii],p_yi_2d_tri[ii]);
		for(i=0; i<M_Ni_MAX; i++)
		{
			p_N0_element_tri[ii][i]    = Basis_triangle.p_N0[i];
			p_N1_element_tri[ii][i][0] = Basis_triangle.p_N1_1[i];
			p_N1_element_tri[ii][i][1] = Basis_triangle.p_N1_2[i];
		}
	}
	//------------------------------------------------------------------------------------------
}

void Init_face_reference(Basis_rectangle& Basis_rectangle
                        ,Basis_triangle & Basis_triangle)       
{
	int i,ii,k_face;
	double xi,yi;//L_1,L_2,L_3,L_4;
	
	//rec:
	Array_3d_double.New(p_N0_face_rec,4,M_xi_1d,M_Ni_MAX);
	Array_4d_double.New(p_N1_face_rec,4,M_xi_1d,M_Ni_MAX,2); 
	/*
	p_L1_1d_rec = new double[M_xi_1d];
	p_L2_1d_rec = new double[M_xi_1d];
	p_L3_1d_rec = new double[M_xi_1d];
	p_L4_1d_rec = new double[M_xi_1d];
	*/
	//-------------------------------------------------------------
	for(ii=0; ii<M_xi_1d; ii++)
	{
		//-----------------------------------------
		for(k_face=0;k_face<4;k_face++)                     
		{
			if(0 == k_face) 
			{
				xi = 1.0;
				yi = p_xi_1d[ii];
			}
			
			if(1 == k_face)
			{
				xi = -p_xi_1d[ii];
				yi = 1.0;
			}
			
			if(2 == k_face)
			{
				xi = -1.0;
				yi = -p_xi_1d[ii];
			}
			
			if(3 == k_face)
			{
				xi = p_xi_1d[ii];
				yi = -1.0;
			}
			//---------------------------
			Basis_rectangle.Ni_xy(xi,yi);
			
			for(i=0; i<M_Ni_MAX; i++)
			{
				p_N0_face_rec[k_face][ii][i]    = Basis_rectangle.p_N0[i];
				p_N1_face_rec[k_face][ii][i][0] = Basis_rectangle.p_N1_1[i];
				p_N1_face_rec[k_face][ii][i][1] = Basis_rectangle.p_N1_2[i];
			}
		}
	}
	
	//tri:
	Array_3d_double.New(p_N0_face_tri,3,M_xi_1d,M_Ni_MAX);
	Array_4d_double.New(p_N1_face_tri,3,M_xi_1d,M_Ni_MAX,2); 
	/*
	p_L1_1d_tri = new double[M_xi_1d];
	p_L2_1d_tri = new double[M_xi_1d];
	p_L3_1d_tri = new double[M_xi_1d];
	*/
	//--------------------------------
	for(ii=0; ii<M_xi_1d; ii++)
	{
		//----------------------------
		for(k_face=0;k_face<3;k_face++)                     
		{
			if(0 == k_face) 
			{
				xi = -0.5*p_xi_1d[ii]+0.5;
				yi = sqrt(3.0)*0.5*(p_xi_1d[ii]+1.0);
			}
			if(1 == k_face)
			{
				xi = -0.5*(p_xi_1d[ii]+1.0);
				yi = sqrt(3.0)*0.5*(1.0-p_xi_1d[ii]);
			}
			if(2 == k_face)
			{
				xi = p_xi_1d[ii];
				yi = 0.0;
			}
			//---------------------------
			Basis_triangle.Ni_xy(xi,yi);
			
			for(i=0; i<M_Ni_MAX; i++)
			{
				p_N0_face_tri[k_face][ii][i]    = Basis_triangle.p_N0[i];
				p_N1_face_tri[k_face][ii][i][0] = Basis_triangle.p_N1_1[i];
				p_N1_face_tri[k_face][ii][i][1] = Basis_triangle.p_N1_2[i];
			}
		}
		
	}
	//tri over 
	
}


