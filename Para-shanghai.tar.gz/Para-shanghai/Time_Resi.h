//#include"dg.h"
void Time_Resi(int my_id)
{
	char fname[500];
	sprintf(fname,"%s%d.txt","output_data/OUTPUT_Time_p", ORDER_U);
	FILE *fp = fopen(fname,"w");
	fprintf(fp,"%10d%10.6f\n",ORDER_U,wall_time);
	fprintf(fp,"\n");
	fclose(fp);
	//
	int i;
	char fname1[500];
	sprintf(fname1,"%s%d.plt","output_data/OUTPUT_Resi_p", ORDER_U);
	fp = fopen(fname1,"w");
	fprintf(fp,"%s\n","Title = \"Residual\" ");
	fprintf(fp,"%s\n","Variables= \"timestep\",\"residual\" ");
	 
	fprintf(fp,"%s%5d","Zone T=\"resi_all\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=Red");
	//fprintf(fp,"%10d\n",ORDER_U);
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[0][i]);
	/* 
	fprintf(fp,"%s%5d","Zone T=\"residual_rho\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=Red");
	//fprintf(fp,"%10d\n",ORDER_U);
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[1][i]);
	
	fprintf(fp,"%s%5d","Zone T=\"residual_u\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=blue");
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[2][i]);
	 
		fprintf(fp,"%s%5d","Zone T=\"residual_v\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=blue");
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[3][i]);
	 
		fprintf(fp,"%s%5d","Zone T=\"residual_e\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=blue");
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[4][i]);
	*/
	/*
		fprintf(fp,"%s%5d","Zone T=\"residual_k\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=blue");
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[i][4]);
	 
		fprintf(fp,"%s%5d","Zone T=\"residual_w\",I=",ACT_ITER);
	fprintf(fp,"%s\n",",F=POINT, C=blue");
	for(i=0;i<ACT_ITER;i++)
		fprintf(fp,"%6d%16.10f\n",i,Resi_R[i][5]);
	*/ 
	fclose(fp);
}
