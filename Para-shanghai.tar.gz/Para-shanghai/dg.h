#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "mpi.h"
#include "p_mmap.h"
//#include "lis.h"

//using namespace std;
//*****************
//*****************
#include"Array_multi.h"
#include"Structs.h"
#include"Defs.h"
#include"Basis_rectangle.h"
#include"Basis_triangle.h"
#include"Proto.h"
#include"Parameter.h"

#include"Linear_Algebriac.h"
//#include"Liftor.h"
//#include"LiftS.h"
#include"Basis_function.h"
//#include"Block_GS.h"
//#include"LISGMRES.h"
//#include"Pmgmres.h"
//#include"Curved_solid.h"
//#include"Coeff.h"
//#include"Discretization.h"
//#include"DL_DU.h"
//#include"Mgmres.h"
#include"Grid_general.h"
#include"Init_para.h"
#include"Init_quadrature.h"
#include"Newton_Iter.h"
#include"Output.h"
#include"Parallelization.h"
#include"Relations.h"
//#include"Runge_Kutta.h"
//#include"Test.h"
//#include"BDF2.h"
//#include"IRK2.h"
//#include"IRK3.h"
//#include"Time_Resi.h"
