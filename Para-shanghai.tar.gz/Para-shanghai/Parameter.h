//====================================
//========  parameters  ====
//====================================
#include<math.h>
//====================================


//*************************************************************************
//
//                Parameter you could change
//
//***************************************************************************
const int    MAX_ITER    = 30;                   //max iteration numbers
const int    sleep_time  = 1;                        // sleep time of every interations(seconds)
const int    Gap_of_output =2;                  //output tecplot file every gap step


//*********  Parameters you can't change **********************************
int file_write_time = 0;
int file_read_time = 0;
int pcm_write_time = 0;
int pcm_read_time = 0;

double PI          = 2.0*asin(1.0);
//***********************
   int Dimen       = 2;
   int Num_U       = 4;

   int Num_Curlay  = 5;//8;   //Curve_March
   int FLAG_Euler  = 1;

int Iter = 0;


double MACH_inf    = 0.20;//0.15;//0.734;
double RE_inf      = 3000000.0;//5000000;//1850000;//3130000;//6500000.0;


double ALPHA       = 0.0;//10.0;//3.4;//2.79;
double Beta        = 0.0;
   int Wall_Type   = 0;

//partition parameters:
int NUM_PARTITION;
int NUM_ELEMENT_TOTAL;
int NUM_FACE_TOTAL;
                            //+Trans Infor
PARA_SEND*   p_para_send;	// [num_partition_neighbouring]
PARA_RECV*   p_para_recv;	// [num_partition_neighbouring]

//high-order DG parameters
int ORDER_U        = 1;
int FLAG_CONTINUE  = 0;

int FLAG_FLUXe     = 0;
int FLAG_FLUXv     = 0;

int FLAG_Turb      = 0;
int FLAG_TModel    = 0;

//K-W model:
double Tu_far      = 0.01;
double Ru_far      = 0.1;
double DelY        = 0.00003;//0.0001;
//S-A model:
double Nut_far     = 0.01;

//non_dimensional values
double RHO_inf     = 1.0;
double T_inf       = 1.0;
double P_inf       = 1.0/GAMMA*RHO_inf*T_inf;
double C_inf       = sqrt(T_inf);
double FACTOR      = MACH_inf/RE_inf;
double FACTOR_shock= 0.0;
double factor_edge = 1.0;
double factor_ele  = 1.0;

//shock_para:
int FLAG_Laprho    = 0;
double     Lapk    = 4.0;

int    ACT_ITER;

//GMRES_parameter
//int    MR = 10;
//int    Iter_GMRES = 30;
//===========================
//parameter_curve
double Crate = 1.0;
//Output
int N_OUTPUT = 5;
time_t start,end;
double cost;
double wall_time;

//Other_parameters
int ORDER_MAX;
int ORDER_QUADRATURE_1D =  ORDER_U; //2*N+1

int M_Ni_U;
int M_Ni_MAX;

int* p_M_Ni;

int M_xi_1d;       //for quadrature
double* p_xi_1d;   //order_quadrature_1d
double* p_wi_1d;

//rec:
int M_xi_2d_rec;
double* p_xi_2d_rec;  //order_quadrature_2d
double* p_yi_2d_rec;
double* p_wi_2d_rec;

double* p_L1_2d_rec;
double* p_L2_2d_rec;
double* p_L3_2d_rec;
double* p_L4_2d_rec;
//tri:
int M_xi_2d_tri;
double* p_xi_2d_tri;
double* p_yi_2d_tri;
double* p_wi_2d_tri;

double* p_L1_2d_tri;
double* p_L2_2d_tri;
double* p_L3_2d_tri;

//rec
double**  p_N0_element_rec;   //[M_xi_2d][M_Ni_Max]
double*** p_N1_element_rec;   //[M_xi_2d][M_Ni_Max][2]

double***  p_N0_face_rec;     //[face/index_rotating][M_xi_1d][M_Ni_Max]
double**** p_N1_face_rec;     //[face/index_rotating][M_xi_1d][M_Ni_Max][2]

//tri
double**  p_N0_element_tri;   //[M_xi_2d][M_Ni_Max]
double*** p_N1_element_tri;   //[M_xi_2d][M_Ni_Max][2]

double***  p_N0_face_tri;     //[face/index_rotating][M_xi_1d][M_Ni_Max]
double**** p_N1_face_tri;

double*** p_M;            //[e][M_Ni_U][M_Ni_U]
double*** p_M_1;
