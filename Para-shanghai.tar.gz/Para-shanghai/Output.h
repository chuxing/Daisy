/*
 * =====================================================================================
 *
 *       Filename:  Output2.h
 *
 *    Description:  output tecplot data on hybrid mesh and output saved data
 *
 *        Version:  1.0
 *        Created:  25/02/14 17:08:06
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */


//#include"dg.h"
#define _BSD_SOURCE

#include <sys/time.h>

void Output_Interface_mix(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,
                          Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle)
{
	FILE *op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "!");
	fclose(op1);
	FILE *op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "!");
	fclose(op2);

	//*** first_part:quadraterial:
	int i,j,k,t;
	double* p_coef1 = new double [8];   //for curved
	double** p_node_flat;        // [16][2]
	double*** p_node_real;       // [Grid.num_e][16][2]
	double** p_N0;              //  [16][M_Ni_U]
	double*** p_U;             //   [Grid.num_e][16][5]

	int N0 = N_OUTPUT;
	int Ne_rec = (N0-1)*(N0-1);           //NUMber of elements
	int Np_rec = N0*N0;     //NUMber of points
	int Ne_tri = (N0-1)*(N0-1);
	int Np_tri = (1+N0)*N0/2;
	int node1,node2,node3,node4;
	double rho,u,v,p,ma,c;
	double cv1 = 7.1;
	double Xt,fv1;
	double kine,w;
	double nut,mu,mut=0.0;
	//double* temp0,*temp1;
	Array_2d_double.New(p_node_flat,Np_rec,2);

	Array_3d_double.New(p_node_real,Grid.num_e,Np_rec,2);
	for(i=0;i<Grid.num_e;i++)
		for(j=0;j<Np_rec;j++)
			{
				p_node_real[i][j][0] = 0.0;
				p_node_real[i][j][1] = 0.0;
			}

	Array_2d_double.New(p_N0,Np_rec,M_Ni_MAX);

	Array_3d_double.New(p_U,Grid.num_e,Np_rec,Num_U+1);   //RHO,U,V,P.MA
	for(i=0;i<Grid.num_e;i++)
		for(j=0;j<Np_rec;j++)
			for(t=0;t<Num_U+1;t++)
				p_U[i][j][t] = 0.0;

	//********************  here  to input the sixteen points in the flat plane  *******************//
	for(i=0;i<N0;i++)
		for(j=0;j<N0;j++)
		{
			p_node_flat[N0*i+j][0] = -1 + 2.0/(N0-1)*j;
			p_node_flat[N0*i+j][1] = -1 + 2.0/(N0-1)*i;
		}

	for(i=0;i<Np_rec;i++)
	{
		Basis_rectangle.Ni_xy(p_node_flat[i][0],p_node_flat[i][1]);

		for(k=0;k<M_Ni_MAX;k++)
		{
			p_N0[i][k] = Basis_rectangle.p_N0[k];
		}
	}

	//**** second_part:triangle:
	double** p_node_flat_tri;
	double*** p_node_real_tri;
	double** p_N0_tri;
	double*** p_U_tri;
	//allocate:
	Array_2d_double.New(p_node_flat_tri,Np_tri,2);
	Array_3d_double.New(p_node_real_tri,Grid.num_e,Np_tri,2);
	Array_2d_double.New(p_N0_tri,Np_tri,M_Ni_MAX);
	Array_3d_double.New(p_U_tri,Grid.num_e,Np_tri,Num_U+1);
	//zerolize:
	for(i=0;i<Grid.num_e;i++)
		for(j=0;j<Np_tri;j++)
		{
			p_node_real_tri[i][j][0] = 0.0;
			p_node_real_tri[i][j][1] = 0.0;
		}

	for(i=0;i<Grid.num_e;i++)
		for(j=0;j<Np_tri;j++)
			for(k=0;k<Num_U+1;k++)
				p_U_tri[i][j][k] = 0.0;
	//end

	//node_flat:
	k = 0;
	for(i=0;i<N0;i++)
		for(j=0;j<N0-i;j++)
		{
			p_node_flat_tri[k][0] = -1 + (2.0*j+i)/(N0-1);
			p_node_flat_tri[k][1] = sqrt(3.0)*i/(N0-1);
			k++;
		}
	/* check*/
	if(k!=Np_tri)
	{
		 printf("==========================================");
		 printf("============== ERROR IN Np_tri ===========");
		 printf("==========================================");
	}

	//end

	//p_N0:
	for(i=0;i<Np_tri;i++)
	{
		Basis_triangle.Ni_xy(p_node_flat_tri[i][0],p_node_flat_tri[i][1]);

		for(k=0;k<M_Ni_MAX;k++)
		{
			p_N0_tri[i][k] = Basis_triangle.p_N0[k];
		}
	}

	//end

	//loop over elements:
	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_rec;j++)
			{

					p_U[i][j][0] = Iter;
					p_U[i][j][1] = Iter;
					p_U[i][j][2] = Iter;
					p_U[i][j][3] = Iter;
					if(6 == Num_U)
					{
						p_U[i][j][4] =Iter;
						p_U[i][j][5] =Iter;
					}
					else if(5 == Num_U)
					{
						p_U[i][j][4] =Iter;
					}


				//Cal_mu_from_U_SA(p_U[i][j],mu,mut);


				rho =  Iter;
				u = Iter;
				v =  Iter;
				p =  Iter;
				c =  Iter;
				ma =  Iter;
				if(6 == Num_U)
				{
					kine =  Iter;
					   w =  Iter;
				}
				else if(5 == Num_U)
				{

					nut =  Iter;
					Xt =Iter;
					fv1 = Iter;
					//printf("fv1 = %10.5f\n",fv1);

					if(nut>0.0)
					{
						mut = Iter;
						//printf("mut = %10.5f\n",mut);
					}
					else if(nut<=0.0)
					{
						  mut = Iter;
					}

				}

				p_U[i][j][0] = Iter;
				p_U[i][j][1] = Iter;
				p_U[i][j][2] = Iter;
				p_U[i][j][3] = Iter;
				p_U[i][j][4] = Iter;
				if(6 == Num_U)
				{
					p_U[i][j][5] = Iter;
					p_U[i][j][6] = Iter;
				}
				else if(5 == Num_U)
				{
					p_U[i][j][5] = Iter;
				}
			}
		}

		else if(3 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_tri;j++)
			{
				for(t=0;t<M_Ni_MAX;t++)
				{
					p_U_tri[i][j][0] += p_para_element[i].p_u[0][t] * p_N0_tri[j][t];
					p_U_tri[i][j][1] += p_para_element[i].p_u[1][t] * p_N0_tri[j][t];
					p_U_tri[i][j][2] += p_para_element[i].p_u[2][t] * p_N0_tri[j][t];
					p_U_tri[i][j][3] += p_para_element[i].p_u[3][t] * p_N0_tri[j][t];
					if(6 == Num_U)
					{
						p_U_tri[i][j][4] += p_para_element[i].p_u[4][t] * p_N0_tri[j][t];
						p_U_tri[i][j][5] += p_para_element[i].p_u[5][t] * p_N0_tri[j][t];
					}
					else if(5 == Num_U)
					{
						p_U_tri[i][j][4] += p_para_element[i].p_u[4][t] * p_N0_tri[j][t];
					}
				}


				//Cal_mu_from_U_SA(p_U[i][j],mu,mut);
				rho =  p_U_tri[i][j][0];
				u =  p_U_tri[i][j][1]/p_U_tri[i][j][0];
				v =  p_U_tri[i][j][2]/p_U_tri[i][j][0];
				p =  (GAMMA-1.0)*( p_U_tri[i][j][3] - 0.5*rho*(u*u+v*v) );
				c =  sqrt(GAMMA*p/rho);
				ma =  sqrt(u*u+v*v)/c;



				p_U_tri[i][j][0] = Iter;
				p_U_tri[i][j][1] = Iter;
				p_U_tri[i][j][2] = Iter;
				p_U_tri[i][j][3] = Iter;
				p_U_tri[i][j][4] = Iter;


			}

		}
	}

	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			if( -1 == Grid.p_element[i].cflag)
			{
				for(j=0;j<Np_rec;j++)
				{
					Cal_P_polynomials(p_node_flat[j][0],p_node_flat[j][1],p_coef1);

					for(t=0;t<8;t++)
					{
						p_node_real[i][j][0] += Grid.p_element[i].p_a_to_X_e[t] * p_coef1[t];
						p_node_real[i][j][1] += Grid.p_element[i].p_a_to_Y_e[t] * p_coef1[t];
					}
					//Cal_mappingfunction(Grid.p_xi_12[0],Grid.p_xi_12[1],
					//		p_node_flat[j][0],p_node_flat[j][1],p_coef);
					//for(t=0;t<12;t++)
					//{
					//	p_node_real[i][j][0] += Grid.p_X_12_in_e[i][0][t] * p_coef[t];
					//	p_node_real[i][j][1] += Grid.p_X_12_in_e[i][1][t] * p_coef[t];
					//}

				}
			}

			else
			{
				node1 = Grid.p_element[i].p_node[0];
				node2 = Grid.p_element[i].p_node[1];
				node3 = Grid.p_element[i].p_node[2];
				node4 = Grid.p_element[i].p_node[3];

				for(j=0;j<Np_rec;j++)
				{
					Cal_X_from_xi_rectangle( Grid.p_node[node1].p_X[0],Grid.p_node[node1].p_X[1],
							Grid.p_node[node2].p_X[0],Grid.p_node[node2].p_X[1],
							Grid.p_node[node3].p_X[0],Grid.p_node[node3].p_X[1],
							Grid.p_node[node4].p_X[0],Grid.p_node[node4].p_X[1],
							p_node_flat[j][0],p_node_flat[j][1],
					        p_node_real[i][j][0],p_node_real[i][j][1] );
				}
			}
		}

		else if(3 == Grid.p_element[i].type)
		{
			node1 = Grid.p_element[i].p_node[0];
			node2 = Grid.p_element[i].p_node[1];
			node3 = Grid.p_element[i].p_node[2];

			for(j=0;j<Np_tri;j++)
			{
				Cal_X_from_xi_triangle( Grid.p_node[node1].p_X[0],Grid.p_node[node1].p_X[1],
					                        Grid.p_node[node2].p_X[0],Grid.p_node[node2].p_X[1],
					                        Grid.p_node[node3].p_X[0],Grid.p_node[node3].p_X[1],
					                         p_node_flat_tri[j][0], p_node_flat_tri[j][1],
					                    p_node_real_tri[i][j][0],p_node_real_tri[i][j][1]);
			}
		}

	}
	//get the number of cells/tri/quad;
	int num_rec=0,num_tri=0;
	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
			num_rec ++;
		else if(3 == Grid.p_element[i].type)
			num_tri ++;
		else
		{
			printf("ERROR in output.h!\n");
		}
	}
	int nume_totol = Ne_rec*num_rec + Ne_tri*num_tri;
	int nump_totol = Np_rec*num_rec + Np_tri*num_tri;
	int count_p = 0;

	timeval start, s;
	timeval end, e;

	int pid = Iter * 1000 + ORDER_U * 100 + my_id *10 + 0;
	p_delete(pid);
	char* op = (char*)p_new(pid, 4*1024*1024);
	gettimeofday(&start, NULL);
	// int idx = 0;
	//int pid = Iter * 1000 + ORDER_U * 100 + my_id * 10 + 0;
	//p_delete(pid);
	//char* op = (char *)p_new(pid, 4*1024*1024);
	char* sop = op;
	char tmp[100];
	//printf("p_new for plt:: %d, %p\n", pid, op);
	//op[0] = 'a';
	
	sprintf(op,"Title = \"grid_2d_mix\"\n");
	op += strlen("Title = \"grid_2d_mix\"\n");
	if(6 == Num_U) {
		sprintf(op,"Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"k\",\"lw\" \n");
		op += strlen("Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"k\",\"lw\" \n");
		//fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"k\",\"lw\" ");
	}
	else if(5 == Num_U) {
		sprintf(op,"Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"nut\" \n");
		op += strlen("Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"nut\" \n");
		//fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"nut\" ");
	}
	else if(4 == Num_U) {
		sprintf(op,"Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\" \n");
		op += strlen("Var= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\" \n");
		//fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\" ");
	}
	
	sprintf(op, "%s%-6d%s%-6d","Zone N=",nump_totol,",E=",nume_totol);
	op += strlen(op);	

	//strcat(op, tmp);	
	sprintf(op, "%s\n",",F=FEP, ET=QDRIL");
	op += strlen(",F=FEP, ET=QDRIL\n");
	//strcat(op, tmp);
	//fprintf(fp1,"%s%-6d%s%-6d","Zone N=",nump_totol,",E=",nume_totol);
	//fprintf(fp1,"%s\n",",F=FEPOINT, ET=QUADRILATERAL");

	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "1");
	fclose(op1);

	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_rec;j++)
			{
				/*
				fprintf(fp1,"%15.5f%15.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f\n",
						p_node_real[i][j][0],p_node_real[i][j][1],
						p_U[i][j][0],p_U[i][j][1],p_U[i][j][2],
						p_U[i][j][3],p_U[i][j][4],p_U[i][j][5],p_U[i][j][6]);
				*/	/*
				sprintf(op, "%20.10f%20.10f",
						p_node_real[i][j][0],p_node_real[i][j][1]);
				op += strlen(op);*/
				//strcat(op, tmp);
				//fprintf(fp1,"%20.10f%20.10f",
						//p_node_real[i][j][0],p_node_real[i][j][1]);

				for(k=0;k<Num_U/2;k++) {
					*(double *)op = p_U[i][j][k];			
					//sprintf(op, "%20.10f",p_U[i][j][k]);
					op += sizeof(double);
					//strcat(op, tmp);
					//fprintf(fp1,"%20.10f",p_U[i][j][k]);
				}
				//fprintf(fp1,"\n");
				sprintf(op++, "\n");
			}

		}

		else if(3 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_tri;j++)
			{
					/*
					fprintf(fp1,"%15.5f%15.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f\n",
							p_node_real_tri[i][j][k][0],p_node_real_tri[i][j][k][1],
							p_U_tri[i][j][k][0],p_U_tri[i][j][k][1],p_U_tri[i][j][k][2],
							p_U_tri[i][j][k][3],p_U_tri[i][j][k][4],p_U_tri[i][j][k][5],
							p_U_tri[i][j][k][6]);
					*//*
					sprintf(op, "%20.10f%20.10f",
							p_node_real_tri[i][j][0],p_node_real_tri[i][j][1]);
					op += strlen(op);*/
					//strcat(op, tmp);
					//fprintf(fp1,"%20.10f%20.10f",
							//p_node_real_tri[i][j][0],p_node_real_tri[i][j][1]);
					for(k=0;k<Num_U/2;k++) {
						*(double *)op = p_U_tri[i][j][k];
						//sprintf(op, "%20.10f",p_U_tri[i][j][k]);
						op += sizeof(double);
						//strcat(op, tmp);
						//fprintf(fp1,"%20.10f",p_U_tri[i][j][k]);
					}
				sprintf(op++, "\n");
				//fprintf(fp1,"\n");
			}


		}
	}

	//strcat(op, "\0");
	*op = '\0';
	gettimeofday(&end, NULL);
	pcm_write_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
//	printf("%s", sop);

	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "2");
	fclose(op1);

	gettimeofday(&start, NULL);
	char fname[50];
	sprintf(fname,"dg/%s_%d_%s%d%s_%d.plt","OUTPUT_tecplot_p",ORDER_U,"Iter",Iter,"_id",my_id);

	FILE* fp1 = fopen(fname,"w");
	fprintf(fp1,"%s\n","Title = \"grid_2d_mix\"");

	if(6 == Num_U)
		fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"k\",\"lw\" ");
	else if(5 == Num_U)
		fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\",\"nut\" ");
	else if(4 == Num_U)
		fprintf(fp1,"%s\n","Variables= \"X\",\"Y\",\"rho\",\"u\",\"v\",\"p\",\"Ma\" ");

	gettimeofday(&s, NULL);
	fprintf(fp1,"%s%-6d%s%-6d","Zone N=",nump_totol,",E=",nume_totol);
	gettimeofday(&e, NULL);
	printf("fprintf imte:%d\n", e.tv_usec - s.tv_usec);
	fprintf(fp1,"%s\n",",F=FEPOINT, ET=QUADRILATERAL");

	op1 = fopen("dg-file-stage", "w");
	fprintf(op1, "1");
	fclose(op1);

	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_rec;j++)
			{
/*
				fprintf(fp1,"%15.5f%15.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f\n",
						p_node_real[i][j][0],p_node_real[i][j][1],
						p_U[i][j][0],p_U[i][j][1],p_U[i][j][2],
						p_U[i][j][3],p_U[i][j][4],p_U[i][j][5],p_U[i][j][6]); */
			/*	fprintf(fp1,"%20.10f%20.10f",
						p_node_real[i][j][0],p_node_real[i][j][1]); */
				for(k=0;k<Num_U/2;k++) {
					fprintf(fp1,"%20.10f",p_U[i][j][k]);
				}
				fprintf(fp1,"\n");
			}

		}

		else if(3 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_tri;j++)
			{
/*
					fprintf(fp1,"%15.5f%15.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f%10.5f\n",
							p_node_real_tri[i][j][k][0],p_node_real_tri[i][j][k][1],
							p_U_tri[i][j][k][0],p_U_tri[i][j][k][1],p_U_tri[i][j][k][2],
							p_U_tri[i][j][k][3],p_U_tri[i][j][k][4],p_U_tri[i][j][k][5],
							p_U_tri[i][j][k][6]); */
				/*	fprintf(fp1,"%20.10f%20.10f",
							p_node_real_tri[i][j][0],p_node_real_tri[i][j][1]);
				*/	for(k=0;k<Num_U/2;k++) {
						fprintf(fp1,"%20.10f",p_U_tri[i][j][k]);
					}
				fprintf(fp1,"\n");
			}


		}
	}
/*
	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			for(j=0;j<N0-1;j++)
				for(k=0;k<N0-1;k++)
				{
					fprintf(fp1,"%8d%8d%8d%8d\n",(j*N0+k+1)+count_p,(j*N0+k+2)+count_p,
							((j+1)*N0+k+2)+count_p,((j+1)*N0+k+1)+count_p);
				}

			count_p = count_p + Np_rec;
		}
		else if(3 == Grid.p_element[i].type)
		{
			for(j=0;j<N0-1;j++)
				for(k=0;k<N0-1-j;k++)
				{
					fprintf(fp1,"%8d%8d%8d%8d\n",(j*N0-j*(j-1)/2+k+1)+count_p,(j*N0-j*(j-1)/2+k+2)+count_p,
							( (j+1)*N0-j*(j+1)/2+k+1 )+count_p,( (j+1)*N0-j*(j+1)/2+k+1 )+count_p );
				}
			for(j=0;j<N0-2;j++)
				for(k=1;k<N0-1-j;k++)
				{
					fprintf(fp1,"%8d%8d%8d%8d\n",(j*N0-j*(j-1)/2+k+1)+count_p,(j*N0-j*(j-1)/2+k+1)+count_p,
							( (j+1)*N0-j*(j+1)/2+k )+count_p,( (j+1)*N0-j*(j+1)/2+k+1 )+count_p );
				}
			count_p = count_p + Np_tri;

		}
	}
*/
	fclose(fp1);
	gettimeofday(&end, NULL);
	file_write_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;

	op1 = fopen("dg-file-stage", "w");
	fprintf(op1, "2");
	fclose(op1);
	//free
	//rec:
	delete []p_coef1;
	Array_2d_double.Delete(p_node_flat,Np_rec,2);
	Array_3d_double.Delete(p_node_real,Grid.num_e,Np_rec,2);
	Array_2d_double.Delete(p_N0,Np_rec,M_Ni_MAX);
	Array_3d_double.Delete(p_U,Grid.num_e,Np_rec,Num_U+1);   //RHO,U,V,P.MA

	//free
	//tri:
	Array_2d_double.Delete(p_node_flat_tri,Np_tri,2);
	Array_3d_double.Delete(p_node_real_tri,Grid.num_e,Np_tri,2);
	Array_2d_double.Delete(p_N0_tri,Np_tri,M_Ni_MAX);
	Array_3d_double.Delete(p_U_tri,Grid.num_e,Np_tri,Num_U+1);
}


void Output_u_save( int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element)
{	
	FILE *op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "@");
	fclose(op1);
	FILE *op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "@");
	fclose(op2);

	int e,i,k;	
	
	timeval start;
	timeval end;

	gettimeofday(&start,NULL);
	int pid = Iter * 1000 + ORDER_U * 100 + my_id * 10 + 1;
	p_delete(pid);
	char* op = (char *)p_new(pid, 512*1024);
	char tmp[100];
	//printf("p_new for dat:: %d, %p\n", pid, op);
//	op[0] = 'b';

	sprintf(op, "%10d  %10d  %10d\n", ORDER_U, Grid.num_e, M_Ni_U);
	sprintf(tmp, "%10d  %10d  %10d\n", ORDER_U, Grid.num_e, M_Ni_U);
	op += strlen(tmp);

	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "1");
	fclose(op1);
	//fprintf(fp_u, "%10d  %10d  %10d\n", ORDER_U, Grid.num_e, M_Ni_U);
		for(e=0; e<Grid.num_e; e++)
		{
			for(k=0; k<Num_U; k++)
			{
				for(i=0; i<M_Ni_U; i++) {
					sprintf(op, "%20.10f\n", p_para_element[e].p_u[k][i]);
					op += strlen(op);
					//strcat(op, tmp);
					//fprintf(fp_u, "%20.10f\n", p_para_element[e].p_u[k][i]);
				}
			}
			sprintf(op, "\n");
			op++;
			//fprintf(fp_u, "\n");
		}
	
	//strcat(op, "\0");
	*op = '\0';
	gettimeofday(&end,NULL);
	pcm_write_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
//	printf("%s", op);
	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "2");
	fclose(op1);

	gettimeofday(&start,NULL);
	char fname[500];
	sprintf(fname,"dg/%s%d%s%d%s%d.dat","OUTPUT_u_save_p", ORDER_U,"Iter",Iter,"_id",my_id);
	FILE* fp_u = fopen(fname, "w");

	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "1");
	fclose(op2);
	fprintf(fp_u, "%10d  %10d  %10d\n", ORDER_U, Grid.num_e, M_Ni_U);
		for(e=0; e<Grid.num_e; e++)
		{
			for(k=0; k<Num_U; k++)
			{
				for(i=0; i<M_Ni_U; i++) {
					fprintf(fp_u, "%f\n", p_para_element[e].p_u[k][i]);
				}
			}
			fprintf(fp_u, "\n");
		}
	
	fclose(fp_u);
	gettimeofday(&end,NULL);
	file_write_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;	

	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "2");
	fclose(op2);
	//============================================================
}

void read_Interface_mix(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,
                          Basis_rectangle& Basis_rectangle,Basis_triangle& Basis_triangle) {
	int i,j,k;
	double t;
	char c;

	FILE *op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "#");
	fclose(op1);
	FILE *op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "#");
	fclose(op2);

	printf("read_Interface_mix begins\n");	
	timeval start;
	timeval end;

	int N0 = N_OUTPUT;
	int Ne_rec = (N0-1)*(N0-1);           //NUMber of elements
	int Np_rec = N0*N0;     //NUMber of points
	int Ne_tri = (N0-1)*(N0-1);
	int Np_tri = (1+N0)*N0/2;

	gettimeofday(&start,NULL);
	int pid = Iter * 1000 + ORDER_U * 100 + my_id * 10 + 0;
	char* op = (char *)p_get(pid, 4*1024*1024);
	//printf("p_get for plt:: %d, %p\n", pid, op);
	while (*op != '\n') op++;
	while (*op != '\n') op++;
	while (*op != '\n') op++;
	while (*op != '\n') op++;
	op++;

	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "1");
	fclose(op1);

	double data;
	for(i=0;i<Grid.num_e;i++)
		{
			if(4 == Grid.p_element[i].type)
			{
				for(j=0;j<Np_rec;j++)
				{/*
					fscanf(fp1,"%f%f%f%f%f%f%f%f%f\n",
							&t,&t,&t,&t,&t,&t,&t,&t,&t);*/
					//fscanf(fp1,"%f%f",&t,&t);
					for(k=0;k<Num_U/2;k++) {
						data = *(double *)op;
						op += sizeof(double);
					}
					op++;
				}

			}

			else if(3 == Grid.p_element[i].type)
			{
				for(j=0;j<Np_tri;j++)
				{
						/*
						fscanf(fp1,"%f%f%f%f%f%f%f%f%f\n",
								&t,&t,&t,&t,&t,&t,&t,&t,&t);*/
						//fscanf(fp1,"%f%f",&t,&t);
					for(k=0;k<Num_U/2;k++) {
						data = *(double *)op;
						op += sizeof(double);
					}
					op++;
				}


			}
		}
/*
	for (i=0;i<4*1024*1024/sizeof(char);i++) {
		if (op[i] == '\0')
			break;
		c = op[i];
	}  */
	//printf("read p_get for plt done :: %d, %p\n", pid, op);
	gettimeofday(&end,NULL);
	pcm_read_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
	//op[0] = 'a';	
	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "2");
	fclose(op1);

	gettimeofday(&start,NULL);
	char fname[50];
	sprintf(fname,"/tmp/ramdisk/%s_%d_%s%d%s_%d.plt","OUTPUT_tecplot_p",ORDER_U,"Iter",Iter,"_id",my_id);

	FILE* fp1 = fopen(fname,"r");
	fscanf(fp1, "\n");
	fscanf(fp1, "\n");
	fscanf(fp1, "\n");
	fscanf(fp1, "\n");

	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "1");
	fclose(op2);

	for(i=0;i<Grid.num_e;i++)
	{
		if(4 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_rec;j++)
			{/*
				fscanf(fp1,"%f%f%f%f%f%f%f%f%f\n",
						&t,&t,&t,&t,&t,&t,&t,&t,&t);*/
				//fscanf(fp1,"%f%f",&t,&t);
				for(k=0;k<Num_U/2;k++) {
					fscanf(fp1,"%f",&t);
				}
				fscanf(fp1,"\n");
			}

		}

		else if(3 == Grid.p_element[i].type)
		{
			for(j=0;j<Np_tri;j++)
			{
					/*
					fscanf(fp1,"%f%f%f%f%f%f%f%f%f\n",
							&t,&t,&t,&t,&t,&t,&t,&t,&t);*/
					//fscanf(fp1,"%f%f",&t,&t);
					for(k=0;k<Num_U/2;k++) {
						fscanf(fp1,"%f",&t);
					}
				fscanf(fp1,"\n");
			}


		}
	}
	//printf("file read plt done\n");
	gettimeofday(&end,NULL);
	file_read_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;	
	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "2");
	fclose(op2);
	printf("read_Interface_mix ends\n");
}

void read_u_save(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element) {
	printf("read_u_save begins\n");	

	FILE *op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "$");
	fclose(op1);
	FILE *op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "$");
	fclose(op2);

	int e,i,k;
	char c;	
	
	timeval start;
	timeval end;

	int N0 = N_OUTPUT;
	int Ne_rec = (N0-1)*(N0-1);           //NUMber of elements
	int Np_rec = N0*N0;     //NUMber of points
	int Ne_tri = (N0-1)*(N0-1);
	int Np_tri = (1+N0)*N0/2;

	gettimeofday(&start,NULL);
	int pid = Iter * 1000 + ORDER_U * 100 + my_id * 10 + 1;
	char* op = (char *)p_get(pid, 512*1024);
	//printf("p_get for dat:: %d, %p\n", pid, op);
	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "1");
	fclose(op1);
	for (i=0;i<512*1024/sizeof(char);i++) {
		if (op[i] == '\0')
			break;
		c = op[i];
	}
	//printf("read p_get for dat done :: %d, %p\n", pid, op);
	gettimeofday(&end,NULL);
	pcm_read_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;	
	op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "2");
	fclose(op1);

	gettimeofday(&start,NULL);
	char fname[500];
	sprintf(fname,"dg/%s%d%s%d%s%d.dat","OUTPUT_u_save_p", ORDER_U,"Iter",Iter,"_id",my_id);
	FILE* fp_u = fopen(fname, "r");

	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "1");
	fclose(op2);

	double tt;
	//fprintf(fp_u, "%10d  %10d  %10d\n", ORDER_U, Grid.num_e, M_Ni_U);
//	fscanf(fp_u, "\n");
	for(e=0; e<Grid.num_e; e++)
	{
		for(k=0; k<Num_U; k++)
		{
			for(i=0; i<M_Ni_U; i++) {
				fscanf(fp_u, "%f\n", &tt);
			}
		}
		fscanf(fp_u, "\n");
	}
	//printf("file read dat done\n");
	fclose(fp_u);
	gettimeofday(&end,NULL);
	file_read_time += 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;

	op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "2");
	fclose(op2);

	printf("read_u_Save ends\n");
	//============================================================
}

void Output_statistic() {
	printf("file read time: %lu, file write time: %lu, total: %lu\n", file_read_time, file_write_time, file_read_time+file_write_time);
	printf("pcm read time: %lu, pcm write time: %lu, total: %lu\n", pcm_read_time, pcm_write_time, pcm_read_time+pcm_write_time);

	FILE *op1 = fopen("dg-scm-stage", "w");
	fprintf(op1, "%\n");
	fprintf(op1, "pcm read time: %lu, pcm write time: %lu, total: %lu\n", pcm_read_time, pcm_write_time, pcm_read_time+pcm_write_time);
	fclose(op1);
	FILE *op2 = fopen("dg-file-stage", "w");
	fprintf(op2, "%\n");
	fprintf(op2, "file read time: %lu, file write time: %lu, total: %lu\n", file_read_time, file_write_time, file_read_time+file_write_time);
	fclose(op2);
}
