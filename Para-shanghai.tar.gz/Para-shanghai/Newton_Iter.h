/*
 * =====================================================================================
 *
 *       Filename:  Newton_Iter.h
 *
 *    Description:  Newton Iterative Method to solve the N-S equations
 *
 *        Version:  1.0
 *        Created:  21/12/13 13:49:01
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

//#include"dg.h"
void Newton_Iter(int my_id,
			GRID_GENERAL& Grid,
			PARA_ELEMENT*   p_para_element,
			PARA_FACE*   p_para_face,
			PARA_FLOW_OUT&  para_flow_out,
			Basis_rectangle& Basis_rectangle,
			Basis_triangle& Basis_triangle)
{
	int i,j,k,e;
	double MAXdu,MAX_max;


	wall_time = MPI_Wtime();

	MPI_Barrier(MPI_COMM_WORLD);
	Exchange_infor_etype(my_id, Grid, p_para_face, p_para_element);
	//printf("ID = %5d\n", my_id);


	for(Iter=0; Iter<MAX_ITER; Iter++)
	{
	    if(my_id ==0 )
            printf("*****************************Iter%5d ***************************\n",Iter);
        for(e=0; e<Grid.num_e; e++)
            for(k=0; k<Num_U; k++)
                for(i=0; i<M_Ni_U; i++)
                {
                    p_para_element[e].p_u[k][i] = (double)Iter;
                }

        MPI_Barrier(MPI_COMM_WORLD);

        Exchange_infor_u( my_id, Grid, p_para_face, p_para_element );
        MPI_Barrier(MPI_COMM_WORLD);
        printf("ID = %5d   Going to Exchange_infor_u... \n", my_id);

        MPI_Barrier(MPI_COMM_WORLD);


       printf ("ID = %5d   Start to Calculate\n",my_id);
        sleep(sleep_time);

        if(Iter%Gap_of_output == 0)
        {
            printf("Output tecplot file\n");
            Output_Interface_mix(my_id,Grid, p_para_element, Basis_rectangle,Basis_triangle);
		read_Interface_mix(my_id,Grid, p_para_element, Basis_rectangle,Basis_triangle);
        }



		Output_u_save(my_id,Grid, p_para_element);
	read_u_save(my_id,Grid, p_para_element);


	}

	wall_time = MPI_Wtime() - wall_time;
	ACT_ITER = Iter;


		//TestL(Grid,p_para_element,p_para_face,para_flow_out);
		Output_Interface_mix(my_id,Grid, p_para_element, Basis_rectangle,Basis_triangle);
	read_Interface_mix(my_id,Grid, p_para_element, Basis_rectangle,Basis_triangle);
		Output_u_save(my_id,Grid, p_para_element);
	read_u_save(my_id,Grid, p_para_element);


}


void MAX_u_du(int my_id, GRID_GENERAL& Grid, PARA_ELEMENT* p_para_element,double& MAXdu)
{
	int e,i,j,k;
	double MAX = 0.0;
	double MAX1 = 0.0;
	double tempdv = 0.0;
	double tempv = 0.0;
	double temp;
	for(e=0;e<Grid.num_e;e++)
	{
		for(k=0; k<Num_U; k++)
		{
			for(i=0; i<M_Ni_U; i++)
			{
				//if(tempv<fabs(p_para_element[e].p_u[k][i])) tempv = p_para_element[e].p_u[k][i];

				//if(tempdv<fabs(p_para_element[e].p_du[k*M_Ni_U+i])) tempdv = p_para_element[e].p_du[k*M_Ni_U+i];


				tempv = p_para_element[e].p_u[k][i];
				tempdv = p_para_element[e].p_du[k*M_Ni_U+i];

				temp = fabs(tempdv/tempv);
				if(temp>MAX) MAX = temp;
			}
		}
	}

	//MAX = tempdv/tempv;
	printf("my_id = %5d, MAX is %12.6f\n",my_id,MAX);
	MAXdu = MAX;
}

