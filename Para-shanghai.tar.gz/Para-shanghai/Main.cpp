/*
 * =====================================================================================
 *
 *       Filename:  Main.cpp
 *
 *    Description:  parallel dg
 *
 *        Version:  1.0
 *        Created:  04/11/13 15:47:06
 *       Revision:  V1
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

#include"dg.h"

int main(int argc, char** argv)
{
	//========== MPI ============
	int MY_ID,NUM_ID;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &NUM_ID);
	MPI_Comm_rank(MPI_COMM_WORLD, &MY_ID);
	//========== M_Ni_U =========
	ORDER_MAX=ORDER_U;
	p_M_Ni=new int [ORDER_MAX+1];
	Cal_M_Ni_from_p(ORDER_MAX,p_M_Ni);
	M_Ni_U=p_M_Ni[ORDER_U];
	M_Ni_MAX=M_Ni_U;

	MPI_Barrier(MPI_COMM_WORLD);

	//======= Quadrature_max ======
	Init_quadrature_max_1d();
	Init_quadrature_max_2d();

	if(0 == MY_ID)
	{
		printf("MY_ID = %3d M_xi_1d = %3d M_xi_2d_rec = %3d M_xi_2d_tri = %3d \n",
			MY_ID,
			M_xi_1d,
			M_xi_2d_rec,
			M_xi_2d_tri);
		//printf("\n");
	}

	//========    Basis     =======
	Basis_rectangle Basis_rec(ORDER_MAX);
	 Basis_triangle Basis_tri(ORDER_MAX);

	MPI_Barrier(MPI_COMM_WORLD);

	Init_element_reference(Basis_rec,Basis_tri);
    Init_face_reference(Basis_rec,Basis_tri);

	//========      Grid      =====
	MPI_Barrier(MPI_COMM_WORLD);
	printf(" MY_ID = %6d  to Init_grid_general \n",MY_ID);

	GRID_GENERAL Grid;
	Init_grid_general(MY_ID,Grid);

	MPI_Barrier(MPI_COMM_WORLD);
	printf(" MY_ID = %3d  Init_grid DONE !!!\n",MY_ID);

	//=======    Init_para.h   ====
	PARA_FLOW_OUT para_flow_out;
	Init_para_flow_out(MY_ID, para_flow_out);
	//determines parameter Num_U
	//-------------------- Init_para_trans ---------------
	Init_para_trans(MY_ID, Grid, p_para_send, p_para_recv);// Num_U,M_xi_1d and M_Ni_U are needed !!!
	MPI_Barrier(MPI_COMM_WORLD);

	Exchange_num_element_total( MY_ID, Grid );
	MPI_Barrier(MPI_COMM_WORLD);
	printf(" MY_ID = %3d, NUM_ELEMENT_TOTAL = %10d  NUM_PARTITION = %3d\n",
						MY_ID, NUM_ELEMENT_TOTAL, NUM_PARTITION );
	MPI_Barrier(MPI_COMM_WORLD);

	Exchange_num_face_total( MY_ID, Grid );
	MPI_Barrier(MPI_COMM_WORLD);
	printf(" MY_ID = %3d, NUM_FACE_TOTAL = %10d  NUM_PARTITION = %3d\n",
						MY_ID, NUM_FACE_TOTAL, NUM_PARTITION );
	MPI_Barrier(MPI_COMM_WORLD);

	//Output_N0_face( MY_ID, Grid );


	//======    Init_para_DG   ======
	PARA_ELEMENT* p_para_element = new PARA_ELEMENT[Grid.num_e];
	PARA_FACE*    p_para_face    = new PARA_FACE[Grid.num_face];

	Init_para(MY_ID, Grid, para_flow_out, p_para_element,p_para_face);

	//##################### Exchange #######################
	MPI_Barrier(MPI_COMM_WORLD);
	printf("ID = %5d   Going to Exchange_infor_u... \n", MY_ID);

	MPI_Barrier(MPI_COMM_WORLD);
	Exchange_infor_u(MY_ID, Grid, p_para_face, p_para_element);
	MPI_Barrier(MPI_COMM_WORLD);
	//######################################################


    printf("ID = %5d , newton_Iter Method ... \n",MY_ID);
    Newton_Iter(MY_ID,Grid,p_para_element,p_para_face,para_flow_out,Basis_rec,Basis_tri);
	Output_statistic();

	MPI_Barrier(MPI_COMM_WORLD);
	printf("      ID  = %5d   going to MPI_Finalize() .....\n", MY_ID);
	MPI_Finalize();

	return 0;
}
