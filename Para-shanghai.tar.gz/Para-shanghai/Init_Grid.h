/*
 * =====================================================================================
 *
 *       Filename:  Init_Grid.h
 *
 *    Description:  Read grid_information and operate
 *
 *        Version:  1.0
 *        Created:  25/11/13 20:11:09
 *       Revision:  V1
 *       Compiler:  gcc
 *
 *         Author:  Wanglong Qin (Phd candidate), qinwanglong@126.com
 *   Organization:  Nanjing University of Aeronautics and Astronautics
 *
 * =====================================================================================
 */

void Init_grid_level_0(int my_id, GRID_LEVEL*& p_grid_level)
{
	int e,i,j,k, partition,face, i_fscanf;

	char fname[100];
	FILE* fp;
	//=================================================================
	partition = my_id;
	sprintf(fname,"input_data/%s%d.txt","Grid_slave_", partition);
	fp = fopen(fname, "r");
	//-------------------- Grid_general ---------------------
	i_fscanf = fscanf(fp, "%d\n", &NUM_PARTITION);

	i_fscanf = fscanf(fp, "%d %d %d\n", &p_grid_level[0].num_e, &p_grid_level[0].num_node, &p_grid_level[0].num_face);

	p_grid_level[0].p_element = new ELEMENT_INFOR[p_grid_level[0].num_e];
	p_grid_level[0].p_node    = new NODE_INFOR[p_grid_level[0].num_node];
	p_grid_level[0].p_face    = new FACE_INFOR[p_grid_level[0].num_face];

	for(e=0; e<p_grid_level[0].num_e; e++)
	{
		i_fscanf = fscanf(fp, "%d %d %lf %lf %d %lf %lf", 
					&p_grid_level[0].p_element[e].flag, 
					&p_grid_level[0].p_element[e].type, 
					&p_grid_level[0].p_element[e].h, 
					&p_grid_level[0].volume, 
					&p_grid_level[0].num_f, 
					&p_grid_level[0].l[0], 
					&p_grid_level[0].l[1]);
		for(i=0;i<p_Grid_slave[partition].p_element[e].type;i++)
		{
			fprintf(fp, "%10d",p_Grid_slave[partition].p_element[e].p_node[i]); 
		}
		for(i=0;i<p_Grid_slave[partition].p_element[e].type;i++)
		{
			fprintf(fp, "%10d",p_Grid_slave[partition].p_element[e].p_face[i]); 
		}
		for(i=0;i<p_Grid_slave[partition].p_element[e].num_f;i++)
		{
			fprintf(fp, "%10d",p_Grid_slave[partition].p_element[e].p_f[i]); 
		}
		for(i=0;i<p_Grid_slave[partition].p_element[e].num_f;i++)
		{
			fprintf(fp, "%10d",p_Grid_slave[partition].p_element[e].p_partition_f[i]); 
		}
		fprintf(fp,"\n");
		p_grid_level[0].p_element[e].p_node        = new int[4];
		p_grid_level[0].p_element[e].p_face        = new int[4];
		p_grid_level[0].p_element[e].p_f           = new int[5];
		p_grid_level[0].p_element[e].p_partition_f = new int[5];
		p_grid_level[0].p_element[e].p_index_face  = new int[4];
		p_grid_level[0].p_element[e].p_index_f     = new int[4];

		i_fscanf = fscanf(fp, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %le\n", 
				&p_grid_level[0].p_element[e].flag, 
				&p_grid_level[0].p_element[e].p_node[0], 
				&p_grid_level[0].p_element[e].p_node[1],
				&p_grid_level[0].p_element[e].p_node[2],
				&p_grid_level[0].p_element[e].p_node[3],
				&p_grid_level[0].p_element[e].p_f[0],
				&p_grid_level[0].p_element[e].p_f[1],
				&p_grid_level[0].p_element[e].p_f[2],
				&p_grid_level[0].p_element[e].p_f[3],
				&p_grid_level[0].p_element[e].p_partition_f[0], 
				&p_grid_level[0].p_element[e].p_partition_f[1],
				&p_grid_level[0].p_element[e].p_partition_f[2], 
				&p_grid_level[0].p_element[e].p_partition_f[3], 
				&p_grid_level[0].p_element[e].p_face[0],
				&p_grid_level[0].p_element[e].p_face[1],
				&p_grid_level[0].p_element[e].p_face[2], 
				&p_grid_level[0].p_element[e].p_face[3], 
				&p_grid_level[0].p_element[e].volume);


		p_grid_level[0].p_element[e].h = pow(0.75*p_grid_level[0].p_element[e].volume/PI, 1.0/3.0);
		p_grid_level[0].p_element[e].p_index_face[0] = 0;
		p_grid_level[0].p_element[e].p_index_face[1] = 1;
		p_grid_level[0].p_element[e].p_index_face[2] = 2;
		p_grid_level[0].p_element[e].p_index_face[3] = 3;
		p_grid_level[0].p_element[e].p_index_f[0]    = 0;
		p_grid_level[0].p_element[e].p_index_f[1]    = 1;
		p_grid_level[0].p_element[e].p_index_f[2]    = 2;
		p_grid_level[0].p_element[e].p_index_f[3]    = 3;
	}
	for(i=0; i<p_grid_level[0].num_node; i++)
	{
		p_grid_level[0].p_node[i].p_X = new double[3];
		i_fscanf = fscanf(fp, "%d %le %le %le\n", 
				&p_grid_level[0].p_node[i].flag, 
				&p_grid_level[0].p_node[i].p_X[0], 
				&p_grid_level[0].p_node[i].p_X[1],
				&p_grid_level[0].p_node[i].p_X[2]);
	}
	for(face=0; face<p_grid_level[0].num_face; face++)
	{
		p_grid_level[0].p_face[face].p_n_of_face = new double[3];
		i_fscanf = fscanf(fp, "%d %d %d %d %d %d %d %d %d %d %le %le %le %le\n", 
				&p_grid_level[0].p_face[face].flag, 
				&p_grid_level[0].p_face[face].e, 
				&p_grid_level[0].p_face[face].f, 
				&p_grid_level[0].p_face[face].index_in_e,
				&p_grid_level[0].p_face[face].index_in_f, 
				&p_grid_level[0].p_face[face].index_rotating_in_e,
				&p_grid_level[0].p_face[face].index_rotating_in_f,
				&p_grid_level[0].p_face[face].partition_e,
				&p_grid_level[0].p_face[face].partition_f,
				&p_grid_level[0].p_face[face].face_in_partition_f,
				&p_grid_level[0].p_face[face].p_n_of_face[0], 
				&p_grid_level[0].p_face[face].p_n_of_face[1],
				&p_grid_level[0].p_face[face].p_n_of_face[2],
				&p_grid_level[0].p_face[face].area);
	}

	//------------------- Partition Infor -------------------
	p_grid_level[0].p_e_master    = new int[p_grid_level[0].num_e];
	p_grid_level[0].p_node_master = new int[p_grid_level[0].num_node];
	p_grid_level[0].p_face_master = new int[p_grid_level[0].num_face];	
	for(e=0; e<p_grid_level[0].num_e; e++)
		i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_e_master[e]);
	for(i=0; i<p_grid_level[0].num_node; i++)
		i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_node_master[i]);
	for(k=0; k<p_grid_level[0].num_face; k++)
		i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_face_master[k]);

	//--------------------  Trans Infor  --------------------
	i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].num_partition_neighbouring);

	p_grid_level[0].p_partition_neighbouring = new int[p_grid_level[0].num_partition_neighbouring];

	for(i=0; i<p_grid_level[0].num_partition_neighbouring; i++)
		i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_partition_neighbouring[i]);

	p_grid_level[0].p_trans = new PARA_TRANS[p_grid_level[0].num_partition_neighbouring];
	for(i=0; i<p_grid_level[0].num_partition_neighbouring; i++)
	{
		i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_trans[i].num);

		p_grid_level[0].p_trans[i].p_face = new int[p_grid_level[0].p_trans[i].num];
		for(j=0; j<p_grid_level[0].p_trans[i].num; j++)
			i_fscanf = fscanf(fp, "%d\n", &p_grid_level[0].p_trans[i].p_face[j]);
	}
	//-------------------------------------------------------
	fclose(fp);

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	for(e=0; e<p_grid_level[0].num_e; e++)
	{
		Array_2d_double.New(p_grid_level[0].p_element[e].p_dxi_dX, 3, 3);
		Cal_dxi_dX_element(e, Grid);
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	p_grid_level[0].h_min_global = p_grid_level[0].p_element[0].h;
	for(e=0; e<p_grid_level[0].num_e; e++)
	{
		if(p_grid_level[0].h_min_global > p_grid_level[0].p_element[e].h)
			p_grid_level[0].h_min_global = p_grid_level[0].p_element[e].h;
	}

	printf("  my_id = %3d   local  H_min = %20.12f\n", my_id, p_grid_level[0].h_min_global);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

}


/*

void Init_para_trans(int my_id, GRID_GENERAL& Grid, PARA_SEND*& p_para_send, PARA_RECV*& p_para_recv)
{
	int i,k, partition;

	partition = my_id;

	p_para_send = new PARA_SEND[Grid.num_partition_neighbouring];
	p_para_recv = new PARA_RECV[Grid.num_partition_neighbouring];

	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		p_para_send[k].num = Grid.p_trans[k].num;
		p_para_recv[k].num = Grid.p_trans[k].num;

		p_para_send[k].p_e    = new int[p_para_send[k].num];
		p_para_recv[k].p_face = new int[p_para_recv[k].num];

		p_para_send[k].p_u    = new double[p_para_send[k].num*(5*M_Ni_U)];
		p_para_recv[k].p_u    = new double[p_para_recv[k].num*(5*M_Ni_U)];

		p_para_send[k].p_u0   = new double[p_para_send[k].num*(5*M_Ni_U0)];
		p_para_recv[k].p_u0   = new double[p_para_recv[k].num*(5*M_Ni_U0)];

		p_para_send[k].p_f    = new double[p_para_send[k].num*(3*5*M_Ni_F)];
		p_para_recv[k].p_f    = new double[p_para_recv[k].num*(3*5*M_Ni_F)];

		p_para_send[k].p_flag_source  = new int[p_para_send[k].num];
		p_para_recv[k].p_flag_source  = new int[p_para_recv[k].num];

		//-------------------------------------
		for(i=0; i<Grid.p_trans[k].num; i++)
		{
			p_para_recv[k].p_face[i] = Grid.p_trans[k].p_face[i];
			p_para_send[k].p_e[i]    = Grid.p_face[Grid.p_trans[k].p_face[i]].e;
		}
	}
}

//##############################################################################################################


void Exchange_num_element_total(int my_id, GRID_GENERAL& Grid)
{
	int k, partition_f, slave_f;

	int* p_num_temp = new int[NUM_PARTITION];

	MPI_Request* p_request_send = new MPI_Request[NUM_PARTITION];
	MPI_Request* p_request_recv = new MPI_Request[NUM_PARTITION];
	MPI_Status*  p_status_send  = new MPI_Status[NUM_PARTITION];
	MPI_Status*  p_status_recv  = new MPI_Status[NUM_PARTITION];
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Irecv(&p_num_temp[k], 1, MPI_INT, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Isend(&Grid.num_e, 1, MPI_INT, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(NUM_PARTITION, p_request_recv, p_status_recv);
	MPI_Waitall(NUM_PARTITION, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ Init p_para_face.p_V_f +++++++++++++++++++++++++++++++++++
	NUM_ELEMENT_TOTAL = 0;
	for(k=0; k<NUM_PARTITION; k++)
	{
		NUM_ELEMENT_TOTAL = NUM_ELEMENT_TOTAL + p_num_temp[k];
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_num_temp;
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}



void Exchange_h_min(int my_id, GRID_GENERAL& Grid)
{
	int k, partition_f, slave_f;
	double* p_h_min_temp = new double[NUM_PARTITION];

	MPI_Request* p_request_send = new MPI_Request[NUM_PARTITION];
	MPI_Request* p_request_recv = new MPI_Request[NUM_PARTITION];
	MPI_Status*  p_status_send  = new MPI_Status[NUM_PARTITION];
	MPI_Status*  p_status_recv  = new MPI_Status[NUM_PARTITION];
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Irecv(&p_h_min_temp[k], 1, MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Isend(&Grid.h_min_global, 1, MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(NUM_PARTITION, p_request_recv, p_status_recv);
	MPI_Waitall(NUM_PARTITION, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ Init p_para_face.p_V_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<NUM_PARTITION; k++)
	{
		if(p_h_min_temp[k] < Grid.h_min_global)
			Grid.h_min_global = p_h_min_temp[k];
	}
	H_MIN = Grid.h_min_global;
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_h_min_temp;
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}




void Exchange_u(GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element)
{
	int e, ii, i, j, k, face, partition_f, slave_f;

	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];
	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			for(i=0; i<5; i++)
			{
				for(j=0; j<M_Ni_U; j++)
					p_para_send[k].p_u[ii*(5*M_Ni_U)+i*M_Ni_U+j] = p_para_element[e].p_u[i][j];
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_u, p_para_recv[k].num*(5*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_u, p_para_send[k].num*(5*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_u_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];
			for(i=0; i<5; i++)
			{
				for(j=0; j<M_Ni_U; j++)
					p_para_face[face].p_u_f[i][j] = p_para_recv[k].p_u[ii*(5*M_Ni_U)+i*M_Ni_U+j];
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}


void Exchange_f(GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element)
{
	int e, i,j,k,ii,kk, face, partition_f, slave_f;

	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];
	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			for(kk=0; kk<3; kk++)
			{
				for(i=0; i<5; i++)
				{
					for(j=0; j<M_Ni_F; j++)
					{
						p_para_send[k].p_f[ii*(3*5*M_Ni_F) + kk*(5*M_Ni_F) + i*M_Ni_F + j] = p_para_element[e].p_f[kk][i][j];
					}
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_f, p_para_recv[k].num*(3*5*M_Ni_F), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_f, p_para_send[k].num*(3*5*M_Ni_F), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_f_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(kk=0; kk<3; kk++)
			{
				for(i=0; i<5; i++)
				{
					for(j=0; j<M_Ni_F; j++)
					{
						p_para_face[face].p_f_f[kk][i][j] = p_para_recv[k].p_f[ii*(3*5*M_Ni_F) + kk*(5*M_Ni_F) + i*M_Ni_F + j];
					}
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

*/




