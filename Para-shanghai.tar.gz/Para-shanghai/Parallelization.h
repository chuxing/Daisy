
void Init_para_trans(int my_id, GRID_GENERAL& Grid, PARA_SEND*& p_para_send, PARA_RECV*& p_para_recv)
{
	int e,i,j,k;

	p_para_send = new PARA_SEND[Grid.num_partition_neighbouring];
	p_para_recv = new PARA_RECV[Grid.num_partition_neighbouring];

	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		p_para_send[k].num = Grid.p_trans[k].num;
		p_para_recv[k].num = Grid.p_trans[k].num;

		p_para_send[k].p_e     = new int[ p_para_send[k].num ];
		p_para_recv[k].p_face  = new int[ p_para_recv[k].num ];

		p_para_send[k].p_face  = new int[ p_para_send[k].num ];
		p_para_recv[k].p_e     = new int[ p_para_recv[k].num ];

		p_para_send[k].p_u     = new double[ p_para_send[k].num * (Num_U*M_Ni_U) ];
		p_para_recv[k].p_u     = new double[ p_para_recv[k].num * (Num_U*M_Ni_U) ];

		p_para_send[k].p_du    = new double[ p_para_send[k].num * (Num_U*M_Ni_U) ];
		p_para_recv[k].p_du    = new double[ p_para_recv[k].num * (Num_U*M_Ni_U) ];

		p_para_send[k].p_du0   = new double[ p_para_send[k].num * (Num_U*M_Ni_U) ];
		p_para_recv[k].p_du0   = new double[ p_para_recv[k].num * (Num_U*M_Ni_U) ];

		//p_para_send[k].p_N0    = new double[ p_para_send[k].num * (M_xi_1d*M_Ni_U) ];
		//p_para_recv[k].p_N0    = new double[ p_para_recv[k].num * (M_xi_1d*M_Ni_U) ];
		//================================================
		//type and Epsilon
		p_para_send[k].p_type = new int[p_para_send[k].num];
		p_para_recv[k].p_type = new int[p_para_recv[k].num];

		//================================================
		if(1 == FLAG_Laprho)
		{
			p_para_send[k].p_Epsilon = new double[p_para_send[k].num];
			p_para_recv[k].p_Epsilon = new double[p_para_recv[k].num];		//shock
			//p_sx and p_sy in shock
			p_para_send[k].p_sx    = new double[ p_para_send[k].num * (Num_U*M_Ni_U) ];
			p_para_recv[k].p_sx    = new double[ p_para_recv[k].num * (Num_U*M_Ni_U) ];

			p_para_send[k].p_sy    = new double[ p_para_send[k].num * (Num_U*M_Ni_U) ];
			p_para_recv[k].p_sy    = new double[ p_para_recv[k].num * (Num_U*M_Ni_U) ];
		}
		//================================================
		if(1 == FLAG_Euler)
		{
			//p_gradx and p_grady in vis
			////p_gradx and p_grady in vis
			p_para_send[k].p_gradx    = new double[ p_para_send[k].num * (Num_U*M_xi_1d) ];
			p_para_recv[k].p_gradx    = new double[ p_para_recv[k].num * (Num_U*M_xi_1d) ];

			p_para_send[k].p_grady    = new double[ p_para_send[k].num * (Num_U*M_xi_1d) ];
			p_para_recv[k].p_grady    = new double[ p_para_recv[k].num * (Num_U*M_xi_1d) ];

			p_para_send[k].p_dS_facex = new double[ p_para_send[k].num * (2*Num_U*Num_U*M_xi_1d) ];
			p_para_recv[k].p_dS_facex = new double[ p_para_recv[k].num * (2*Num_U*Num_U*M_xi_1d) ];

			p_para_send[k].p_dS_facey = new double[ p_para_send[k].num * (2*Num_U*Num_U*M_xi_1d) ];
			p_para_recv[k].p_dS_facey = new double[ p_para_recv[k].num * (2*Num_U*Num_U*M_xi_1d) ];
		}
		//================================================
		if(1 == FLAG_Laprho || 1 == FLAG_Euler)
		{
			//p_dxi_dX_r
			//p_para_recv[k].num*(M_xi_1d*4)
			p_para_send[k].p_dxi_dX_r = new double[ p_para_send[k].num * (M_xi_1d * 4) ];
			p_para_recv[k].p_dxi_dX_r = new double[ p_para_recv[k].num * (M_xi_1d * 4) ];
		}
		//-------------------------------------
		for(i=0; i<Grid.p_trans[k].num; i++)
		{
			//all relate to send info,both e or face
			p_para_recv[k].p_face[i] = Grid.p_trans[k].p_face[i];
			p_para_send[k].p_e[i]    = Grid.p_face[ Grid.p_trans[k].p_face[i] ].p_face[2];

			p_para_recv[k].p_e[i]    = p_para_send[k].p_e[i];
			p_para_send[k].p_face[i] = p_para_recv[k].p_face[i];
		}
		//enew:
		p_para_send[k].enew = new int[ p_para_send[k].num ];
		p_para_recv[k].enew = new int[ p_para_recv[k].num ];
		//-------------------------------------
	}
}


void Exchange_infor_u( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,ii, face, partition_e, partition_f, slave_e, slave_f;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_send[k].p_u[ ii*(Num_U*M_Ni_U) + i*M_Ni_U + j ] = p_para_element[e].p_u[i][j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_u, p_para_recv[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_u, p_para_send[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_u_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
					p_para_face[face].p_u_f[i][j] = p_para_recv[k].p_u[ii*(Num_U*M_Ni_U)+i*M_Ni_U+j];
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_avis_s( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,ii, face, partition_e, partition_f, slave_e, slave_f;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_send[k].p_sx[ ii*(Num_U*M_Ni_U) + i*M_Ni_U + j ] = p_para_element[e].p_sx[i][j];
					p_para_send[k].p_sy[ ii*(Num_U*M_Ni_U) + i*M_Ni_U + j ] = p_para_element[e].p_sy[i][j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//================ sending and receiving sx ==========
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_sx, p_para_recv[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_sx, p_para_send[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//===================== sending and receiving sy ==================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_sy, p_para_recv[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}

	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_sy, p_para_send[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_u_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_face[face].p_sx_f[i][j] = p_para_recv[k].p_sx[ii*(Num_U*M_Ni_U)+i*M_Ni_U+j];
					p_para_face[face].p_sy_f[i][j] = p_para_recv[k].p_sy[ii*(Num_U*M_Ni_U)+i*M_Ni_U+j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_vis_grad( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,ii, face, partition_e, partition_f, slave_e, slave_f;
	int index_in_e;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			face = p_para_send[k].p_face[ii];
			index_in_e = Grid.p_face[face].index_in_e;

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_xi_1d; j++)
				{
					p_para_send[k].p_gradx[ ii*(Num_U*M_xi_1d) + i*M_xi_1d + j ] =
					p_para_element[e].grad_ux_face_in_e[index_in_e][i][j] +
					factor_edge*p_para_face[face].S_facex_l[i][j];

					p_para_send[k].p_grady[ ii*(Num_U*M_xi_1d) + i*M_xi_1d + j ] =
					p_para_element[e].grad_uy_face_in_e[index_in_e][i][j] +
					factor_edge*p_para_face[face].S_facey_l[i][j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//==================== Receiving and Sending infor_grad_x =====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_gradx, p_para_recv[k].num*(Num_U*M_xi_1d), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_gradx, p_para_send[k].num*(Num_U*M_xi_1d), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//==================== Receiving and Sending infor_grad_y =====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_grady, p_para_recv[k].num*(Num_U*M_xi_1d), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_grady, p_para_send[k].num*(Num_U*M_xi_1d), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_u_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];
			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_xi_1d; j++)
				{
					p_para_face[face].p_gradx_f[i][j] = p_para_recv[k].p_gradx[ii*(Num_U*M_xi_1d)+i*M_xi_1d+j];
					p_para_face[face].p_grady_f[i][j] = p_para_recv[k].p_grady[ii*(Num_U*M_xi_1d)+i*M_xi_1d+j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_vis_dS( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,t,s,ii, face, partition_e, partition_f, slave_e, slave_f;
	int index_in_e;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//TEST
	//FILE* fp;
	//char fname[100];
	//sprintf(fname,"dS_%d.txt",my_id);
	//fp =  fopen(fname,"w");
	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			face = p_para_send[k].p_face[ii];
			index_in_e = Grid.p_face[face].index_in_e;

			/*
			if(28 == Grid.p_e_master[e])
			{
				fprintf(fp,"%10d\n",Grid.p_face_master[face]);
				fprintf(fp,"%10d\n",face);
				fprintf(fp,"%10d\n",Grid.p_face[face].face_in_partition_f);
				for(t=0;t<2;t++)
					for(i=0; i<Num_U; i++)
						for(s=0;s<Num_U;s++)
							for(j=0; j<M_xi_1d; j++)
							{
								fprintf(fp,"%10.6f%10.6f\n",p_para_face[face].dS_facex_l[t][i][s][j],
															 p_para_face[face].dS_facey_l[t][i][s][j]);
								fprintf(fp,"\n");
							}
				fprintf(fp,"\n\n");
			}
			*/
			for(t=0;t<2;t++)
			{
				for(i=0; i<Num_U; i++)
					for(s=0;s<Num_U;s++)
					{
						for(j=0; j<M_xi_1d; j++)
						{
							p_para_send[k].p_dS_facex[ ii*(2*Num_U*Num_U*M_xi_1d) +
							t*(Num_U*Num_U*M_xi_1d) + i*(Num_U*M_xi_1d) + s*M_xi_1d + j ] =
							p_para_face[face].dS_facex_l[t][i][s][j];

							p_para_send[k].p_dS_facey[ ii*(2*Num_U*Num_U*M_xi_1d) +
							t*(Num_U*Num_U*M_xi_1d) + i*(Num_U*M_xi_1d) + s*M_xi_1d + j ] =
							p_para_face[face].dS_facey_l[t][i][s][j];
						}
					}
			}

		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//==================== Receiving and Sending infor_grad_x =====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_dS_facex, p_para_recv[k].num*(2*Num_U*Num_U*M_xi_1d), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_dS_facex, p_para_send[k].num*(2*Num_U*Num_U*M_xi_1d), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//==================== Receiving and Sending infor_grad_y =====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_dS_facey, p_para_recv[k].num*(2*Num_U*Num_U*M_xi_1d), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_dS_facey, p_para_send[k].num*(2*Num_U*Num_U*M_xi_1d), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.p_dS_facex.y +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			face = p_para_send[k].p_face[ii];

			for(t=0;t<2;t++)
			{
				for(i=0; i<Num_U; i++)
					for(s=0;s<Num_U;s++)
					{
						for(j=0; j<M_xi_1d; j++)
						{
							p_para_face[face].p_dS_facex_rf[t][i][s][j] =
							p_para_recv[k].p_dS_facex[ ii*(2*Num_U*Num_U*M_xi_1d) +
							t*(Num_U*Num_U*M_xi_1d) + i*(Num_U*M_xi_1d) + s*M_xi_1d + j ];

							p_para_face[face].p_dS_facey_rf[t][i][s][j] =
							p_para_recv[k].p_dS_facey[ ii*(2*Num_U*Num_U*M_xi_1d) +
							t*(Num_U*Num_U*M_xi_1d) + i*(Num_U*M_xi_1d) + s*M_xi_1d + j ];
						}
					}
			}
			/*
			if(28 == Grid.p_e_master[e])
			{
				for(t=0;t<2;t++)
					for(i=0; i<Num_U; i++)
						for(s=0;s<Num_U;s++)
							for(j=0; j<M_xi_1d; j++)
							{
								fprintf(fp,"%10.6f%10.6f\n",p_para_face[face].p_dS_facex_rf[t][i][s][j],
															p_para_face[face].p_dS_facey_rf[t][i][s][j]);
								fprintf(fp,"\n");
							}
				fprintf(fp,"\n\n");
			}
			*/
		}
	}
	//fclose(fp);
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_dxidX( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,t,ii, face, partition_e, partition_f, slave_e, slave_f;
	int index_in_e;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];
			face = p_para_send[k].p_face[ii];
			index_in_e = Grid.p_face[face].index_in_e;

			for(i=0; i<M_xi_1d; i++)
			{
				for(j=0; j<2; j++)
				{
					for(t=0; t<2; t++)
					{

						p_para_send[k].p_dxi_dX_r[ ii*(M_xi_1d*4) + i*4 + j*2 + t ] =
						Grid.p_element[e].p_dxi_dX_face_in_e[index_in_e][i][j][t] ;
					}
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//==================== Receiving and Sending infor_dxidX =====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_dxi_dX_r, p_para_recv[k].num*(M_xi_1d*4), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_dxi_dX_r, p_para_send[k].num*(M_xi_1d*4), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.dxidX +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(i=0; i<M_xi_1d; i++)
			{
				for(j=0; j<2; j++)
				{
					for(t=0; t<2; t++)
					{
						Grid.p_face[face].p_dxi_dX_rface[i][j][t] =
							p_para_recv[k].p_dxi_dX_r[ii*(M_xi_1d*4)+i*4+j*2+t];
					}
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_etype( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{
	int e,f,i,j,k,t,ii, face, partition_e, partition_f, slave_e, slave_f;
	int index_in_e;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			p_para_send[k].p_type[ii] =
			Grid.p_element[e].type ;
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//==================== Receiving and Sending infor_type=====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_type, p_para_recv[k].num, MPI_INT, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_type, p_para_send[k].num, MPI_INT, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.dxidX +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			p_para_face[face].p_type_f = p_para_recv[k].p_type[ii];
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}


void Exchange_num_element_total(int my_id, GRID_GENERAL& Grid)
{
	int k, partition_f,slave_f;

	int* p_num_temp = new int[NUM_PARTITION];

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[NUM_PARTITION];
	MPI_Request* p_request_recv = new MPI_Request[NUM_PARTITION];
	MPI_Status*  p_status_send  = new MPI_Status[NUM_PARTITION];
	MPI_Status*  p_status_recv  = new MPI_Status[NUM_PARTITION];

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Irecv(&p_num_temp[k], 1, MPI_INT, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Isend(&Grid.num_e, 1, MPI_INT, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(NUM_PARTITION, p_request_recv, p_status_recv);
	MPI_Waitall(NUM_PARTITION, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ Init p_para_face.p_V_f +++++++++++++++++++++++++++++++++++
	NUM_ELEMENT_TOTAL = 0;
	for(k=0; k<NUM_PARTITION; k++)
	{
		NUM_ELEMENT_TOTAL = NUM_ELEMENT_TOTAL + p_num_temp[k];
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	delete[]p_num_temp;

	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_num_face_total(int my_id, GRID_GENERAL& Grid)
{
	int k, partition_f,slave_f;

	int* p_num_temp = new int[NUM_PARTITION];

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[NUM_PARTITION];
	MPI_Request* p_request_recv = new MPI_Request[NUM_PARTITION];
	MPI_Status*  p_status_send  = new MPI_Status[NUM_PARTITION];
	MPI_Status*  p_status_recv  = new MPI_Status[NUM_PARTITION];

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Irecv(&p_num_temp[k], 1, MPI_INT, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Isend(&Grid.num_face, 1, MPI_INT, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(NUM_PARTITION, p_request_recv, p_status_recv);
	MPI_Waitall(NUM_PARTITION, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ Init p_para_face.p_V_f +++++++++++++++++++++++++++++++++++
	NUM_FACE_TOTAL = 0;
	for(k=0; k<NUM_PARTITION; k++)
	{
		NUM_FACE_TOTAL = NUM_FACE_TOTAL + p_num_temp[k];
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	delete[]p_num_temp;

	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_du(int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element)
{
	int e,f,i,j,k,ii, face, partition_e, partition_f, slave_e, slave_f;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];
	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_send[k].p_du[ ii*(Num_U*M_Ni_U) + i*M_Ni_U+j ] = p_para_element[e].p_du[ i*M_Ni_U+j ];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_du, p_para_recv[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_du, p_para_send[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);
	//+++++++++++++++++++++++++++++++++ renew p_para_face.p_du_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_face[face].p_du_f[i*M_Ni_U+j] = p_para_recv[k].p_du[ii*(Num_U*M_Ni_U)+i*M_Ni_U+j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_infor_du0(int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element)
{
	int e,f,i,j,k,ii, face, partition_e, partition_f, slave_e, slave_f;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];
	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_send[k].p_du0[ ii*(Num_U*M_Ni_U) + i*M_Ni_U+j ] = p_para_element[e].p_du0[ i*M_Ni_U+j ];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].p_du0, p_para_recv[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].p_du0, p_para_send[k].num*(Num_U*M_Ni_U), MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);
	//+++++++++++++++++++++++++++++++++ renew p_para_face.p_du_f +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			for(i=0; i<Num_U; i++)
			{
				for(j=0; j<M_Ni_U; j++)
				{
					p_para_face[face].p_du0_f[i*M_Ni_U+j] = p_para_recv[k].p_du0[ii*(Num_U*M_Ni_U)+i*M_Ni_U+j];
				}
			}
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}


void Exchange_infor_newe( int my_id, GRID_GENERAL& Grid, PARA_FACE* p_para_face, PARA_ELEMENT* p_para_element )
{

	int e,f,i,j,k,t,ii, face, partition_e, partition_f, slave_e, slave_f;
	int index_in_e;

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Request* p_request_recv = new MPI_Request[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_send  = new MPI_Status[Grid.num_partition_neighbouring];
	MPI_Status*  p_status_recv  = new MPI_Status[Grid.num_partition_neighbouring];

	//++++++++++++++++++++++++++++++++++++ renew p_para_send +++++++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_send[k].num; ii++)
		{
			e = p_para_send[k].p_e[ii];

			p_para_send[k].enew[ii] = Grid.p_element[e].enew;
		}
	}

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//==================== Receiving and Sending infor_type=====================
	//------------------------ Receiving Infor ------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Irecv(p_para_recv[k].enew, p_para_recv[k].num, MPI_INT, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		partition_f = Grid.p_partition_neighbouring[k];
		slave_f     = partition_f;

		MPI_Isend(p_para_send[k].enew, p_para_send[k].num, MPI_INT, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_recv, p_status_recv);
	MPI_Waitall(Grid.num_partition_neighbouring, p_request_send, p_status_send);

	//++++++++++++++++++++++++++++++++++ renew p_para_face.dxidX +++++++++++++++++++++++++++++++++++
	for(k=0; k<Grid.num_partition_neighbouring; k++)
	{
		for(ii=0; ii<p_para_recv[k].num; ii++)
		{
			face = p_para_recv[k].p_face[ii];

			p_para_face[face].enew_f = p_para_recv[k].enew[ii];
		}
	}

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

void Exchange_MAX_udu_Linf(int my_id, GRID_GENERAL& Grid,double MAXdu,double& MAX_MAXdu)
{
	int e,f,i,j,k,ii, face, partition_f,slave_f;

	double* MAXdu_partition = new double[NUM_PARTITION];

	int sender;
	MPI_Status   status;
	MPI_Request* p_request_send = new MPI_Request[NUM_PARTITION];
	MPI_Request* p_request_recv = new MPI_Request[NUM_PARTITION];
	MPI_Status*  p_status_send  = new MPI_Status[NUM_PARTITION];
	MPI_Status*  p_status_recv  = new MPI_Status[NUM_PARTITION];

	//------------------------ Receiving Infor ------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Irecv(&MAXdu_partition[k], 1, MPI_DOUBLE, slave_f, MPI_ANY_TAG, MPI_COMM_WORLD, &p_request_recv[k]);
	}
	//------------------------- Sending Infor -------------------------
	for(k=0; k<NUM_PARTITION; k++)
	{
		partition_f = k;
		slave_f     = partition_f;

		MPI_Isend(&MAXdu, 1, MPI_DOUBLE, slave_f, 1, MPI_COMM_WORLD, &p_request_send[k]);
	}
	//-----------------------------------------------------------------
	MPI_Waitall(NUM_PARTITION, p_request_recv, p_status_recv);
	MPI_Waitall(NUM_PARTITION, p_request_send, p_status_send);
	//++++++++++++++++++++++++++++++++++ Init p_para_face.p_V_f +++++++++++++++++++++++++++++++++++
	MAX_MAXdu = 0.0;
	for(k=0; k<NUM_PARTITION; k++)
	{
		if(MAXdu_partition[k]>MAX_MAXdu)
		{
			MAX_MAXdu = MAXdu_partition[k];
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	delete[]MAXdu_partition;

	delete[]p_request_send;
	delete[]p_request_recv;
	delete[]p_status_send;
	delete[]p_status_recv;
}

